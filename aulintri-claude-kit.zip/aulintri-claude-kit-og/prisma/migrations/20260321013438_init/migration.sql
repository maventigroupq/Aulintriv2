-- CreateExtension
CREATE EXTENSION IF NOT EXISTS "vector" WITH SCHEMA "public";

-- CreateExtension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- CreateEnum
CREATE TYPE "BillingTier" AS ENUM ('FULL_SERVICE', 'CO_PILOT', 'PLATFORM');

-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('ADMIN', 'OPS', 'CUSTOMER', 'PARTNER', 'MCP_AGENT');

-- CreateEnum
CREATE TYPE "LedgerRecordType" AS ENUM ('pre', 'post');

-- CreateEnum
CREATE TYPE "ThreatEventType" AS ENUM ('INTENSIVE_EXAM', 'FDA_HOLD', 'USDA_HOLD', 'DOJ_TRANSSHIPMENT', 'CUSTOMS_HOLD_PATTERN', 'AD_CVD_SCOPE_ACTION');

-- CreateEnum
CREATE TYPE "AnonymizationStatus" AS ENUM ('PENDING_REVIEW', 'CLEARED', 'REJECTED');

-- CreateEnum
CREATE TYPE "QuoteStatus" AS ENUM ('DRAFT', 'PENDING', 'SENT', 'APPROVED', 'REJECTED', 'EXPIRED');

-- CreateEnum
CREATE TYPE "ShipmentStatus" AS ENUM ('BOOKED', 'DOCS_RECEIVED', 'LOADED', 'IN_TRANSIT', 'ARRIVED', 'CUSTOMS_HOLD', 'RELEASED', 'DELIVERED');

-- CreateEnum
CREATE TYPE "AgentType" AS ENUM ('QUOTE_AGENT', 'CLEARANCE_AGENT', 'OPS_AGENT');

-- CreateEnum
CREATE TYPE "EntryType" AS ENUM ('ISF', 'TYPE_01', 'IN_BOND_IT', 'IN_BOND_IE', 'IN_BOND_TE', 'FTZ_TYPE_06', 'DRAWBACK', 'AES_EXPORT', 'AMS_MANIFEST');

-- CreateEnum
CREATE TYPE "EntryStatus" AS ENUM ('PENDING', 'FILED', 'ACCEPTED', 'REJECTED', 'RELEASED', 'LIQUIDATED');

-- CreateTable
CREATE TABLE "organizations" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "billing_tier" "BillingTier" NOT NULL DEFAULT 'CO_PILOT',
    "fan_opt_in" BOOLEAN NOT NULL DEFAULT true,
    "monthly_entry_allotment" INTEGER NOT NULL DEFAULT 25,
    "monthly_isf_allotment" INTEGER NOT NULL DEFAULT 30,
    "monthly_tool_call_allotment" INTEGER NOT NULL DEFAULT 500,
    "autonomous_filing_threshold" DOUBLE PRECISION NOT NULL DEFAULT 0.97,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "organizations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "users" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "org_id" UUID NOT NULL,
    "email" TEXT NOT NULL,
    "role" "UserRole" NOT NULL,
    "cognito_sub" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agent_action_ledger" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "tenant_id" UUID NOT NULL,
    "action_type" TEXT NOT NULL,
    "record_type" "LedgerRecordType" NOT NULL,
    "shipment_id" UUID,
    "quote_id" UUID,
    "reserve_allocated" BOOLEAN NOT NULL DEFAULT false,
    "burst_billable" BOOLEAN NOT NULL DEFAULT false,
    "outcome_type" TEXT,
    "outcome_value_usd" DOUBLE PRECISION,
    "sla_met" BOOLEAN NOT NULL,
    "confidence_score" DOUBLE PRECISION NOT NULL,
    "data_source" TEXT NOT NULL DEFAULT 'live',
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "agent_action_ledger_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "threat_events" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "detected_by_tenant" TEXT NOT NULL,
    "event_type" "ThreatEventType" NOT NULL,
    "hts_chapters_affected" TEXT[],
    "origin_country" TEXT NOT NULL,
    "destination_port" TEXT,
    "risk_level" INTEGER NOT NULL,
    "anonymization_status" "AnonymizationStatus" NOT NULL DEFAULT 'PENDING_REVIEW',
    "shared" BOOLEAN NOT NULL DEFAULT false,
    "detected_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "alerted_at" TIMESTAMP(3),
    "resolution_status" TEXT,

    CONSTRAINT "threat_events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "quotes" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "tenant_id" UUID NOT NULL,
    "status" "QuoteStatus" NOT NULL DEFAULT 'DRAFT',
    "version" INTEGER NOT NULL DEFAULT 1,
    "origin_port" TEXT,
    "dest_port" TEXT,
    "commodity_desc" TEXT,
    "container_type" TEXT,
    "hts_candidates" TEXT[],
    "confirmed_coo" TEXT,
    "ad_cvd_alerts" JSONB[],
    "agent_session_id" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "sent_at" TIMESTAMP(3),
    "approved_at" TIMESTAMP(3),
    "expires_at" TIMESTAMP(3),

    CONSTRAINT "quotes_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "shipments" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "tenant_id" UUID NOT NULL,
    "quote_id" UUID,
    "status" "ShipmentStatus" NOT NULL DEFAULT 'BOOKED',
    "active_agent" "AgentType",
    "carrier_id" TEXT,
    "booking_reference" TEXT,
    "vessel_eta" TIMESTAMP(3),
    "vessel_ata" TIMESTAMP(3),
    "enhanced_review" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "shipments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "customs_entries" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "tenant_id" UUID NOT NULL,
    "shipment_id" UUID NOT NULL,
    "entry_type" "EntryType" NOT NULL DEFAULT 'TYPE_01',
    "status" "EntryStatus" NOT NULL DEFAULT 'PENDING',
    "hts_code" TEXT,
    "confidence_score" DOUBLE PRECISION,
    "review_required_fields" JSONB,
    "entered_value" DOUBLE PRECISION,
    "duty_calc" JSONB,
    "abi_transmission_id" TEXT,
    "cbp_response_code" TEXT,
    "isf_id" TEXT,
    "doc_received_at" TIMESTAMP(3),
    "draft_ready_at" TIMESTAMP(3),
    "filed_at" TIMESTAMP(3),
    "liquidated_at" TIMESTAMP(3),
    "liquidated_duty" DOUBLE PRECISION,
    "ad_cvd_alerts" JSONB[],
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "customs_entries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "hts_classifications" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "tenant_id" UUID NOT NULL,
    "commodity_desc" TEXT NOT NULL,
    "country_of_origin" TEXT NOT NULL,
    "hts_code" TEXT NOT NULL,
    "confidence_score" DOUBLE PRECISION NOT NULL,
    "cbp_liquidated_code" TEXT,
    "is_confirmed" BOOLEAN NOT NULL DEFAULT false,
    "entry_id" UUID,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "hts_classifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "rag_documents" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "content" TEXT NOT NULL,
    "embedding" vector(1536),
    "source" TEXT NOT NULL,
    "document_type" TEXT NOT NULL,
    "hts_chapters_affected" TEXT[],
    "countries_affected" TEXT[],
    "effective_date" TIMESTAMP(3),
    "case_number" TEXT,
    "ingested_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "rag_documents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "documents" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "tenant_id" UUID NOT NULL,
    "shipment_id" UUID,
    "type" TEXT NOT NULL,
    "s3_key" TEXT NOT NULL,
    "sha256_hash" TEXT NOT NULL,
    "template_version" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "documents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_log" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "tenant_id" UUID NOT NULL,
    "entity_type" TEXT NOT NULL,
    "entity_id" UUID NOT NULL,
    "action" TEXT NOT NULL,
    "actor_id" UUID,
    "actor_type" TEXT,
    "metadata" JSONB,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_log_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "billing_summaries" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "tenant_id" UUID NOT NULL,
    "billing_period_start" TIMESTAMP(3) NOT NULL,
    "billing_period_end" TIMESTAMP(3) NOT NULL,
    "reserve_fee" DOUBLE PRECISION NOT NULL,
    "reserve_consumed" INTEGER NOT NULL,
    "burst_billable_count" INTEGER NOT NULL,
    "burst_amount" DOUBLE PRECISION NOT NULL,
    "outcome_amount" DOUBLE PRECISION NOT NULL,
    "total_amount" DOUBLE PRECISION NOT NULL,
    "invoice_generated" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "billing_summaries_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "organizations_slug_key" ON "organizations"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "users_cognito_sub_key" ON "users"("cognito_sub");

-- CreateIndex
CREATE INDEX "agent_action_ledger_tenant_id_action_type_timestamp_idx" ON "agent_action_ledger"("tenant_id", "action_type", "timestamp");

-- CreateIndex
CREATE INDEX "agent_action_ledger_shipment_id_idx" ON "agent_action_ledger"("shipment_id");

-- CreateIndex
CREATE INDEX "threat_events_hts_chapters_affected_idx" ON "threat_events" USING GIN ("hts_chapters_affected");

-- CreateIndex
CREATE INDEX "threat_events_anonymization_status_shared_idx" ON "threat_events"("anonymization_status", "shared");

-- CreateIndex
CREATE UNIQUE INDEX "shipments_quote_id_key" ON "shipments"("quote_id");

-- CreateIndex
CREATE INDEX "hts_classifications_tenant_id_hts_code_idx" ON "hts_classifications"("tenant_id", "hts_code");

-- CreateIndex
CREATE INDEX "rag_documents_hts_chapters_affected_idx" ON "rag_documents" USING GIN ("hts_chapters_affected");

-- CreateIndex
CREATE INDEX "rag_documents_countries_affected_idx" ON "rag_documents" USING GIN ("countries_affected");

-- CreateIndex
CREATE INDEX "audit_log_entity_type_entity_id_idx" ON "audit_log"("entity_type", "entity_id");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_action_ledger" ADD CONSTRAINT "agent_action_ledger_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shipments" ADD CONSTRAINT "shipments_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "shipments" ADD CONSTRAINT "shipments_quote_id_fkey" FOREIGN KEY ("quote_id") REFERENCES "quotes"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customs_entries" ADD CONSTRAINT "customs_entries_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customs_entries" ADD CONSTRAINT "customs_entries_shipment_id_fkey" FOREIGN KEY ("shipment_id") REFERENCES "shipments"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "documents" ADD CONSTRAINT "documents_shipment_id_fkey" FOREIGN KEY ("shipment_id") REFERENCES "shipments"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "billing_summaries" ADD CONSTRAINT "billing_summaries_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "organizations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
