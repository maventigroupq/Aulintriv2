# Netlify Deployment Checklist

## ⚡ Quick Deploy (Choose One)

### Option A: CLI Deploy (5 minutes)
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Navigate to project
cd /Users/minhnguyen/Downloads/aulintri_inDownloads/aulintri-claude-kit

# Login and deploy
netlify login
netlify init
netlify deploy --prod
```

### Option B: Git Deploy (10 minutes)
```bash
# 1. Push to GitHub
git init
git add .
git commit -m "Initial: Aulintri v2.0"
git remote add origin https://github.com/YOUR_USERNAME/aulintri.git
git push -u origin main

# 2. Go to https://app.netlify.com
# 3. Click "Add new site" → "Import from Git"
# 4. Select your repo → Deploy
```

---

## 📋 Pre-Deployment Checklist

### Files Created ✅
- [x] `netlify.toml` (configuration)
- [x] `.npmrc` (build settings)
- [x] `NETLIFY-DEPLOYMENT.md` (full guide)
- [x] `DEPLOY-CHECKLIST.md` (this file)

### Required for Frontend-Only
- [ ] Push code to GitHub
- [ ] Netlify account created
- [ ] Custom domain ready (optional)

### Required for Full Stack
- [ ] Neon PostgreSQL account + database
- [ ] Upstash Redis account + database
- [ ] Railway account (for backend)
- [ ] Claude API key
- [ ] Carrier API keys (Freightos, Flexport, Convoy)

---

## 🚀 Deployment Steps

### Step 1: Deploy Frontend to Netlify
- [ ] Connect GitHub repo to Netlify
- [ ] Verify build settings (auto-detected from `netlify.toml`)
- [ ] Add environment variables (if using external backend):
  ```
  NEXT_PUBLIC_API_URL=https://your-backend.railway.app
  NEXT_PUBLIC_MCP_URL=https://your-backend.railway.app/mcp
  ```
- [ ] Click "Deploy site"
- [ ] Wait 3-5 minutes for build
- [ ] Visit deployed URL (e.g., `https://random-name-123.netlify.app`)

### Step 2: Deploy Backend (Optional)
**If you need the full MCP server + RAG workers:**

#### Option 1: Railway (Recommended)
- [ ] Sign up at https://railway.app
- [ ] Create new project from GitHub repo
- [ ] Add environment variables:
  ```
  DATABASE_URL=postgresql://...
  REDIS_URL=rediss://...
  CLAUDE_API_KEY=sk-ant-...
  ```
- [ ] Deploy
- [ ] Copy deployment URL for Netlify env vars

#### Option 2: AWS Lambda
- [ ] Use existing Lambda deployment from Sprint 4
- [ ] Copy Lambda Function URL for Netlify

### Step 3: Setup Database (Optional)
**If deploying full stack:**

- [ ] Sign up at https://neon.tech
- [ ] Create database: "aulintri-production"
- [ ] Enable pgvector extension
- [ ] Run migrations:
  ```bash
  DATABASE_URL="postgresql://..." npx prisma migrate deploy
  ```
- [ ] Copy connection string for backend env vars

### Step 4: Setup Redis (Optional)
**If deploying full stack:**

- [ ] Sign up at https://upstash.com
- [ ] Create database: "aulintri-redis"
- [ ] Copy connection string (starts with `rediss://`)
- [ ] Add to backend env vars

---

## ✅ Post-Deployment Verification

### Frontend Checks
- [ ] Site loads: `https://your-site.netlify.app`
- [ ] No console errors (open DevTools)
- [ ] Quote Dashboard renders
- [ ] Navigation works (quotes list → detail)
- [ ] Tailwind CSS styles applied

### Backend Checks (if deployed)
- [ ] MCP endpoint responds:
  ```bash
  curl -X POST https://your-backend/mcp \
    -H "Content-Type: application/json" \
    -d '{"jsonrpc":"2.0","method":"tools/list","id":1}'
  ```
- [ ] Returns 5 tools (extract_rfq_data, classify_hts_code, etc.)
- [ ] Database connection works (check logs)
- [ ] Redis connection works (check logs)

### Full Stack Integration
- [ ] Frontend can call backend APIs
- [ ] Quote Agent can generate quotes
- [ ] RAG corpus queries work
- [ ] HTS classification returns results

---

## 🐛 Common Issues & Fixes

### Issue: Build fails with "Cannot find module 'prisma'"
**Fix:**
```json
// Add to package.json
"scripts": {
  "postinstall": "prisma generate"
}
```

### Issue: "CORS error" when calling backend
**Fix:** Add CORS to backend:
```typescript
// In Fastify server
import cors from '@fastify/cors';
await fastify.register(cors, {
  origin: 'https://your-netlify-site.netlify.app'
});
```

### Issue: Environment variables not working
**Fix:**
- Prefix with `NEXT_PUBLIC_` for client-side vars
- Redeploy after adding env vars (Netlify doesn't auto-redeploy)

### Issue: Large bundle size warning
**Fix:**
```bash
# Analyze bundle
npm run build

# Check .next/analyze/ folder
# Remove unused dependencies if needed
```

---

## 💰 Cost Summary

### Free Tier (Good for Testing)
- **Netlify:** Free (100GB bandwidth, 300 build minutes)
- **Neon:** Free (0.5GB storage)
- **Upstash:** Free (10K commands/day)
- **Railway:** $5 credit/month
- **TOTAL:** ~$0-5/month

### Production (5,000 quotes/month)
- **Netlify:** $19/month (Pro)
- **Neon:** $19/month (Scale)
- **Upstash:** $30/month
- **Railway:** $20/month
- **APIs:** $450/month (Claude + carriers)
- **TOTAL:** $538/month

---

## 📚 Resources

- **Full deployment guide:** `NETLIFY-DEPLOYMENT.md`
- **Architecture docs:** `docs/architecture/`
- **Sprint summaries:** `docs/sprint-acceptance/`
- **Executive summary:** `docs/EXECUTIVE-SUMMARY.md`

---

## 🎯 Quick Commands Reference

```bash
# Deploy to Netlify
netlify deploy --prod

# Check deployment status
netlify status

# View logs
netlify logs

# Open site in browser
netlify open:site

# Open admin dashboard
netlify open:admin

# Run build locally (test before deploy)
npm run build

# Test MCP endpoint
curl -X POST http://localhost:3000/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"tools/list","id":1}'
```

---

## ✨ You're Ready!

Your Aulintri platform is ready to deploy to Netlify. Choose your deployment option and follow the steps above.

**Recommended for first deploy:** Frontend-only (Option A: CLI Deploy)
**Time required:** 5-10 minutes
**No credit card required:** Use Netlify free tier

**Questions?** Check `NETLIFY-DEPLOYMENT.md` for detailed troubleshooting.

---

**Status:** ✅ Ready to deploy
**Last updated:** 2026-03-20
