# Aulintri Test Suite

Sprint 1 acceptance and integration tests for MCP-native customs compliance platform.

## Prerequisites

- Node.js 20+
- PostgreSQL 15 with pgvector extension
- Redis 7
- npm dependencies installed

## Setup

### 1. Install Dependencies

```bash
npm install
npm install --save-dev jest ts-jest @types/jest supertest @types/supertest
```

### 2. Create Test Database

```bash
createdb aulintri_test
psql aulintri_test -c "CREATE EXTENSION IF NOT EXISTS vector;"
```

### 3. Run Migrations

```bash
DATABASE_URL="postgresql://user:pass@localhost:5432/aulintri_test" npx prisma migrate dev
```

### 4. Set Environment Variables

Create `.env.test`:

```env
DATABASE_URL=postgresql://user:pass@localhost:5432/aulintri_test
REDIS_HOST=localhost
REDIS_PORT=6379
AWS_REGION=us-east-1
COGNITO_USER_POOL_ID=us-east-1_TEST
NODE_ENV=test
```

## Running Tests

### All Tests
```bash
npm test
```

### Specific Test Suite
```bash
npm test -- tests/integration/mcp-tools
npm test -- tests/unit/ledger.test.ts
npm test -- tests/acceptance/sprint-1-exit-criteria.test.ts
```

### Watch Mode
```bash
npm test -- --watch
```

### Coverage Report
```bash
npm test -- --coverage
```

## Test Structure

```
tests/
├── setup.ts                     # Global test setup and mocks
├── helpers/                     # Test utilities
│   └── db-setup.ts             # Database seed/teardown
├── fixtures/                    # Test data
│   ├── tenants.ts
│   ├── shipments.ts
│   ├── rfq-documents.ts
│   └── users.ts
├── unit/                        # Unit tests
│   └── ledger.test.ts          # Ledger service tests
├── integration/                 # Integration tests
│   ├── mcp-tools/              # MCP tool tests
│   │   ├── extract-rfq-data.test.ts
│   │   ├── classify-hts-code.test.ts
│   │   ├── get-carrier-rates.test.ts
│   │   └── get-carrier-safety-score.test.ts
│   ├── rls.test.ts             # Row-level security tests
│   ├── aos.test.ts             # Agent orchestration tests
│   └── quote-agent.test.ts     # Quote agent workflow tests
└── acceptance/                  # Acceptance tests
    └── sprint-1-exit-criteria.test.ts
```

## Sprint 1 Exit Criteria

The acceptance test suite validates:

- ✅ MCP Server responds to `tools/list` with 4 registered tools
- ✅ Each tool callable via JSON-RPC 2.0 MCP protocol
- ✅ agent_action_ledger records written BEFORE tool handler runs
- ✅ PostgreSQL RLS blocks cross-tenant queries
- ✅ FAN threat_events respects anonymization rules
- ✅ All tests passing in CI/CD pipeline

## CI/CD Integration

Tests run automatically on:
- Every pull request
- Merge to main branch
- Tag push (releases)

See `.github/workflows/ci.yml` for configuration.

## Troubleshooting

### "Cannot find module '@/db/prisma'"
Run `npx prisma generate` to generate Prisma client.

### "Connection refused" errors
Ensure PostgreSQL and Redis are running locally.

### RLS tests fail
Verify Prisma migrations ran successfully: `npx prisma migrate status`

### "Exceeded timeout" errors
Increase timeout in jest.config.js or individual test files.

## Writing New Tests

### Unit Test Template

```typescript
import { functionToTest } from '@/path/to/module';

describe('ModuleName', () => {
  it('should do something', () => {
    const result = functionToTest(input);
    expect(result).toEqual(expected);
  });
});
```

### Integration Test Template

```typescript
import request from 'supertest';
import { app } from '@/index';

describe('API Endpoint', () => {
  it('should respond with success', async () => {
    const response = await request(app)
      .post('/mcp')
      .send({ jsonrpc: '2.0', method: 'tools/list', id: 1 });

    expect(response.status).toBe(200);
    expect(response.body.result).toBeDefined();
  });
});
```

## Mocking Guidelines

- Mock external APIs (AWS, FMCSA, carrier APIs)
- Mock database in unit tests, use real DB in integration tests
- Mock Redis pub/sub in unit tests
- Use fixtures for consistent test data

## Test Coverage Goals

- Sprint 1: 70% coverage (foundational)
- Sprint 2: 80% coverage (add E2E tests)
- Sprint 3: 85%+ coverage (production-ready)

Current coverage: Run `npm test -- --coverage` to view.
