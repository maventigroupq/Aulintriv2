/**
 * Test Fixtures - RFQ Documents
 * Sprint 1: Sample RFQ document data for testing
 */

export const testRFQDocuments = {
  standard_ocean: {
    document_s3_key: 'rfq/tenant_blx_001/rfq_20260315_001.pdf',
    extracted_data: {
      shipper: {
        name: 'Shanghai Manufacturing Co Ltd',
        address: {
          line1: '123 Industrial Road',
          city: 'Shanghai',
          country: 'CN',
          postal_code: '200000',
        },
        contact: {
          name: 'Li Wei',
          email: 'liwei@shanghai-mfg.com',
          phone: '+86-21-1234-5678',
        },
      },
      consignee: {
        name: 'Acme Imports Inc',
        address: {
          line1: '456 Commerce St',
          city: 'Los Angeles',
          state: 'CA',
          country: 'US',
          postal_code: '90001',
        },
        contact: {
          name: 'John Smith',
          email: 'jsmith@acme-imports.com',
          phone: '+1-310-555-0123',
        },
      },
      commodity_items: [
        {
          description: "Men's cotton trousers",
          quantity: 1000,
          unit_of_measure: 'DZN',
          estimated_value_usd: 12500.0,
          weight_kg: 450,
        },
        {
          description: "Women's cotton blouses",
          quantity: 800,
          unit_of_measure: 'DZN',
          estimated_value_usd: 9600.0,
          weight_kg: 320,
        },
      ],
      shipping_details: {
        origin_port: 'CNSHA',
        destination_port: 'USLAX',
        container_type: '40GP',
        cargo_ready_date: '2026-04-01',
        requested_delivery_date: '2026-05-10',
        incoterm: 'FOB',
      },
      special_instructions: 'Time-sensitive shipment. Require express clearance.',
    },
    extraction_confidence: 0.95,
    missing_fields: [],
  },

  air_freight: {
    document_s3_key: 'rfq/tenant_blx_001/rfq_20260318_002.pdf',
    extracted_data: {
      shipper: {
        name: 'Shenzhen Electronics Ltd',
        address: {
          line1: '88 Tech Park',
          city: 'Shenzhen',
          country: 'CN',
          postal_code: '518000',
        },
      },
      consignee: {
        name: 'Tech Distributors USA',
        address: {
          line1: '789 Airport Way',
          city: 'San Francisco',
          state: 'CA',
          country: 'US',
          postal_code: '94102',
        },
      },
      commodity_items: [
        {
          description: 'Smartphone accessories',
          quantity: 5000,
          unit_of_measure: 'EA',
          estimated_value_usd: 25000.0,
          weight_kg: 180,
        },
      ],
      shipping_details: {
        origin_airport: 'SZX',
        destination_airport: 'SFO',
        cargo_ready_date: '2026-04-05',
        requested_delivery_date: '2026-04-08',
        service_level: 'express',
      },
    },
    extraction_confidence: 0.92,
    missing_fields: ['shipper.contact', 'consignee.contact'],
  },

  incomplete: {
    document_s3_key: 'rfq/tenant_blx_001/rfq_20260320_003.pdf',
    extracted_data: {
      shipper: {
        name: 'Unknown Supplier',
      },
      consignee: {
        name: 'Acme Imports Inc',
        address: {
          city: 'Los Angeles',
          country: 'US',
        },
      },
      commodity_items: [
        {
          description: 'General merchandise',
          quantity: null,
          estimated_value_usd: null,
        },
      ],
      shipping_details: {
        origin_port: 'CNSHA',
        destination_port: 'USLAX',
      },
    },
    extraction_confidence: 0.62,
    missing_fields: [
      'shipper.address',
      'shipper.contact',
      'consignee.address.line1',
      'commodity_items[0].quantity',
      'commodity_items[0].estimated_value_usd',
      'shipping_details.cargo_ready_date',
    ],
  },
};
