/**
 * Test Fixtures - Tenants
 * Sprint 1: Sample tenant configurations for testing
 */

export const testTenants = {
  blx: {
    id: 'tenant_blx_001',
    name: 'Beyond Logix',
    type: 'blx',
    status: 'active',
    billing_tier: 'enterprise',
    reserve_balance_usd: 5000.0,
    burst_limit_usd: 2000.0,
    e_and_o_policy_number: 'EO-BLX-2026-001',
  },
  blc: {
    id: 'tenant_blc_001',
    name: 'Beyond Clearance',
    type: 'blc',
    status: 'active',
    billing_tier: 'enterprise',
    reserve_balance_usd: 3000.0,
    burst_limit_usd: 1500.0,
    e_and_o_policy_number: 'EO-BLC-2026-001',
  },
  external_customer: {
    id: 'tenant_ext_001',
    name: 'Acme Imports Inc',
    type: 'external_customer',
    status: 'active',
    billing_tier: 'pro',
    reserve_balance_usd: 1000.0,
    burst_limit_usd: 500.0,
    e_and_o_policy_number: null,
  },
  low_balance: {
    id: 'tenant_low_balance',
    name: 'Low Balance Test Tenant',
    type: 'external_customer',
    status: 'active',
    billing_tier: 'free',
    reserve_balance_usd: 0,
    burst_limit_usd: 100.0,
    e_and_o_policy_number: null,
  },
};
