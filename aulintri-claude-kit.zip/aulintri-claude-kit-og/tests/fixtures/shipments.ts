/**
 * Test Fixtures - Shipments
 * Sprint 1: Sample shipment data for testing
 */

export const testShipments = {
  in_transit: {
    id: 'shipment_001',
    tenant_id: 'tenant_blx_001',
    shipment_reference: 'BLX-2026-0001',
    status: 'in_transit',
    origin_port: 'CNSHA',
    destination_port: 'USLAX',
    container_type: '40GP',
    cargo_ready_date: new Date('2026-03-15'),
    estimated_arrival: new Date('2026-04-10'),
    shipper: {
      name: 'Shanghai Manufacturing Co Ltd',
      address: {
        line1: '123 Industrial Road',
        city: 'Shanghai',
        country: 'CN',
        postal_code: '200000',
      },
    },
    consignee: {
      name: 'Acme Imports Inc',
      address: {
        line1: '456 Commerce St',
        city: 'Los Angeles',
        state: 'CA',
        country: 'US',
        postal_code: '90001',
      },
    },
    isf_filed: true,
    isf_filing_id: 'ISF-2026-001',
    entry_filed: false,
    active_agent: 'clearance_agent',
  },

  quoted: {
    id: 'shipment_002',
    tenant_id: 'tenant_blx_001',
    shipment_reference: 'BLX-2026-0002',
    status: 'quoted',
    origin_port: 'CNNGB',
    destination_port: 'USNYC',
    container_type: '20GP',
    cargo_ready_date: new Date('2026-04-01'),
    estimated_arrival: new Date('2026-05-05'),
    shipper: {
      name: 'Ningbo Exports Ltd',
      address: {
        line1: '789 Export Blvd',
        city: 'Ningbo',
        country: 'CN',
        postal_code: '315000',
      },
    },
    consignee: {
      name: 'East Coast Trading LLC',
      address: {
        line1: '321 Shipping Lane',
        city: 'New York',
        state: 'NY',
        country: 'US',
        postal_code: '10001',
      },
    },
    isf_filed: false,
    entry_filed: false,
    active_agent: 'quote_agent',
  },

  cleared: {
    id: 'shipment_003',
    tenant_id: 'tenant_ext_001',
    shipment_reference: 'ACM-2026-0001',
    status: 'cleared',
    origin_port: 'VNSGN',
    destination_port: 'USSEA',
    container_type: '40HC',
    cargo_ready_date: new Date('2026-02-15'),
    estimated_arrival: new Date('2026-03-18'),
    actual_arrival: new Date('2026-03-18'),
    isf_filed: true,
    isf_filing_id: 'ISF-2026-003',
    entry_filed: true,
    entry_number: '123-4567890-1',
    active_agent: 'ops_agent',
  },
};

export const testCommodities = [
  {
    description: "Men's cotton trousers, size 32",
    hts_code: '6203424060',
    quantity: 1000,
    unit_of_measure: 'DZN',
    unit_value_usd: 12.50,
    total_value_usd: 12500.0,
    country_of_origin: 'CN',
  },
  {
    description: 'Wooden furniture - dining tables',
    hts_code: '9403608041',
    quantity: 50,
    unit_of_measure: 'NO',
    unit_value_usd: 245.00,
    total_value_usd: 12250.0,
    country_of_origin: 'VN',
  },
  {
    description: 'Computer monitors, 27 inch LCD',
    hts_code: '8528520000',
    quantity: 200,
    unit_of_measure: 'NO',
    unit_value_usd: 180.00,
    total_value_usd: 36000.0,
    country_of_origin: 'KR',
  },
];
