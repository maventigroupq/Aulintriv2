/**
 * Test Fixtures - Users
 * Sprint 1: Sample user accounts for testing
 */

export const testUsers = {
  blx_admin: {
    id: 'user_blx_admin_001',
    tenant_id: 'tenant_blx_001',
    cognito_sub: 'cognito-sub-blx-admin-001',
    email: 'admin@beyondlogix.com',
    role: 'admin',
    status: 'active',
  },

  blx_operator: {
    id: 'user_blx_ops_001',
    tenant_id: 'tenant_blx_001',
    cognito_sub: 'cognito-sub-blx-ops-001',
    email: 'ops@beyondlogix.com',
    role: 'operator',
    status: 'active',
  },

  blc_broker: {
    id: 'user_blc_broker_001',
    tenant_id: 'tenant_blc_001',
    cognito_sub: 'cognito-sub-blc-broker-001',
    email: 'broker@beyondclearance.com',
    role: 'broker',
    status: 'active',
  },

  external_customer: {
    id: 'user_ext_customer_001',
    tenant_id: 'tenant_ext_001',
    cognito_sub: 'cognito-sub-ext-customer-001',
    email: 'contact@acme-imports.com',
    role: 'readonly',
    status: 'active',
  },

  mcp_agent: {
    id: 'user_mcp_agent_001',
    tenant_id: 'tenant_blx_001',
    cognito_sub: 'cognito-sub-mcp-agent-001',
    email: 'mcp-agent@system.internal',
    role: 'api_key',
    status: 'active',
  },
};

export const testJWTTokens = {
  blx_admin: 'mock_jwt_token_blx_admin_valid',
  blx_operator: 'mock_jwt_token_blx_ops_valid',
  blc_broker: 'mock_jwt_token_blc_broker_valid',
  external_customer: 'mock_jwt_token_ext_customer_valid',
  mcp_agent: 'mock_jwt_token_mcp_agent_valid',
  expired: 'mock_jwt_token_expired',
  invalid: 'mock_jwt_token_invalid_signature',
};
