/**
 * Ledger Service - Unit Tests
 * Sprint 1: Tests agent_action_ledger pre-execution pattern (ADR-003)
 */

import { writeLedgerEntry, updateLedgerEntry } from '@/services/ledger';
import { prisma } from '@/db/prisma';

describe('Ledger Service', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('writeLedgerEntry()', () => {
    it('should create ledger entry with all NOT NULL fields', async () => {
      const mockEntry = {
        action_id: 'action_123',
        tenant_id: 'tenant_456',
        action_type: 'classify_hts',
        reserve_allocated: 0.25,
        burst_billable: 0,
        outcome_type: 'pending',
        outcome_value_usd: 0,
        sla_met: false,
        confidence_score: 0,
        timestamp: new Date(),
      };

      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue(mockEntry);

      const result = await writeLedgerEntry({
        tenant_id: 'tenant_456',
        action_type: 'classify_hts',
      });

      expect(prisma.agentActionLedger.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          tenant_id: 'tenant_456',
          action_type: 'classify_hts',
          outcome_type: 'pending',
          sla_met: false,
          confidence_score: 0,
        }),
      });

      expect(result.action_id).toBe('action_123');
    });

    it('should calculate cost based on action_type', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_cost_123',
      });

      await writeLedgerEntry({
        tenant_id: 'tenant_456',
        action_type: 'classify_hts',
      });

      const createCall = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0];
      expect(createCall.data.reserve_allocated).toBeGreaterThan(0);
    });

    it('should set initial outcome_type to "pending"', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_pending_123',
      });

      await writeLedgerEntry({
        tenant_id: 'tenant_456',
        action_type: 'extract_rfq',
      });

      const createCall = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0];
      expect(createCall.data.outcome_type).toBe('pending');
    });

    it('should set initial sla_met to false', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_sla_123',
      });

      await writeLedgerEntry({
        tenant_id: 'tenant_456',
        action_type: 'get_carrier_rates',
      });

      const createCall = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0];
      expect(createCall.data.sla_met).toBe(false);
    });

    it('should throw error if database write fails', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockRejectedValue(
        new Error('Database connection lost')
      );

      await expect(
        writeLedgerEntry({
          tenant_id: 'tenant_456',
          action_type: 'classify_hts',
        })
      ).rejects.toThrow('Database connection lost');
    });
  });

  describe('updateLedgerEntry()', () => {
    it('should update existing ledger entry', async () => {
      (prisma.agentActionLedger.update as jest.Mock).mockResolvedValue({
        action_id: 'action_123',
        outcome_type: 'success',
      });

      await updateLedgerEntry('action_123', {
        outcome_type: 'success',
        outcome_value_usd: 100.0,
        sla_met: true,
        confidence_score: 0.98,
      });

      expect(prisma.agentActionLedger.update).toHaveBeenCalledWith({
        where: { action_id: 'action_123' },
        data: expect.objectContaining({
          outcome_type: 'success',
          outcome_value_usd: 100.0,
          sla_met: true,
          confidence_score: 0.98,
        }),
      });
    });

    it('should update with failure outcome', async () => {
      (prisma.agentActionLedger.update as jest.Mock).mockResolvedValue({
        action_id: 'action_failure_123',
      });

      await updateLedgerEntry('action_failure_123', {
        outcome_type: 'failure',
        outcome_value_usd: 0,
        sla_met: false,
        error_message: 'Classification service timeout',
      });

      const updateCall = (prisma.agentActionLedger.update as jest.Mock).mock.calls[0][0];
      expect(updateCall.data.outcome_type).toBe('failure');
      expect(updateCall.data.error_message).toContain('timeout');
    });

    it('should include execution time', async () => {
      (prisma.agentActionLedger.update as jest.Mock).mockResolvedValue({});

      await updateLedgerEntry('action_timing_123', {
        outcome_type: 'success',
        execution_time_ms: 2450,
      });

      const updateCall = (prisma.agentActionLedger.update as jest.Mock).mock.calls[0][0];
      expect(updateCall.data.execution_time_ms).toBe(2450);
    });
  });

  describe('Cost Calculation', () => {
    it('should charge different amounts per action_type', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({});

      await writeLedgerEntry({ tenant_id: 'tenant_456', action_type: 'extract_rfq' });
      const extractCost = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0].data.reserve_allocated;

      jest.clearAllMocks();

      await writeLedgerEntry({ tenant_id: 'tenant_456', action_type: 'submit_isf' });
      const isfCost = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0].data.reserve_allocated;

      expect(extractCost).not.toBe(isfCost);
    });

    it('should use reserve_allocated when balance available', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({});

      await writeLedgerEntry({
        tenant_id: 'tenant_with_balance',
        action_type: 'classify_hts',
      });

      const createCall = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0];
      expect(createCall.data.reserve_allocated).toBeGreaterThan(0);
      expect(createCall.data.burst_billable).toBe(0);
    });
  });

  describe('Billing Logic', () => {
    it('should deduct from reserve first', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({});

      await writeLedgerEntry({
        tenant_id: 'tenant_with_reserve',
        action_type: 'classify_hts',
        tenant_reserve_balance: 100.0,
      });

      const createCall = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0];
      expect(createCall.data.reserve_allocated).toBeGreaterThan(0);
      expect(createCall.data.burst_billable).toBe(0);
    });

    it('should use burst billing when reserve exhausted', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({});

      await writeLedgerEntry({
        tenant_id: 'tenant_no_reserve',
        action_type: 'classify_hts',
        tenant_reserve_balance: 0,
      });

      const createCall = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0];
      expect(createCall.data.reserve_allocated).toBe(0);
      expect(createCall.data.burst_billable).toBeGreaterThan(0);
    });
  });

  describe('SLA Tracking', () => {
    it('should mark sla_met=true when confidence >= 0.95', async () => {
      (prisma.agentActionLedger.update as jest.Mock).mockResolvedValue({});

      await updateLedgerEntry('action_sla_met_123', {
        outcome_type: 'success',
        confidence_score: 0.98,
        sla_met: true,
      });

      const updateCall = (prisma.agentActionLedger.update as jest.Mock).mock.calls[0][0];
      expect(updateCall.data.sla_met).toBe(true);
    });

    it('should mark sla_met=false when confidence < 0.95', async () => {
      (prisma.agentActionLedger.update as jest.Mock).mockResolvedValue({});

      await updateLedgerEntry('action_sla_not_met_123', {
        outcome_type: 'success',
        confidence_score: 0.87,
        sla_met: false,
      });

      const updateCall = (prisma.agentActionLedger.update as jest.Mock).mock.calls[0][0];
      expect(updateCall.data.sla_met).toBe(false);
    });

    it('should always set sla_met=false on failure', async () => {
      (prisma.agentActionLedger.update as jest.Mock).mockResolvedValue({});

      await updateLedgerEntry('action_failure_sla_123', {
        outcome_type: 'failure',
        sla_met: false,
      });

      const updateCall = (prisma.agentActionLedger.update as jest.Mock).mock.calls[0][0];
      expect(updateCall.data.sla_met).toBe(false);
    });
  });

  describe('Metadata Fields', () => {
    it('should accept optional metadata field', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({});

      await writeLedgerEntry({
        tenant_id: 'tenant_456',
        action_type: 'classify_hts',
        metadata: {
          commodity_description: "Men's cotton trousers",
          hts_chapter: '62',
        },
      });

      const createCall = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0];
      expect(createCall.data.metadata).toEqual({
        commodity_description: "Men's cotton trousers",
        hts_chapter: '62',
      });
    });

    it('should link to related entities', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({});

      await writeLedgerEntry({
        tenant_id: 'tenant_456',
        action_type: 'classify_hts',
        related_entity_type: 'shipment',
        related_entity_id: 'shipment_789',
      });

      const createCall = (prisma.agentActionLedger.create as jest.Mock).mock.calls[0][0];
      expect(createCall.data.related_entity_type).toBe('shipment');
      expect(createCall.data.related_entity_id).toBe('shipment_789');
    });
  });
});
