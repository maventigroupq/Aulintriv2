/**
 * Global Test Setup
 * Aulintri v2.0 - Sprint 1
 *
 * Runs before all tests to configure mocks and test environment
 */

const prismaState = {
  currentTenantId: null as string | null,
  shipments: [] as Array<Record<string, any>>,
  ledger: [] as Array<Record<string, any>>,
  threats: [] as Array<Record<string, any>>,
};

function composeSql(strings: TemplateStringsArray | string[], values: unknown[]) {
  return strings.reduce((sql, part, index) => {
    const value = index < values.length ? String(values[index]) : '';
    return `${sql}${part}${value}`;
  }, '');
}

const prisma = {
  $connect: jest.fn(),
  $disconnect: jest.fn(),
  $queryRaw: jest.fn(),
  $executeRaw: jest.fn(),
  agentActionLedger: {
    create: jest.fn(),
    update: jest.fn(),
    findMany: jest.fn(),
    findUnique: jest.fn(),
  },
  shipment: {
    create: jest.fn(),
    findMany: jest.fn(),
    findUnique: jest.fn(),
  },
  tenant: {
    create: jest.fn(),
    findUnique: jest.fn(),
  },
  threatEvent: {
    create: jest.fn(),
    findMany: jest.fn(),
  },
};

function resetPrismaState() {
  prismaState.currentTenantId = null;
  prismaState.shipments = [
    { id: 'shipment_a_1', tenant_id: 'tenant_a' },
    { id: 'shipment_b_1', tenant_id: 'tenant_b' },
    { id: 'shipment_test_1', tenant_id: 'tenant_test_123' },
  ];
  prismaState.ledger = [];
  prismaState.threats = [];
}

function installPrismaDefaults() {
  prisma.$connect.mockReset().mockResolvedValue(undefined);
  prisma.$disconnect.mockReset().mockResolvedValue(undefined);

  prisma.$queryRaw.mockReset().mockImplementation(async (strings: TemplateStringsArray, ...values: unknown[]) => {
    const sql = composeSql(strings, values);
    if (sql.includes('COUNT(*) FROM shipments')) {
      const count = prismaState.currentTenantId
        ? prismaState.shipments.filter((shipment) => shipment.tenant_id === prismaState.currentTenantId).length
        : 0;
      return [{ count }];
    }
    return [];
  });

  prisma.$executeRaw.mockReset().mockImplementation(async (strings: TemplateStringsArray, ...values: unknown[]) => {
    const sql = composeSql(strings, values);
    const match = sql.match(/SET LOCAL app\.current_tenant_id = '([^']+)'/);
    if (match) {
      prismaState.currentTenantId = match[1];
    }
    return 1;
  });

  prisma.agentActionLedger.create.mockReset().mockImplementation(async ({ data }: { data: Record<string, any> }) => {
    const record = {
      ...data,
      action_id: data.action_id ?? `action_${prismaState.ledger.length + 1}`,
      tenant_id: data.tenant_id ?? prismaState.currentTenantId,
    };
    prismaState.ledger.push(record);
    return record;
  });

  prisma.agentActionLedger.update.mockReset().mockImplementation(async ({ where, data }: { where: Record<string, any>; data: Record<string, any> }) => {
    const index = prismaState.ledger.findIndex((entry) => entry.action_id === where.action_id);
    if (index >= 0) {
      prismaState.ledger[index] = { ...prismaState.ledger[index], ...data };
      return prismaState.ledger[index];
    }
    return { action_id: where.action_id, ...data };
  });

  prisma.agentActionLedger.findMany.mockReset().mockImplementation(async () => (
    prismaState.currentTenantId
      ? prismaState.ledger.filter((entry) => entry.tenant_id === prismaState.currentTenantId)
      : []
  ));

  prisma.agentActionLedger.findUnique.mockReset().mockImplementation(async ({ where }: { where: Record<string, any> }) => (
    prismaState.ledger.find((entry) => entry.action_id === where.action_id || entry.id === where.id) ?? null
  ));

  prisma.shipment.create.mockReset().mockImplementation(async ({ data }: { data: Record<string, any> }) => {
    const shipment = { ...data, tenant_id: data.tenant_id ?? prismaState.currentTenantId };
    prismaState.shipments.push(shipment);
    return shipment;
  });

  prisma.shipment.findMany.mockReset().mockImplementation(async () => (
    prismaState.currentTenantId
      ? prismaState.shipments.filter((shipment) => shipment.tenant_id === prismaState.currentTenantId)
      : []
  ));

  prisma.shipment.findUnique.mockReset().mockResolvedValue(null);
  prisma.tenant.create.mockReset().mockImplementation(async ({ data }: { data: Record<string, any> }) => data);
  prisma.tenant.findUnique.mockReset().mockResolvedValue(null);

  prisma.threatEvent.create.mockReset().mockImplementation(async ({ data }: { data: Record<string, any> }) => {
    const threat = {
      ...data,
      source_tenant_id: data.source_tenant_id ?? prismaState.currentTenantId,
    };
    prismaState.threats.push(threat);
    return threat;
  });

  prisma.threatEvent.findMany.mockReset().mockImplementation(async ({ where }: { where?: Record<string, any> } = {}) => {
    return prismaState.threats.filter((threat) => {
      const sameTenant = threat.source_tenant_id === prismaState.currentTenantId;
      const visibleCrossTenant = threat.anonymization_status === 'cleared' && threat.shared === true;
      const visible = sameTenant || visibleCrossTenant;
      if (!visible) {
        return false;
      }
      if (!where) {
        return true;
      }
      return Object.entries(where).every(([key, value]) => threat[key] === value);
    });
  });
}

jest.mock('@/db/prisma', () => ({
  prisma,
}));

// Mock Redis client
jest.mock('ioredis', () => {
  return jest.fn().mockImplementation(() => ({
    get: jest.fn(),
    set: jest.fn(),
    hgetall: jest.fn(),
    hset: jest.fn(),
    publish: jest.fn(),
    subscribe: jest.fn(),
    on: jest.fn(),
    del: jest.fn(),
    expire: jest.fn(),
  }));
});

// Mock AWS SDK
jest.mock('@aws-sdk/client-s3', () => ({
  S3Client: jest.fn().mockImplementation(() => ({})),
  GetObjectCommand: jest.fn(),
  PutObjectCommand: jest.fn(),
}), { virtual: true });

jest.mock('@aws-sdk/client-secrets-manager', () => ({
  SecretsManagerClient: jest.fn().mockImplementation(() => ({})),
  GetSecretValueCommand: jest.fn(),
}), { virtual: true });

// Set test environment variables
process.env.NODE_ENV = 'test';
process.env.DATABASE_URL = 'postgresql://test:test@localhost:5432/aulintri_test';
process.env.REDIS_HOST = 'localhost';
process.env.REDIS_PORT = '6379';
process.env.AWS_REGION = 'us-east-1';
process.env.COGNITO_USER_POOL_ID = 'us-east-1_TEST';
process.env.LOG_LEVEL = 'error'; // Suppress logs during tests

// Global test timeout
jest.setTimeout(10000);

beforeEach(() => {
  resetPrismaState();
  installPrismaDefaults();
  const s3 = require('@aws-sdk/client-s3');
  s3.GetObjectCommand.mockReset().mockImplementation(() => ({}));
  s3.PutObjectCommand.mockReset().mockImplementation(() => ({}));
});
