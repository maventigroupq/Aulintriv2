/**
 * Get Carrier Safety Score Tool - Integration Tests
 * Sprint 1: Tests stub implementation with FMCSA data
 */

import request from 'supertest';
import { app } from '@/index';
import { prisma } from '@/db/prisma';

describe('get_carrier_safety_score MCP Tool', () => {
  const mockTenantId = 'tenant_test_123';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Tool Registration', () => {
    it('should be registered in MCP tools/list', async () => {
      const response = await request(app)
        .post('/mcp')
        .send({
          jsonrpc: '2.0',
          method: 'tools/list',
          id: 1,
        });

      const tool = response.body.result.tools.find(
        (t: any) => t.name === 'get_carrier_safety_score'
      );

      expect(tool).toBeDefined();
      expect(tool.inputSchema.required).toContain('dot_number');
    });
  });

  describe('Input Validation', () => {
    it('should validate DOT number format (6-8 digits)', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '123', // Too short
            },
          },
          id: 2,
        });

      expect(response.status).toBe(400);
      expect(response.body.error.code).toBe('INVALID_PARAMS');
    });

    it('should reject non-numeric DOT numbers', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: 'ABC123',
            },
          },
          id: 3,
        });

      expect(response.status).toBe(400);
    });

    it('should accept valid DOT number', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '1234567',
            },
          },
          id: 4,
        });

      expect(response.status).toBe(200);
      expect(response.body.result).toBeDefined();
    });
  });

  describe('Safety Score Result', () => {
    it('should return overall safety score (0-100)', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_score_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '1234567',
            },
          },
          id: 5,
        });

      expect(response.body.result.data.safety_score).toBeGreaterThanOrEqual(0);
      expect(response.body.result.data.safety_score).toBeLessThanOrEqual(100);
    });

    it('should include FMCSA rating', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_rating_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '1234567',
            },
          },
          id: 6,
        });

      expect(response.body.result.data.fmcsa_rating).toMatch(
        /^(Satisfactory|Conditional|Unsatisfactory)$/
      );
    });

    it('should include out-of-service rate', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_oos_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '1234567',
            },
          },
          id: 7,
        });

      expect(response.body.result.data.oos_rate_percent).toBeGreaterThanOrEqual(0);
      expect(response.body.result.data.oos_rate_percent).toBeLessThanOrEqual(100);
    });

    it('should include recommendation', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_recommendation_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '1234567',
            },
          },
          id: 8,
        });

      expect(response.body.result.data.recommendation).toMatch(
        /^(approved|conditional_approval|rejected)$/
      );
    });
  });

  describe('Crash History (Optional)', () => {
    it('should include crash history when requested', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_crash_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '1234567',
              include_crash_history: true,
            },
          },
          id: 9,
        });

      expect(response.body.result.data.crash_history).toBeDefined();
      expect(response.body.result.data.crash_history).toHaveProperty('total_crashes');
      expect(response.body.result.data.crash_history).toHaveProperty('fatal_crashes');
    });

    it('should omit crash history when not requested', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_no_crash_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '1234567',
              include_crash_history: false,
            },
          },
          id: 10,
        });

      expect(response.body.result.data.crash_history).toBeUndefined();
    });
  });

  describe('Insurance Verification', () => {
    it('should include insurance status', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_insurance_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '1234567',
            },
          },
          id: 11,
        });

      expect(response.body.result.data).toHaveProperty('insurance_verified');
      expect(typeof response.body.result.data.insurance_verified).toBe('boolean');
    });
  });

  describe('Recommendation Logic', () => {
    it('should approve carriers with Satisfactory rating and low OOS rate', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_approve_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_safety_score',
            arguments: {
              dot_number: '2000000', // Stub returns Satisfactory
            },
          },
          id: 12,
        });

      if (response.body.result.data.fmcsa_rating === 'Satisfactory' &&
          response.body.result.data.oos_rate_percent < 10) {
        expect(response.body.result.data.recommendation).toBe('approved');
      }
    });
  });
});
