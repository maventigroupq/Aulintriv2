/**
 * Extract RFQ Data Tool - Integration Tests
 * Sprint 1: Tests stub implementation with ledger integration
 */

import request from 'supertest';
import { app } from '@/index';
import { prisma } from '@/db/prisma';

describe('extract_rfq_data MCP Tool', () => {
  const mockTenantId = 'tenant_test_123';
  const mockUserId = 'user_test_456';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Tool Registration', () => {
    it('should be registered in MCP tools/list', async () => {
      const response = await request(app)
        .post('/mcp')
        .send({
          jsonrpc: '2.0',
          method: 'tools/list',
          id: 1,
        });

      expect(response.status).toBe(200);
      expect(response.body.result.tools).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            name: 'extract_rfq_data',
            description: expect.any(String),
            inputSchema: expect.objectContaining({
              type: 'object',
              properties: expect.objectContaining({
                document_s3_key: expect.any(Object),
              }),
            }),
          }),
        ])
      );
    });
  });

  describe('Input Validation', () => {
    it('should reject missing document_s3_key', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'extract_rfq_data',
            arguments: {},
          },
          id: 2,
        });

      expect(response.status).toBe(400);
      expect(response.body.error).toMatchObject({
        code: 'INVALID_PARAMS',
        message: expect.stringContaining('document_s3_key'),
      });
    });

    it('should reject invalid document_s3_key format', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'extract_rfq_data',
            arguments: {
              document_s3_key: 'invalid-format.exe', // Must be pdf/png/jpg
            },
          },
          id: 3,
        });

      expect(response.status).toBe(400);
      expect(response.body.error.code).toBe('INVALID_PARAMS');
    });

    it('should accept valid document_s3_key', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'extract_rfq_data',
            arguments: {
              document_s3_key: 'rfq/tenant123/doc456.pdf',
            },
          },
          id: 4,
        });

      expect(response.status).toBe(200);
      expect(response.body.result).toBeDefined();
    });
  });

  describe('Ledger Integration', () => {
    it('should write ledger entry BEFORE execution', async () => {
      const createSpy = jest.spyOn(prisma.agentActionLedger, 'create');

      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_pre_exec_123',
      });

      await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'extract_rfq_data',
            arguments: {
              document_s3_key: 'rfq/tenant123/doc456.pdf',
            },
          },
          id: 5,
        });

      expect(createSpy).toHaveBeenCalledWith({
        data: expect.objectContaining({
          tenant_id: mockTenantId,
          action_type: 'extract_rfq',
          outcome_type: 'pending',
          sla_met: false,
          confidence_score: 0,
        }),
      });
    });

    it('should update ledger entry AFTER execution', async () => {
      const updateSpy = jest.spyOn(prisma.agentActionLedger, 'update');

      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_post_exec_123',
      });

      await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'extract_rfq_data',
            arguments: {
              document_s3_key: 'rfq/tenant123/doc456.pdf',
            },
          },
          id: 6,
        });

      expect(updateSpy).toHaveBeenCalledWith({
        where: { action_id: 'action_post_exec_123' },
        data: expect.objectContaining({
          outcome_type: 'success',
          sla_met: true,
          confidence_score: expect.any(Number),
        }),
      });
    });

    it('should update ledger on failure', async () => {
      const updateSpy = jest.spyOn(prisma.agentActionLedger, 'update');

      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_failure_123',
      });

      // Simulate S3 error
      jest.spyOn(require('@aws-sdk/client-s3'), 'GetObjectCommand')
        .mockImplementation(() => {
          throw new Error('S3 bucket not found');
        });

      await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'extract_rfq_data',
            arguments: {
              document_s3_key: 'rfq/nonexistent/doc.pdf',
            },
          },
          id: 7,
        });

      expect(updateSpy).toHaveBeenCalledWith({
        where: { action_id: 'action_failure_123' },
        data: expect.objectContaining({
          outcome_type: 'failure',
          sla_met: false,
          error_message: expect.stringContaining('S3'),
        }),
      });
    });
  });

  describe('Stub Implementation (Sprint 1)', () => {
    it('should return mock extraction data', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_stub_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'extract_rfq_data',
            arguments: {
              document_s3_key: 'rfq/tenant123/doc456.pdf',
            },
          },
          id: 8,
        });

      expect(response.status).toBe(200);
      expect(response.body.result.data).toMatchObject({
        shipper: expect.objectContaining({
          name: expect.any(String),
          address: expect.any(Object),
        }),
        consignee: expect.objectContaining({
          name: expect.any(String),
          address: expect.any(Object),
        }),
        commodity_items: expect.arrayContaining([
          expect.objectContaining({
            description: expect.any(String),
            quantity: expect.any(Number),
          }),
        ]),
      });

      expect(response.body.result.metadata.confidence_score).toBeGreaterThan(0.9);
    });
  });
});
