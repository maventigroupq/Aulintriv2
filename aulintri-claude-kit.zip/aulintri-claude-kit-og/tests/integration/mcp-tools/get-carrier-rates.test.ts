/**
 * Get Carrier Rates Tool - Integration Tests
 * Sprint 1: Tests stub implementation with multi-carrier aggregation
 */

import request from 'supertest';
import { app } from '@/index';
import { prisma } from '@/db/prisma';

describe('get_carrier_rates MCP Tool', () => {
  const mockTenantId = 'tenant_test_123';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Tool Registration', () => {
    it('should be registered in MCP tools/list', async () => {
      const response = await request(app)
        .post('/mcp')
        .send({
          jsonrpc: '2.0',
          method: 'tools/list',
          id: 1,
        });

      const tool = response.body.result.tools.find(
        (t: any) => t.name === 'get_carrier_rates'
      );

      expect(tool).toBeDefined();
      expect(tool.inputSchema.required).toContain('origin_port');
      expect(tool.inputSchema.required).toContain('destination_port');
      expect(tool.inputSchema.required).toContain('container_type');
      expect(tool.inputSchema.required).toContain('cargo_ready_date');
    });
  });

  describe('Input Validation', () => {
    it('should validate UN/LOCODE format for origin_port', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'SHANGHAI', // Should be CNSHA
              destination_port: 'USLAX',
              container_type: '40GP',
              cargo_ready_date: '2026-04-01',
            },
          },
          id: 2,
        });

      expect(response.status).toBe(400);
      expect(response.body.error.code).toBe('INVALID_PARAMS');
    });

    it('should validate container_type enum', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: 'INVALID',
              cargo_ready_date: '2026-04-01',
            },
          },
          id: 3,
        });

      expect(response.status).toBe(400);
      expect(response.body.error.message).toContain('container_type');
    });

    it('should validate cargo_ready_date format (ISO 8601)', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: '40GP',
              cargo_ready_date: '04/01/2026', // Wrong format
            },
          },
          id: 4,
        });

      expect(response.status).toBe(400);
    });

    it('should accept valid inputs', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: '40GP',
              cargo_ready_date: '2026-04-01',
            },
          },
          id: 5,
        });

      expect(response.status).toBe(200);
      expect(response.body.result).toBeDefined();
    });
  });

  describe('Rate Aggregation', () => {
    it('should return multiple rate options', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_rates_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: '40GP',
              cargo_ready_date: '2026-04-01',
            },
          },
          id: 6,
        });

      expect(response.body.result.data.rate_options).toBeDefined();
      expect(Array.isArray(response.body.result.data.rate_options)).toBe(true);
      expect(response.body.result.data.rate_options.length).toBeGreaterThan(0);
    });

    it('should include carrier name and SCAC code', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_carrier_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: '40GP',
              cargo_ready_date: '2026-04-01',
            },
          },
          id: 7,
        });

      const firstRate = response.body.result.data.rate_options[0];
      expect(firstRate).toHaveProperty('carrier_name');
      expect(firstRate).toHaveProperty('scac_code');
      expect(firstRate.scac_code).toMatch(/^[A-Z]{4}$/);
    });

    it('should include rate breakdown (base + surcharges)', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_breakdown_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: '40GP',
              cargo_ready_date: '2026-04-01',
            },
          },
          id: 8,
        });

      const firstRate = response.body.result.data.rate_options[0];
      expect(firstRate).toHaveProperty('base_rate_usd');
      expect(firstRate).toHaveProperty('surcharges');
      expect(firstRate).toHaveProperty('total_rate_usd');
    });

    it('should include transit time estimate', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_transit_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: '40GP',
              cargo_ready_date: '2026-04-01',
            },
          },
          id: 9,
        });

      const firstRate = response.body.result.data.rate_options[0];
      expect(firstRate).toHaveProperty('transit_days');
      expect(firstRate.transit_days).toBeGreaterThan(0);
    });

    it('should sort rates by total cost (ascending)', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_sort_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: '40GP',
              cargo_ready_date: '2026-04-01',
            },
          },
          id: 10,
        });

      const rates = response.body.result.data.rate_options;
      for (let i = 1; i < rates.length; i++) {
        expect(rates[i].total_rate_usd).toBeGreaterThanOrEqual(
          rates[i - 1].total_rate_usd
        );
      }
    });
  });

  describe('Optional Parameters', () => {
    it('should accept commodity_class parameter', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_commodity_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: 'LCL',
              cargo_ready_date: '2026-04-01',
              commodity_class: 'hazmat',
            },
          },
          id: 11,
        });

      expect(response.status).toBe(200);
    });

    it('should accept preferred_carriers array', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_preferred_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'get_carrier_rates',
            arguments: {
              origin_port: 'CNSHA',
              destination_port: 'USLAX',
              container_type: '40GP',
              cargo_ready_date: '2026-04-01',
              preferred_carriers: ['MAEU', 'MSCU'],
            },
          },
          id: 12,
        });

      expect(response.status).toBe(200);
    });
  });
});
