/**
 * Classify HTS Code Tool - Integration Tests
 * Sprint 1: Tests stub implementation with RAG and AD/CVD detection
 */

import request from 'supertest';
import { app } from '@/index';
import { prisma } from '@/db/prisma';

describe('classify_hts_code MCP Tool', () => {
  const mockTenantId = 'tenant_test_123';

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Tool Registration', () => {
    it('should be registered in MCP tools/list', async () => {
      const response = await request(app)
        .post('/mcp')
        .send({
          jsonrpc: '2.0',
          method: 'tools/list',
          id: 1,
        });

      const tool = response.body.result.tools.find(
        (t: any) => t.name === 'classify_hts_code'
      );

      expect(tool).toBeDefined();
      expect(tool.inputSchema.required).toContain('commodity_description');
      expect(tool.inputSchema.required).toContain('country_of_origin');
    });
  });

  describe('Input Validation', () => {
    it('should require commodity_description', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              country_of_origin: 'CN',
            },
          },
          id: 2,
        });

      expect(response.status).toBe(400);
      expect(response.body.error.message).toContain('commodity_description');
    });

    it('should require country_of_origin', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: 'Cotton trousers',
            },
          },
          id: 3,
        });

      expect(response.status).toBe(400);
      expect(response.body.error.message).toContain('country_of_origin');
    });

    it('should validate country_of_origin format (ISO 3166-1)', async () => {
      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: 'Cotton trousers',
              country_of_origin: 'CHINA', // Should be 'CN'
            },
          },
          id: 4,
        });

      expect(response.status).toBe(400);
      expect(response.body.error.code).toBe('INVALID_PARAMS');
    });

    it('should accept valid inputs', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: "Men's cotton trousers, size 32",
              country_of_origin: 'CN',
            },
          },
          id: 5,
        });

      expect(response.status).toBe(200);
      expect(response.body.result).toBeDefined();
    });
  });

  describe('Confidence Score Routing', () => {
    it('should return high confidence for stub classification', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_confidence_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: "Men's cotton trousers",
              country_of_origin: 'CN',
            },
          },
          id: 6,
        });

      expect(response.body.result.metadata.confidence_score).toBeGreaterThan(0.97);
    });

    it('should flag classifications >= 0.97 for fast-path review', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_fastpath_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: "Men's cotton trousers",
              country_of_origin: 'VN',
            },
          },
          id: 7,
        });

      expect(response.body.result.metadata.sla_met).toBe(true);
      expect(response.body.result.metadata.confidence_score).toBeGreaterThanOrEqual(0.97);
    });
  });

  describe('HTS Classification Result', () => {
    it('should return 10-digit HTS code', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_hts_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: "Men's cotton trousers",
              country_of_origin: 'CN',
            },
          },
          id: 8,
        });

      expect(response.body.result.data.hts_code).toMatch(/^\d{10}$/);
    });

    it('should include duty rate', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_duty_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: "Men's cotton trousers",
              country_of_origin: 'CN',
            },
          },
          id: 9,
        });

      expect(response.body.result.data.duty_rate_percent).toBeGreaterThanOrEqual(0);
    });

    it('should detect AD/CVD applicability', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_adcvd_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: 'Steel pipe',
              country_of_origin: 'CN',
            },
          },
          id: 10,
        });

      expect(response.body.result.data).toHaveProperty('ad_cvd_applicable');
    });

    it('should identify PGA requirements', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_pga_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: 'Fresh apples for consumption',
              country_of_origin: 'NZ',
            },
          },
          id: 11,
        });

      expect(response.body.result.data.pga_requirements).toBeDefined();
      expect(Array.isArray(response.body.result.data.pga_requirements)).toBe(true);
    });
  });

  describe('Prior Classifications Support', () => {
    it('should accept prior_classifications array', async () => {
      (prisma.agentActionLedger.create as jest.Mock).mockResolvedValue({
        action_id: 'action_prior_123',
      });

      const response = await request(app)
        .post('/mcp')
        .set('Authorization', `Bearer mock_token_${mockTenantId}`)
        .send({
          jsonrpc: '2.0',
          method: 'tools/call',
          params: {
            name: 'classify_hts_code',
            arguments: {
              commodity_description: "Men's cotton trousers",
              country_of_origin: 'CN',
              prior_classifications: [
                {
                  hts_code: '6203424060',
                  commodity_description: "Men's cotton pants",
                  confidence_score: 0.98,
                },
              ],
            },
          },
          id: 12,
        });

      expect(response.status).toBe(200);
    });
  });
});
