# Deploying Aulintri to Netlify

## Quick Start (5 minutes)

### Option A: Deploy via Netlify CLI

```bash
# 1. Install Netlify CLI
npm install -g netlify-cli

# 2. Login to Netlify
netlify login

# 3. Initialize Netlify site
cd /Users/minhnguyen/Downloads/aulintri_inDownloads/aulintri-claude-kit
netlify init

# 4. Deploy
netlify deploy --prod
```

### Option B: Deploy via Git (Recommended)

1. **Push to GitHub:**
   ```bash
   cd /Users/minhnguyen/Downloads/aulintri_inDownloads/aulintri-claude-kit
   git init
   git add .
   git commit -m "Initial commit: Aulintri v2.0"
   git remote add origin https://github.com/YOUR_USERNAME/aulintri-claude-kit.git
   git push -u origin main
   ```

2. **Connect to Netlify:**
   - Go to https://app.netlify.com/
   - Click "Add new site" → "Import an existing project"
   - Choose GitHub → Select your repository
   - Build settings are auto-detected from `netlify.toml`
   - Click "Deploy site"

---

## Configuration

### Environment Variables (Set in Netlify UI)

Go to **Site Settings → Environment Variables** and add:

```bash
# Backend API URL (if using external backend)
NEXT_PUBLIC_API_URL=https://your-backend-url.com

# MCP Server URL
NEXT_PUBLIC_MCP_URL=https://your-backend-url.com/mcp

# Database URL (if using Netlify Functions)
DATABASE_URL=postgresql://user:pass@your-db-host:5432/aulintri

# Redis URL (if using Netlify Functions)
REDIS_URL=redis://default:password@your-redis-host:6379

# Claude API Key (for Netlify Functions)
CLAUDE_API_KEY=sk-ant-xxxxxxxxxxxxx

# AWS Region
AWS_REGION=us-east-1

# Node environment
NODE_ENV=production
```

---

## Architecture Options

### Option 1: Frontend-Only (Simplest)

**What's deployed to Netlify:**
- Next.js frontend (Quote Dashboard UI)
- Static assets

**What's deployed elsewhere:**
- MCP Server → AWS Lambda
- RAG Workers → AWS Lambda
- Database → Neon/Supabase
- Redis → Upstash

**Pros:** Fast, simple, Netlify's strength
**Cons:** Need separate backend deployment

---

### Option 2: Netlify Functions (Hybrid)

**What's deployed to Netlify:**
- Next.js frontend
- Netlify Functions (serverless endpoints)

**What's deployed elsewhere:**
- Database → Neon/Supabase (free tier: 0.5GB)
- Redis → Upstash (free tier: 10K commands/day)

**Setup:**

1. **Create Netlify Functions directory:**
   ```bash
   mkdir -p netlify/functions
   ```

2. **Create MCP endpoint:**
   ```typescript
   // netlify/functions/mcp.ts
   import { Handler } from '@netlify/functions';
   import { mcpServer } from '../../src/mcp/server';

   export const handler: Handler = async (event, context) => {
     if (event.httpMethod !== 'POST') {
       return { statusCode: 405, body: 'Method Not Allowed' };
     }

     const body = JSON.parse(event.body || '{}');
     const result = await mcpServer.handleRequest(body);

     return {
       statusCode: 200,
       headers: { 'Content-Type': 'application/json' },
       body: JSON.stringify(result),
     };
   };
   ```

3. **Update `netlify.toml`:**
   ```toml
   [functions]
     directory = "netlify/functions"
     node_bundler = "esbuild"
   ```

**Limitations:**
- Netlify Functions timeout: 10s (not suitable for long-running tasks like RAG ingestion)
- Cold starts: 1-3s (may affect user experience)
- No persistent connections (Redis/Prisma connection pooling limited)

---

## Recommended Setup (Production-Ready)

### Frontend: Netlify
- Next.js Quote Dashboard
- Storybook documentation
- Static assets

### Backend: Railway (or AWS Lambda)
- MCP Server (Fastify)
- RAG Workers
- Quote Agent
- AOS orchestration

### Database: Neon PostgreSQL
- Free tier: 0.5GB storage
- Built-in pgvector support
- Connection pooling
- Auto-pause on inactivity

### Cache: Upstash Redis
- Free tier: 10K commands/day
- Global edge network
- Persistent storage

---

## Step-by-Step: Full Stack Deployment

### 1. Deploy Database (Neon)

```bash
# Sign up at https://neon.tech
# Create new project: "aulintri-production"
# Copy connection string

# Run migrations
DATABASE_URL="postgresql://user:pass@your-neon-host/aulintri?sslmode=require" \
  npx prisma migrate deploy

# Generate Prisma client
npx prisma generate
```

### 2. Deploy Redis (Upstash)

```bash
# Sign up at https://upstash.com
# Create new database: "aulintri-redis"
# Copy connection string (starts with rediss://)
```

### 3. Deploy Backend (Railway)

```bash
# Sign up at https://railway.app
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Initialize project
railway init

# Set environment variables
railway variables set DATABASE_URL="postgresql://..."
railway variables set REDIS_URL="rediss://..."
railway variables set CLAUDE_API_KEY="sk-ant-..."

# Deploy
railway up

# Get deployment URL
railway domain
# Example: https://aulintri-backend.up.railway.app
```

### 4. Deploy Frontend (Netlify)

```bash
# Set environment variable in Netlify UI
NEXT_PUBLIC_API_URL=https://aulintri-backend.up.railway.app
NEXT_PUBLIC_MCP_URL=https://aulintri-backend.up.railway.app/mcp

# Deploy via Git or CLI
netlify deploy --prod
```

---

## Post-Deployment Checklist

### Verify Frontend
- [ ] Visit your Netlify URL (e.g., https://aulintri.netlify.app)
- [ ] Check Quote Dashboard renders
- [ ] Verify no console errors

### Verify Backend (if separate)
- [ ] Test MCP endpoint:
  ```bash
  curl -X POST https://your-backend-url.com/mcp \
    -H "Content-Type: application/json" \
    -d '{"jsonrpc":"2.0","method":"tools/list","id":1}'
  ```
- [ ] Should return list of 5 MCP tools

### Verify Database
- [ ] Check Prisma connection:
  ```bash
  DATABASE_URL="your-connection-string" npx prisma studio
  ```
- [ ] Verify tables exist: `agent_action_ledger`, `rag_documents`, etc.

### Verify Redis
- [ ] Test connection:
  ```bash
  redis-cli -u "your-redis-url" PING
  ```
- [ ] Should return `PONG`

---

## Cost Estimates (Monthly)

### Free Tier (Development)
- **Netlify:** Free (100GB bandwidth)
- **Neon:** Free (0.5GB storage, 1GB transfer)
- **Upstash:** Free (10K commands/day)
- **Railway:** $5 credit/month (enough for low traffic)
- **TOTAL:** ~$5/month

### Production (5,000 quotes/month)
- **Netlify:** $19/month (Pro plan for team features)
- **Neon:** $19/month (Scale plan, 10GB storage)
- **Upstash:** $30/month (25K commands/day)
- **Railway:** $20/month (2GB RAM, always-on)
- **Claude API:** $150/month (5,000 classifications)
- **Carrier APIs:** $300/month (combined)
- **TOTAL:** $538/month

---

## Troubleshooting

### Build fails on Netlify

**Error:** `Cannot find module 'next'`
**Fix:**
```bash
# Clear Netlify cache
netlify build --clear-cache

# Or in Netlify UI: Site Settings → Build & Deploy → Clear Cache
```

**Error:** `Prisma Client not generated`
**Fix:** Add to `package.json`:
```json
{
  "scripts": {
    "build": "prisma generate && next build && tsc -p tsconfig.server.json",
    "postinstall": "prisma generate"
  }
}
```

### Frontend can't connect to backend

**Error:** `CORS policy: No 'Access-Control-Allow-Origin' header`
**Fix:** Add to backend (Fastify server):
```typescript
import cors from '@fastify/cors';

await fastify.register(cors, {
  origin: [
    'https://your-netlify-site.netlify.app',
    'https://your-custom-domain.com'
  ]
});
```

### Database connection fails

**Error:** `P1001: Can't reach database server`
**Fix:**
- Verify connection string includes `?sslmode=require` for Neon
- Check IP allowlist in database settings (Neon allows all by default)
- Test connection locally first:
  ```bash
  DATABASE_URL="your-string" npx prisma db pull
  ```

---

## Custom Domain Setup

### 1. Add domain in Netlify
- Site Settings → Domain Management → Add domain
- Enter your domain (e.g., `aulintri.com`)

### 2. Configure DNS
Add these records to your DNS provider:

```
Type    Name    Value
A       @       75.2.60.5
CNAME   www     your-site.netlify.app
```

### 3. Enable HTTPS
- Netlify automatically provisions Let's Encrypt SSL
- Wait 1-2 minutes for DNS propagation
- HTTPS will be enabled automatically

---

## Next Steps

After successful deployment:

1. **Set up monitoring:**
   - Netlify Analytics (built-in)
   - Sentry for error tracking
   - Uptime monitoring (UptimeRobot free tier)

2. **Configure alerts:**
   - Build failure notifications (Netlify → Slack)
   - Error alerts (Sentry → Email)
   - Cost alerts (Railway → Email at 80% budget)

3. **Enable CI/CD:**
   - Automated tests on PR (GitHub Actions)
   - Preview deployments (Netlify feature)
   - Staging environment (Railway branch deployment)

4. **Invite beta customers:**
   - 5 customers as planned in Sprint 4
   - Share Netlify URL + credentials
   - Collect feedback via Typeform

---

## Support

**Netlify Support:**
- Docs: https://docs.netlify.com
- Forum: https://answers.netlify.com
- Status: https://www.netlifystatus.com

**Railway Support:**
- Docs: https://docs.railway.app
- Discord: https://discord.gg/railway
- Status: https://railway.app/status

**Neon Support:**
- Docs: https://neon.tech/docs
- Discord: https://discord.gg/neon
- Status: https://neon.tech/status

---

**Deployment Status:** Ready to deploy ✅
**Estimated Time:** 30 minutes (full stack)
**Difficulty:** Intermediate

Good luck! 🚀
