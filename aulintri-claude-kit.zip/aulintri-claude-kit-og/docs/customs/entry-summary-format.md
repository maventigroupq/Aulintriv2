# Entry Summary Format (CBP Form 7501)

## Overview
The Entry Summary (CBP Form 7501) is the formal customs declaration for imported merchandise. It must be filed within **10 working days** of cargo release.

**Legal Authority:** 19 CFR § 142

## Entry Types

| Code | Description | Use Case |
|------|-------------|----------|
| 01 | Consumption Entry | Standard import for immediate sale |
| 03 | Warehouse Entry | Storage in bonded warehouse |
| 06 | Foreign Trade Zone (FTZ) | Entry into FTZ |
| 11 | Quota/Visa | Goods subject to quota restrictions |
| 23 | Temporary Import Bond (TIB) | Temporary admission, re-export required |
| 52 | Reconciliation | Post-entry duty adjustments |

**Sprint 1 Focus:** Type 01 (Consumption Entry) only

## Required Header Fields

### Block 1: Entry Information
- Entry Number (11 digits): `XXX-XXXXXXX-X` (port-entry-check)
- Entry Type Code: `01`
- Entry Date: Date filed with CBP
- Port of Entry: 4-digit port code (e.g., `2704` = Los Angeles)

### Block 2: Party Information
- Importer of Record (IOR) Number: IRS/EIN
- Consignee Number: IRS/EIN
- Filer Code: Customs broker filer code (3 digits)

### Block 3: Bond Information
- Surety Code: Customs bond surety company
- Bond Type: Usually `8` (Single Transaction) or `9` (Continuous)

### Block 4: Transportation Details
- Carrier Code (SCAC): 4-letter code
- Vessel/Flight Name
- Voyage/Trip Number
- Arrival Date

## Line Item Structure

Each commodity requires:

### Block 5: Commodity Description
- Line Number (sequential)
- HTS Code (10 digits): `XXXX.XX.XX.XX`
- Country of Origin: ISO alpha-2 code
- Quantity & Unit of Measure
- Entered Value (USD)

### Block 6: Duty Calculation
- Duty Rate (%): From HTS schedule
- Duty Amount: `Entered Value × Duty Rate`
- MPF (Merchandise Processing Fee): `0.3464% of value` (min $27.75, max $538.40)
- HMF (Harbor Maintenance Fee): `0.125% of value`

### Block 7: Special Programs
- AD/CVD Case Number (if applicable)
- PGA Requirements (FDA, USDA, etc.)
- FTZ Status
- NAFTA/USMCA Preference Indicator

## Duty Calculation Formula

```
Total Duties = Sum of (Line Item Duties) + MPF + HMF + AD/CVD (if applicable)

Where:
- Line Duty = Entered Value × Duty Rate
- MPF = MAX(MIN(Entered Value × 0.003464, 538.40), 27.75)
- HMF = Entered Value × 0.00125
```

## Sample Entry (Sprint 1 Test Data)

```
Entry Number: 270-4567890-1
Entry Type: 01
Port: 2704 (Los Angeles)
IOR: 12-3456789
Filer Code: XXX

Line 1:
  HTS: 6203.42.40.60
  Description: Men's cotton trousers
  Origin: CN
  Quantity: 1000 DZN
  Value: $12,500.00
  Duty Rate: 16.5%
  Duty: $2,062.50

Line 2:
  HTS: 6206.30.30.10
  Description: Women's cotton blouses
  Origin: CN
  Quantity: 800 DZN
  Value: $9,600.00
  Duty Rate: 19.7%
  Duty: $1,891.20

Totals:
  Total Value: $22,100.00
  Total Duty: $3,953.70
  MPF: $76.55
  HMF: $27.63
  GRAND TOTAL: $4,057.88
```

## CATAIR Message Format

Entry filed via ABI using CATAIR Entry Type `01`:

```
ISA*00*          *00*          *ZZ*BROKERCODE     *ZZ*CBPCODE        *YYMMDD*HHMM*U*00401*000000001*0*P*>~
GS*IM*BROKERCODE*CBPCODE*YYYYMMDD*HHMM*1*X*004010~
ST*350*0001~
M10*270*4567890*1*01*YYYYMMDD~
M11*12-3456789*IOR NAME*ADDRESS~
...
SE*50*0001~
GE*1*1~
IEA*1*000000001~
```

## Aulintri Implementation (Sprint 7)

### MCP Tool: `draft_entry_summary`

**Confidence Routing:**
- Confidence >= 0.97 + no FAN flags → BLC 30-second fast-path review
- Confidence < 0.97 OR FAN flag → Full BLC review with agent explanation

**Pre-execution Ledger Write:**
```typescript
{
  action_type: 'draft_entry',
  reserve_allocated: 0.45, // $0.45 per entry draft
  outcome_type: 'pending',
}
```

## References

- 19 CFR § 142 - Entry of Merchandise
- CBP Form 7501 Instructions
- CATAIR Entry Type 01 Specification
