# ISF 10+2 Requirements

## Overview

The Importer Security Filing (ISF), also known as "10+2", is a CBP requirement mandating the electronic submission of import data **24 hours before cargo is loaded** onto a vessel bound for the United States.

**Legal Authority:** 19 CFR § 149

## The 10 Importer Data Elements

Must be submitted by **Importer of Record** (or authorized agent):

### 1. Manufacturer (or Supplier) Name and Address
- Full legal name
- Complete physical address (no P.O. boxes)
- For multiple manufacturers: list all

### 2. Seller Name and Address
- Last known seller (may differ from manufacturer)
- Full address required

### 3. Buyer Name and Address
- First known buyer in the U.S.
- May be different from consignee

### 4. Ship-to Name and Address
- Final delivery location
- Can be warehouse, distribution center, or customer

### 5. Container Stuffing Location
- Physical address where container was loaded
- Critical for CBP supply chain security

### 6. Consolidator (Stuffer) Name and Address
- Entity that stuffed the container
- May be same as manufacturer or separate logistics provider

### 7. Importer of Record Number
- IRS/EIN number
- CBP-assigned importer number

### 8. Consignee Number(s)
- IRS/EIN of consignee
- Multiple numbers if consolidation

### 9. Country of Origin
- ISO 3166-1 alpha-2 code (CN, MX, VN, etc.)
- For each commodity item

### 10. Commodity HTS-6 Code
- First 6 digits of Harmonized Tariff Schedule
- More specific than full 10-digit code

## The 2 Carrier Data Elements

Must be submitted by **Carrier**:

### 11. Vessel Stow Plan
- Container location on vessel
- Submitted by carrier at time of loading

### 12. Container Status Messages
- Equipment receipt, gate-in, loading events
- Automatic via carrier systems

## Filing Deadlines

| Shipment Type | Deadline |
|---------------|----------|
| Ocean freight (containerized) | **24 hours before loading** at foreign port |
| Ocean freight (break bulk) | **24 hours before loading** |
| Air freight | **Not required** (air cargo has different security rules) |
| Rail/Truck from Canada/Mexico | **1 hour before arrival** at border |

### Critical Timing Notes:
- "24 hours before loading" = 24 hours before cargo is loaded onto the **vessel** at origin port
- NOT 24 hours before vessel departure
- NOT 24 hours before arrival in U.S.

## Amendment Rules

ISF can be amended:
- **Before arrival:** Unlimited amendments allowed
- **After arrival:** Amendments allowed only to correct errors

**Best practice:** Submit complete ISF at initial filing to avoid delays.

## Penalties

| Violation | Penalty |
|-----------|---------|
| Late filing (< 24 hours) | Up to **$5,000 per shipment** |
| Inaccurate/incomplete data | Up to **$5,000 per shipment** |
| Failure to file | Up to **$5,000 per shipment** + potential cargo hold |
| Repeated violations | Enhanced penalties + increased CBP scrutiny |

## Exemptions

ISF **NOT required** for:
- Immediate exportation (IE) entries
- Transportation & Exportation (T&E) entries
- Foreign cargo remaining on board (FROB)
- Shipments via air, truck, or rail (domestic arrival from Canada/Mexico)
- Household goods and personal effects

## Data Quality Requirements

### Address Standards:
- No P.O. boxes (physical addresses only)
- City, state/province, postal code required
- Country code (ISO 3166-1)

### Manufacturer Identification:
- If manufacturer is unknown: "UNKNOWN" is acceptable **only if** due diligence performed
- Document due diligence attempts (emails, calls, etc.) for CBP audit

### HTS-6 Classification:
- Use best available information at time of filing
- Can be amended if classification changes before entry

## Aulintri Implementation (Sprint 7)

### MCP Tool: `submit_isf_filing`

**Input:**
```typescript
{
  shipment_id: string;
  importer_data: {
    manufacturer: { name, address },
    seller: { name, address },
    buyer: { name, address },
    ship_to: { name, address },
    container_stuffing_location: { address },
    consolidator: { name, address },
    importer_of_record_number: string,
    consignee_numbers: string[],
    country_of_origin: string[], // Per commodity
    hts_6_codes: string[], // Per commodity
  }
}
```

**Validation:**
- All 10 fields required (no nulls)
- Addresses must have city, country, postal code
- HTS-6 must match `^\d{6}$` pattern
- Country codes must be ISO 3166-1 alpha-2

**Submission:**
- Via ABI vendor (Connexion/QP/Descartes)
- ABI message type: ISF-10
- Requires customs bond on file

**Error Handling:**
- CBP rejection codes: ISF01-ISF99
- Common: ISF04 (missing data), ISF12 (invalid HTS), ISF23 (late filing)

## References

- 19 CFR § 149 - Importer Security Filing
- CBP CATAIR: ISF message format specification
- CBP ISF FAQ: https://www.cbp.gov/trade/programs-administration/entry-summary/isf

## SLA Implications

**Aulintri SLA Commitment:**
- ISF must be filed **>= 28 hours before vessel departure** (4-hour buffer)
- Agent confidence score >= 0.95 for ISF data extraction
- Zero late filing penalties attributable to Aulintri system failures

**E&O Risk:**
- Late filing = False Claims Act exposure
- Inaccurate data = potential CBP penalty assessments
- All ISF submissions logged to `agent_action_ledger` for audit trail
