# Customs Compliance Screening Checklist

## Pre-Import Screening (Quote Stage)

### Party Screening
- [ ] **OFAC SDN List** - Specially Designated Nationals
  - Source: https://sanctionssearch.ofac.treas.gov/
  - Check: Shipper, manufacturer, consignee, notify party
  - Action if hit: REJECT shipment, report to OFAC

- [ ] **BIS Denied Persons List**
  - Source: https://www.bis.doc.gov/index.php/policy-guidance/lists-of-parties-of-concern
  - Check: All parties in supply chain
  - Action if hit: REJECT shipment

- [ ] **Entity List (BIS)**
  - Restrictions on specific companies (e.g., Huawei subsidiaries)
  - May require export license from origin country

- [ ] **Military End User List**
  - Chinese military-affiliated entities
  - Prohibited under NDAA Section 889

### Commodity Screening
- [ ] **Export Control Classification Number (ECCN)**
  - Dual-use items (military + civilian applications)
  - May require export license

- [ ] **ITAR (International Traffic in Arms Regulations)**
  - Defense articles, technical data
  - Requires State Department license

- [ ] **Section 301 Tariffs**
  - Additional 25% tariff on goods from China (Lists 1-4)
  - HTS chapters affected: Varies by list

- [ ] **UFLPA (Uyghur Forced Labor Prevention Act)**
  - Rebuttable presumption for goods from Xinjiang, China
  - HTS chapters: 52 (cotton), 28 (polysilicon)

## Import Compliance (Entry Stage)

### Value Declaration
- [ ] **Transaction Value Verified**
  - Invoice matches commercial reality
  - Related party pricing documented
  - No undervaluation (19 USC § 1592)

- [ ] **Assists/Royalties Declared**
  - Tooling, molds provided by buyer
  - Trademark/patent royalties
  - Must be added to entered value

### Classification
- [ ] **HTS Code Accuracy**
  - 10-digit code matches commodity description
  - General Rules of Interpretation (GRI) applied
  - Binding Ruling obtained if ambiguous

- [ ] **AD/CVD Applicability Checked**
  - HTS + COO queried against AD/CVD database
  - Rates applied if applicable

### Origin
- [ ] **Country of Origin Verified**
  - Substantial transformation rule applied
  - Certificate of Origin obtained if preferential treatment claimed (USMCA, etc.)

- [ ] **Marking Requirements**
  - "Made in [Country]" on product and packaging (19 CFR § 134)

### PGA Requirements
- [ ] **FDA Prior Notice** (if food/cosmetics)
- [ ] **USDA Permit** (if animal/plant products)
- [ ] **EPA TSCA** (if chemicals)
- [ ] **CPSC Certification** (if consumer products)
- [ ] **TTB Permit** (if alcohol/tobacco)

### Documentation
- [ ] **Commercial Invoice**
  - Shipper, consignee, description, value, terms
  - Must be in English or translated

- [ ] **Packing List**
  - Quantity, weight, dimensions per package

- [ ] **Bill of Lading**
  - Ocean: B/L, Air: AWB, Truck: PRO

- [ ] **Certificate of Origin** (if claiming preferential duty rate)

- [ ] **Other Certificates**
  - Phytosanitary, health, mill test reports, etc.

## Post-Entry Monitoring

### Liquidation
- [ ] **Entry Liquidation Date Tracked**
  - Typically 314 days after entry
  - Can be extended by CBP

- [ ] **No Changes After Liquidation**
  - Final unless protest filed within 180 days

### Compliance Metrics
- [ ] **Error Rate < 5%** (E&O SLA requirement)
- [ ] **No Penalties in Last 12 Months**
- [ ] **ISF On-Time Filing Rate > 98%**

## Red Flags (Escalate to Human Review)

| Red Flag | Action |
|----------|--------|
| Shipper on SDN list | REJECT |
| Value < 50% of market price | Human review, potential undervaluation |
| HTS + COO mismatch (e.g., "Made in USA" but origin CN) | Verify origin, may be transshipment |
| High AD/CVD rate (> 100%) | Verify classification, consider ruling |
| Multiple PGA requirements | Ensure all permits obtained before filing |
| UFLPA high-risk region (Xinjiang) | Additional due diligence, supply chain mapping |

## Aulintri screen_compliance Tool (Sprint 7)

**Input:**
```typescript
{
  party_name: string,
  party_country: string,
  commodity_hts: string,
  commodity_description: string
}
```

**Output:**
```typescript
{
  ofac_hit: boolean,
  bis_hit: boolean,
  section_301_applicable: boolean,
  uflpa_risk: "none" | "low" | "medium" | "high",
  recommended_action: "approve" | "escalate" | "reject",
  confidence_score: number
}
```

## References
- 19 CFR § 11 - Packing and Stamping
- 19 CFR § 134 - Country of Origin Marking
- 19 USC § 1592 - Penalties for Fraud
- OFAC: https://sanctionssearch.ofac.treas.gov/
- BIS: https://www.bis.doc.gov/
