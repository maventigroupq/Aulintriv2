# CATAIR EDI Format Requirements

## Overview

CATAIR (Customs and Trade Automated Interface Requirements) is CBP's Electronic Data Interchange (EDI) specification for the Automated Broker Interface (ABI).

**Protocol:** ANSI X12 EDI
**Transport:** CBP ACE (Automated Commercial Environment)
**Security:** PKI certificates required

## ISF Message Format (ANSI X12 350)

### Structure
```
ISA segment - Interchange Control Header
GS segment - Functional Group Header
ST segment - Transaction Set Header (350)
M10 segment - ISF Header
M11-M19 segments - ISF Data Elements
SE segment - Transaction Set Trailer
GE segment - Functional Group Trailer
IEA segment - Interchange Control Trailer
```

### Example ISF Message
```
ISA*00*          *00*          *ZZ*BROKERCODE     *ZZ*CBPPORTAL      *260315*1430*U*00401*000000001*0*P*>~
GS*IM*BROKERCODE*CBPPORTAL*20260315*1430*1*X*004010~
ST*350*0001~
M10*2704*ISF2026001*MSCU1234567*CNSHA*USLAX*20260401~
M11*12-3456789*ACME IMPORTS INC*456 COMMERCE ST*LOS ANGELES*CA*90001*US~
M12*SHANGHAI MFG CO LTD*123 INDUSTRIAL RD*SHANGHAI**200000*CN~
M13*SHANGHAI MFG CO LTD*123 INDUSTRIAL RD*SHANGHAI**200000*CN~
M14*ACME IMPORTS INC*456 COMMERCE ST*LOS ANGELES*CA*90001*US~
M15*456 COMMERCE ST*LOS ANGELES*CA*90001*US~
M16*123 INDUSTRIAL RD*SHANGHAI**200000*CN~
M17*SHANGHAI MFG CO LTD*123 INDUSTRIAL RD*SHANGHAI**200000*CN~
M18*6203*CN~
M19*6206*CN~
SE*12*0001~
GE*1*1~
IEA*1*000000001~
```

### Segment Details

**M10 - ISF Header:**
- Port Code (4 digits)
- ISF Number (unique identifier)
- Container Number
- Foreign Port of Lading (UN/LOCODE)
- U.S. Port of Unlading (UN/LOCODE)
- Estimated Arrival Date (YYYYMMDD)

**M11 - Importer/Consignee:**
- IRS/EIN
- Name
- Address (line 1, city, state, postal, country)

**M12-M17 - Party Details:**
- M12: Manufacturer
- M13: Seller
- M14: Buyer
- M15: Ship-to
- M16: Container Stuffing Location
- M17: Consolidator

**M18-M19 - Commodity (repeat for each item):**
- HTS-6 Code
- Country of Origin

## Entry Summary Format (ANSI X12 214)

### Structure
```
ST segment - Transaction Set Header (214)
B3 segment - Beginning Segment for Entry
N1-N4 segments - Party Name/Address
N9 segment - Reference Identification
L5 segment - Line Item Detail
SE segment - Transaction Set Trailer
```

### Example Entry Line Item
```
L5*1*6203424060*CN*1000*DZ*12500.00*0.165*2062.50~
```

**Fields:**
1. Line number: `1`
2. HTS code (10-digit): `6203424060`
3. Country of origin: `CN`
4. Quantity: `1000`
5. Unit of measure: `DZ` (dozen)
6. Entered value: `12500.00`
7. Duty rate: `0.165` (16.5%)
8. Duty amount: `2062.50`

## CBP Response Codes

### Acceptance Codes
- `AA` - Accepted, no errors
- `AB` - Accepted with warnings
- `AC` - Conditionally accepted (additional docs required)

### Rejection Codes
- `E01` - Invalid entry number format
- `E02` - Missing required data element
- `E03` - Invalid HTS code
- `E04` - Invalid country code
- `ISF04` - ISF missing data
- `ISF12` - ISF invalid HTS-6
- `ISF23` - ISF late filing (< 24 hours)

## Error Handling

### Retry Logic
1. Rejection received → Parse error code
2. If correctable (E02, E03, ISF04) → Fix data, resubmit
3. If systemic (E01) → Escalate to human review
4. If late filing (ISF23) → Cannot retry, penalty assessed

### Timeout Handling
- Submit → Wait up to 30 seconds for acknowledgement
- No response → Retry once after 60 seconds
- Still no response → Log to dead letter queue, human intervention

## ABI Vendor Integration

Aulintri uses third-party ABI vendors (not direct CBP connection):

### Vendor Options
1. **Connexion** - Leading ABI vendor, 60% market share
2. **QP** (Customs Quest) - Mid-tier, good API
3. **Descartes** - Enterprise, complex setup

### Integration Pattern
```
Aulintri MCP Tool → ABI Vendor API → CBP ACE Gateway → CBP Mainframe

submit_isf_filing():
  1. Build CATAIR ISF message (M10-M19 segments)
  2. POST to vendor API: /api/v1/isf/submit
  3. Vendor translates to EDI, submits to CBP
  4. Receive acknowledgement (AA/AB) or rejection (E*)
  5. Return result to MCP caller
```

## Aulintri Implementation (Sprint 7)

### submit_isf_filing Tool
**Ledger Write:**
```typescript
action_type: 'submit_isf'
reserve_allocated: 0.35 // $0.35 per ISF filing
```

**CATAIR Message Construction:**
```typescript
function buildISFMessage(input: ISFInput): string {
  const segments = [
    buildISASegment(brokerCode, timestamp),
    buildGSSegment(brokerCode, timestamp),
    buildSTSegment('350', sequenceNumber),
    buildM10Segment(input.port, input.isfNumber, ...),
    buildM11Segment(input.importer),
    buildM12Segment(input.manufacturer),
    // ... M13-M17
    ...input.commodities.map((c, i) => buildM18Segment(c)),
    buildSESegment(segmentCount),
    buildGESegment(),
    buildIEASegment()
  ];
  return segments.join('~\n') + '~';
}
```

### Error Logging
All CBP rejections logged to `agent_action_ledger`:
```typescript
{
  outcome_type: 'failure',
  error_message: 'CBP rejection: ISF04 - Missing manufacturer address',
  metadata: {
    cbp_response_code: 'ISF04',
    cbp_message: 'M12 segment incomplete',
    retry_count: 1
  }
}
```

## Testing (Sprint 7)

### CBP Sandbox
- URL: https://aceservices.cbp.dhs.gov/acesbp-test/
- Credentials: Apply via CBP portal
- Test ISF numbers: Use pattern `TESTISF*`

### Validation Tests
1. Valid ISF → Expect `AA` response
2. Invalid HTS-6 → Expect `ISF12` rejection
3. Late filing (timestamp < 24h) → Expect `ISF23` rejection
4. Missing M12 segment → Expect `ISF04` rejection

## References
- CATAIR Specification: https://www.cbp.gov/trade/ace/catair
- ABI Handbook: CBP Publication 0000-0558-00
- X12 EDI Standard: ANSI ASC X12
