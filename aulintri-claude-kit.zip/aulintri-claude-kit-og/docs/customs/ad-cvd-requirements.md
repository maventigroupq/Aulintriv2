# Antidumping (AD) & Countervailing Duty (CVD) Requirements

## Overview

AD/CVD duties are **additional tariffs** imposed on imports determined to be sold in the U.S. below fair market value (dumping) or benefiting from foreign government subsidies.

**Legal Authority:** 19 USC § 1673 (AD), 19 USC § 1671 (CVD)

## Key Concepts

### Antidumping (AD)
- Imposed when foreign manufacturer sells goods in U.S. below "normal value"
- Example: Chinese steel sold in U.S. for $400/ton vs. $600/ton in China
- AD duty = difference (e.g., $200/ton or 50% ad valorem)

### Countervailing Duty (CVD)
- Imposed when foreign government subsidizes manufacturer
- Example: Export subsidies, preferential loans, tax breaks
- CVD duty = estimated subsidy amount

## Active Cases (High-Volume Examples)

| HTS Chapter | Commodity | Countries | AD Rate | CVD Rate |
|-------------|-----------|-----------|---------|----------|
| 72 | Steel products | CN, IN, KR | 25-200% | 10-50% |
| 04 | Honey | CN, VN, AR | 50-100% | 5-20% |
| 84 | Solar panels | CN, MY, TH, VN | 30-250% | 15-40% |
| 73 | Wire hangers | CN, VN | 20-180% | 3-15% |
| 39 | PVC resin | CN, IN | 15-75% | 2-10% |

**Total Active Cases (as of 2026):** ~600 AD/CVD orders

## Lookup Process

### Step 1: Identify HTS + Country Combination
```
HTS: 7208.51.00.45 (hot-rolled steel)
COO: CN (China)
```

### Step 2: Query AD/CVD Database
Sources:
- CBP AD/CVD Search: https://adcvd.cbp.dhs.gov/
- Federal Register daily updates
- Aulintri RAG pipeline (ingests Federal Register daily)

### Step 3: Check Case Status
- **Active:** Duties currently in effect
- **Suspended:** Duties waived (exporter agreement)
- **Revoked:** Order terminated (sunset review)
- **Under Review:** Administrative/sunset review pending

### Step 4: Calculate Duty
```
Entered Value: $10,000
AD Rate: 25.5%
CVD Rate: 8.3%

AD Duty: $10,000 × 0.255 = $2,550
CVD Duty: $10,000 × 0.083 = $830
Total AD/CVD: $3,380
```

## Case Number Format

**Antidumping:** `A-XXX-###`
- Example: `A-570-979` (Steel Wire Garment Hangers from China)
- XXX = country code (570 = China)

**Countervailing Duty:** `C-XXX-###`
- Example: `C-570-980` (Steel Wire Garment Hangers from China - CVD)

## Federal Register Updates

AD/CVD orders change frequently via:
- **New Orders:** New case initiated
- **Scope Rulings:** Clarify which products covered
- **Administrative Reviews:** Annual rate adjustments
- **Sunset Reviews:** Every 5 years, order may be revoked
- **Changed Circumstances:** Immediate rate changes

**Aulintri RAG Pipeline:**
- Ingests Federal Register daily (6am ET)
- Indexes by HTS chapter + country
- Embeddings for semantic search
- Alerts if existing shipment affected by new order

## Importer Acknowledgement Requirement

**Critical:** Importer must **acknowledge** AD/CVD duty liability **before** quote approval.

### Modal Text (Sprint 3):
```
⚠️ Antidumping/Countervailing Duty Notice

This shipment is subject to additional duties:
- Case A-570-979: Steel Wire Garment Hangers from China
- AD Rate: 25.5%
- CVD Rate: 8.3%
- Estimated AD/CVD: $3,380.00

By approving this quote, you acknowledge responsibility for all applicable
AD/CVD duties. Failure to pay AD/CVD duties may result in CBP penalties
and potential False Claims Act liability.

☐ I acknowledge and accept AD/CVD liability (REQUIRED)
```

**Backend Implementation:**
- Acknowledgement logged to `audit_log` table
- Timestamp + user_id + case_number recorded
- Used as defense in False Claims Act disputes

## Aulintri Implementation (Sprint 7)

### classify_hts_code Tool
When classifying HTS, tool must:
1. Query AD/CVD database for HTS + COO match
2. Return:
```typescript
{
  hts_code: "7208510045",
  ad_cvd_applicable: true,
  ad_case: "A-570-979",
  ad_rate_percent: 25.5,
  cvd_case: "C-570-980",
  cvd_rate_percent: 8.3,
  estimated_ad_cvd_usd: 3380.00,
  requires_acknowledgement: true,
}
```

### FAN Integration
If AD/CVD detected:
- Publish to `fan:threat` channel
- Event type: `ad_cvd_risk`
- Severity: `high` (rates > 100%) or `medium` (rates < 100%)
- Shared cross-tenant after anonymization

## E&O Risk Management

**High-Risk Scenarios:**
1. **Missed AD/CVD Order:** Agent fails to detect applicable order
   - Importer underpays duties → CBP penalty + interest
   - E&O claim potential: $5,000 - $50,000

2. **Incorrect Rate Applied:** Agent uses outdated rate
   - Underpayment or overpayment of duties
   - Requires post-entry reconciliation

3. **Scope Ambiguity:** Product may/may not be covered by order
   - Agent confidence < 0.85 triggers mandatory BLC review
   - Customs ruling request may be required

**Mitigation:**
- Daily RAG ingestion of Federal Register
- Confidence threshold: 0.97 for AD/CVD flagged shipments
- All AD/CVD detections logged to `agent_action_ledger`

## References

- 19 USC § 1673 - Antidumping Duties
- 19 USC § 1671 - Countervailing Duties
- CBP AD/CVD Search: https://adcvd.cbp.dhs.gov/
- Federal Register: https://www.federalregister.gov/
