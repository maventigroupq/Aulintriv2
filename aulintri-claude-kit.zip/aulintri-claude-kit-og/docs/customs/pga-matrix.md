# PGA (Partner Government Agency) Requirements Matrix

## Overview
Partner Government Agencies regulate specific product categories beyond CBP jurisdiction. Each requires permits, certifications, or prior approvals before importation.

## PGA Agency Matrix

| Agency | HTS Chapters | Requirements | Contact |
|--------|--------------|--------------|---------|
| **FDA** (Food & Drug Administration) | 3, 4, 19-24, 30, 90 | Prior Notice, registration | FDA.gov |
| **USDA** (Agriculture) | 1-24, 41, 43, 51-53 | Permits, phytosanitary certificates | APHIS.usda.gov |
| **EPA** (Environmental) | 27, 38, 84, 87 | TSCA compliance, vehicle emissions | EPA.gov |
| **CPSC** (Consumer Products) | 39, 61-64, 94-96 | Safety certifications | CPSC.gov |
| **TTB** (Alcohol/Tobacco) | 22, 24 | Permits, COLA labels | TTB.gov |
| **NHTSA/DOT** (Vehicles) | 87 | FMVSS compliance | NHTSA.gov |
| **FCC** (Telecommunications) | 85 | Equipment authorization | FCC.gov |

## FDA Requirements

### Prior Notice (PN)
**Required for:** Food, cosmetics, dietary supplements, drugs
**Timing:** Before arrival in U.S.
**Data:** Manufacturer, shipper, grower, product description

### FDA Registration
**Required for:** Food facilities, drug manufacturers
**Timing:** Before first shipment
**Renewal:** Biennial (Oct 1 - Dec 31 even years)

### Common FDA HTS Codes
- `0202.*` - Beef products (USDA + FDA)
- `1901.90` - Food preparations
- `2106.90` - Dietary supplements
- `3004.*` - Pharmaceutical products
- `3304.*` - Cosmetics

## USDA Requirements

### APHIS Permits
**Required for:** Plants, animals, animal products
**Timing:** Apply 30+ days before shipment

### Phytosanitary Certificates
**Required for:** Wooden pallets (ISPM 15), fresh produce
**Issued by:** Origin country agriculture ministry

### Lacey Act Declaration
**Required for:** Wood, plants, plant products
**Data:** Scientific name, value, quantity, source

## EPA Requirements

### TSCA (Toxic Substances Control Act)
**Required for:** Chemicals, plastics
**Certification:** "I certify this shipment complies with TSCA"

### Vehicle Emissions
**Required for:** Cars, trucks, engines
**Standards:** EPA Tier 2/3 or nonroad emissions

## CPSC Requirements

### Children's Products
**Required for:** Toys, children's clothing (HTS 61-63, 95)
**Certification:** CPC (Children's Product Certificate)
**Testing:** CPSIA lead, phthalate limits

### General Products
**Required for:** Household goods, furniture
**Standards:** ASTM, UL, product-specific regulations

## TTB Requirements

### Alcoholic Beverages
**Required for:** Beer, wine, spirits (HTS 2203-2208)
**Permits:** Basic Permit (importer), COLA (label approval)
**Taxes:** Federal excise tax per proof gallon

### Tobacco
**Required for:** Cigarettes, cigars (HTS 2402-2403)
**Permits:** Tobacco Import Permit
**Taxes:** Federal excise tax per unit

## Aulintri PGA Detection (Sprint 7)

### classify_hts_code Tool Response
```typescript
{
  hts_code: "2106909890",
  pga_requirements: [
    {
      agency: "FDA",
      requirement_type: "prior_notice",
      description: "FDA Prior Notice required for food preparations",
      deadline: "Before arrival",
      reference: "21 CFR 1.277"
    },
    {
      agency: "FDA",
      requirement_type: "registration",
      description: "FDA facility registration required",
      deadline: "Before first shipment",
      reference: "21 CFR 1.225"
    }
  ],
  compliance_checklist: [
    "☐ FDA Prior Notice filed",
    "☐ Facility registration verified",
    "☐ Manufacturer listed on FDA registration"
  ]
}
```

### FAN Integration
- PGA violations shared cross-tenant (anonymized)
- Example: "HTS 9503.* from CN - high CPSC rejection rate"

## References
- CBP PGA Message Set: https://www.cbp.gov/trade/ace/catair
- FDA Prior Notice: https://www.fda.gov/food/prior-notice-imported-food
- USDA APHIS: https://www.aphis.usda.gov/aphis/ourfocus/importexport
