# Sprint 4 Build Plan — Production Readiness
**Date:** 2026-03-20
**Phase:** 1 (Months 1-3, Foundations)
**Status:** READY TO BUILD

---

## Sprint 4 Goal

**Primary Objective:** Make Quote Agent production-ready with real external API integrations, comprehensive tests, and UI

**Exit Criteria:**
- ✅ Claude API integration with RAG context (hts-classifier.ts)
- ✅ 3 carrier API clients (Freightos, Flexport, Convoy)
- ✅ FMCSA safety score client
- ✅ AOS handoff client (Redis pub/sub)
- ✅ Comprehensive test suite (85%+ coverage)
- ✅ Quote Dashboard UI (Next.js)
- ✅ 500 test classifications processed, confidence threshold calibrated
- ✅ Production deployment ready (all API keys in Secrets Manager)

---

## Deliverables by Agent

### Phase A: Carrier API Clients (backend-agent)

**Files:** `src/services/carrier-rates/`

**Tasks:**
1. **Freightos API Client** (`freightos-client.ts`)
   - Endpoint: `https://api.freightos.com/v1/ocean-freight/rates`
   - Auth: API key in headers (`X-API-Key`)
   - Rate limit: 100 req/hour
   - Response schema: `{ carrier, price, transit_days, valid_until }`
   - Error handling: 429 (rate limit), 503 (service down)

2. **Flexport API Client** (`flexport-client.ts`)
   - Endpoint: `https://api.flexport.com/v2/ocean/rates`
   - Auth: OAuth 2.0 (client credentials flow)
   - Rate limit: 500 req/hour
   - Response schema: `{ carrier_scac, ocean_freight_usd, customs_clearance_usd, transit_days }`

3. **Convoy API Client** (`convoy-client.ts`)
   - Endpoint: `https://api.convoy.com/v1/drayage/quotes`
   - Auth: API key in Bearer token
   - Rate limit: 200 req/hour
   - Response schema: `{ carrier_dot, drayage_cost_usd, pickup_date, delivery_date }`

4. **Carrier Aggregator** (`carrier-aggregator.ts`)
   - Parallel fetch with `Promise.allSettled`
   - Deduplication by SCAC code
   - Ranking algorithm (price 50%, transit 30%, safety 20%)
   - Caching with Redis (1h TTL)
   - Circuit breaker with `opossum` library

---

### Phase B: HTS Classifier with Claude API (backend-agent)

**Files:** `src/agents/quote/hts-classifier.ts`

**Tasks:**
1. **Claude API Integration**
   - Model: `claude-sonnet-4-20250514`
   - Max tokens: 2000
   - Temperature: 0.0 (deterministic)
   - API key from Secrets Manager: `aulintri/prod/claude-api-key`

2. **RAG Context Injection**
   - Query `query_rag_corpus` tool for top-3 precedents
   - Build prompt with RAG context (see Sprint 3 architecture)
   - Track token usage for cost monitoring

3. **Response Parsing**
   - Parse JSON response
   - Validate HTS format: `/^\d{4}\.\d{2}\.\d{4}$/`
   - Validate confidence: 0.0 ≤ score ≤ 1.0
   - Flag for review if confidence < 0.97

4. **Error Handling**
   - Retry 3x with exponential backoff (1s, 2s, 4s)
   - Fallback to "manual review required" if all retries fail
   - Log errors to CloudWatch

---

### Phase C: FMCSA Client + AOS Handoff (backend-agent)

**Files:** `src/agents/quote/fmcsa-client.ts`, `src/agents/orchestration/handoff-client.ts`

**Tasks:**
1. **FMCSA Safety Score Client**
   - Endpoint: `https://mobile.fmcsa.dot.gov/qc/services/carriers/{dotNumber}`
   - No auth required (public API)
   - Rate limit: 100 req/day
   - Response: `{ safetyRating, crashTotal, oosTotal, inspectionTotal }`
   - Safety score calculation formula (Sprint 3 architecture)
   - Cache results with 7-day TTL (aggressive due to rate limit)

2. **AOS Handoff Client**
   - Publish to Redis channels: `aos:handoff:ops`, `aos:dlq`
   - Lock management: `SET NX EX` pattern
   - Heartbeat publishing (30s interval)
   - Message schema validation

---

### Phase D: Comprehensive Test Suite (test-agent)

**Files:** `tests/integration/agents/quote-agent.test.ts`, `tests/acceptance/sprint-4-exit-criteria.test.ts`

**Tasks:**
1. **Unit Tests** (85%+ coverage):
   - Freightos client (10 tests)
   - Flexport client (10 tests)
   - Convoy client (10 tests)
   - Carrier aggregator (15 tests)
   - HTS classifier (20 tests)
   - FMCSA client (8 tests)
   - AOS handoff client (12 tests)

2. **Integration Tests**:
   - Quote Agent full pipeline (RFQ → Quote)
   - Carrier rate aggregation (parallel fetch, dedup, ranking)
   - HTS classification with RAG context
   - AOS handoff (lock acquisition, publish, release)

3. **Acceptance Tests**:
   - 500 test classifications (calibration dataset)
   - Confidence threshold analysis (target: <5% manual review rate)
   - End-to-end quote generation (< 30s)

4. **Test Fixtures**:
   - Mock carrier API responses (50 samples)
   - Mock Claude API responses (100 HTS classifications)
   - Mock FMCSA responses (20 carriers)

---

### Phase E: Quote Dashboard UI (frontend-agent)

**Files:** `src/app/quotes/`, `src/components/quote/`

**Tasks:**
1. **Quote Dashboard Page** (`src/app/quotes/page.tsx`)
   - List view: All quotes with status, HTS confidence, carrier
   - Filters: Date range, confidence threshold, customer
   - Sort: By date, confidence, total cost

2. **Quote Detail Page** (`src/app/quotes/[id]/page.tsx`)
   - HTS classification result (code, confidence, reasoning)
   - RAG sources cited (Federal Register links)
   - Carrier rate comparison table
   - Safety score badges
   - Action buttons: Approve, Request Review, Export PDF

3. **Components**:
   - `QuoteCard` (summary card with key metrics)
   - `HTSClassificationResult` (confidence gauge, reasoning)
   - `CarrierRateComparison` (table with sort/filter)
   - `SafetyScoreBadge` (color-coded: green 90+, yellow 75-89, red <75)
   - `RAGSourcesList` (Federal Register citations)

4. **Storybook Stories** (5 components × 3 states each = 15 stories)

---

### Phase F: Calibration & Deployment

**Tasks:**
1. **Confidence Threshold Calibration**:
   - Process 500 test classifications
   - Analyze false positive rate at 0.95, 0.97, 0.99 thresholds
   - Select threshold with <5% manual review rate, 99%+ accuracy
   - Document findings in `docs/sprint-acceptance/confidence-calibration-report.md`

2. **API Keys Setup** (Secrets Manager):
   - `aulintri/prod/claude-api-key`
   - `aulintri/prod/freightos-api-key`
   - `aulintri/prod/flexport-oauth-client-id`
   - `aulintri/prod/flexport-oauth-client-secret`
   - `aulintri/prod/convoy-api-key`

3. **Production Deployment**:
   - Deploy Quote Agent to AWS Lambda (or ECS)
   - Configure EventBridge trigger for Redis subscription
   - Enable CloudWatch alarms (errors, latency, cost)
   - Deploy Quote Dashboard to Vercel/AWS Amplify

---

## Acceptance Criteria (Sprint 4 Exit)

### Must Pass (Blocking):
✅ Claude API integration returns valid HTS classifications
✅ All 3 carrier APIs return rates (or 2 of 3 with circuit breaker open)
✅ FMCSA safety scores retrieved and cached
✅ AOS handoff publishes to `aos:handoff:ops` channel
✅ 500 test classifications processed
✅ Confidence threshold calibrated (target: 0.97 with <5% review rate)
✅ Test coverage ≥85% for all new files
✅ Quote Dashboard renders with real data
✅ All API keys stored in Secrets Manager
✅ Production deployment successful (dev environment)

### Nice to Have (Non-blocking):
- Email notifications when quote ready
- PDF export for quotes
- Cost tracking dashboard (Claude API usage)

---

## Build Order (Dependencies)

### Phase A (Days 1-2): Carrier API Clients
**Sequential:**
1. backend-agent: Freightos client
2. backend-agent: Flexport client (OAuth flow)
3. backend-agent: Convoy client
4. backend-agent: Carrier aggregator (parallel fetch, ranking)

### Phase B (Days 3-4): HTS Classifier
**Sequential:**
1. backend-agent: Claude API integration
2. backend-agent: RAG context injection
3. backend-agent: Response parsing and validation

### Phase C (Day 5): Supporting Services
**Parallel:**
1. backend-agent: FMCSA client
2. backend-agent: AOS handoff client

### Phase D (Days 6-7): Testing
**Sequential:**
1. test-agent: Unit tests (85%+ coverage)
2. test-agent: Integration tests
3. test-agent: Acceptance tests

### Phase E (Days 8-9): UI
**Parallel:**
1. frontend-agent: Quote Dashboard pages
2. frontend-agent: Components + Storybook

### Phase F (Day 10): Calibration & Deployment
**Sequential:**
1. backend-agent: Run 500 test classifications
2. architect-agent: Analyze results, calibrate threshold
3. devops-agent: Deploy to production

---

## Technical Notes

### Carrier API Mocking Strategy
For testing without real API keys:
```typescript
// tests/mocks/carrier-api-mocks.ts
export const mockFreightosResponse = {
  quotes: [
    { carrier: 'MAEU', price_usd: 2500, transit_days: 18, valid_until: '2025-04-01' }
  ]
};
```

### Claude API Prompt Template
```typescript
const prompt = `You are a customs classification expert. Classify this commodity into a 10-digit HTS code.

COMMODITY: ${commodityDescription}
COUNTRY OF ORIGIN: ${countryOfOrigin}

FEDERAL REGISTER PRECEDENTS:
${ragResults.map(r => `- [${r.document_number}] ${r.content}`).join('\n')}

PRIOR CLASSIFICATIONS:
${priorClassifications.map(p => `- ${p.hts_code} (confidence: ${p.confidence})`).join('\n')}

Respond in JSON:
{
  "hts_code": "0000.00.0000",
  "confidence": 0.98,
  "reasoning": "...",
  "alternative_codes": ["0000.00.0001"],
  "required_documentation": ["Certificate of Origin"]
}`;
```

### Circuit Breaker Configuration
```typescript
const circuitBreaker = new CircuitBreaker(fetchCarrierRates, {
  timeout: 3000,
  errorThresholdPercentage: 50,
  resetTimeout: 30000, // 30 seconds
});
```

---

## Risk Register

| Risk | Mitigation | Owner |
|------|------------|-------|
| Carrier API keys unavailable | Use mock data, deploy stubs | backend-agent |
| Claude API quota exceeded | Rate limiter (10 req/min), alert at 80% quota | backend-agent |
| Confidence calibration shows <99% accuracy | Lower threshold to 0.95, accept 10% review rate | architect-agent |
| OAuth flow for Flexport fails | Fallback to 2-carrier mode (Freightos + Convoy) | backend-agent |
| FMCSA rate limit hit during testing | Pre-populate cache with 100 carriers | backend-agent |

---

## Dependencies

### From Sprint 3:
- ✅ Quote Agent core (agent.ts)
- ✅ TypeScript types (types.ts)
- ✅ Architecture docs (ADR-005, FSM, AOS pattern)

### New for Sprint 4:
- ❓ **External API keys** (Claude, carriers) - store in Secrets Manager
- ❓ **Calibration dataset** (500 known commodity descriptions with verified HTS codes)
- ❓ **Production AWS environment** (Lambda/ECS, RDS, Redis)

---

## Post-Sprint 4 Handoff

After Sprint 4:
- Quote Agent production-ready with real carrier APIs
- BLX can start using for customer quotes
- First external quote via AI (milestone)
- Ready for Sprint 5: Ops Agent (booking automation)

---

**Sprint 4 Duration:** 10 days
**Sprint 4 Output:** Production Quote Agent + Quote Dashboard UI
