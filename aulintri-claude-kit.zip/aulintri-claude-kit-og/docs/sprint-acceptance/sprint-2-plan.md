# Sprint 2 Build Plan — RAG Pipeline
**Date:** 2026-03-20
**Phase:** 1 (Months 1-3, Foundations)
**Status:** READY TO BUILD

---

## Answers Applied

**Architecture Decisions:**
- Q1: **Federal Register API v1** (default)
- Q2: **VoyageAI API** (default - voyage-3 embeddings)
- Q3: **Append-only updates** (default - keep all versions)
- Q4: **Daily at 2am ET** (default)

**Business Rules:**
- Q5: **Notices only** (AD/CVD, HTS keywords) (default)
- Q6: **Internal roles only** (exclude CUSTOMER) (default)
- Q7: **1000 tokens per chunk, 200 overlap** (default)

**Integration:**
- Q8: **Retry 3x + alert** (default)
- Q9: **< 1 second p95** (default)
- Q10: **5-year rolling window** (default)

---

## Sprint 2 Goal

**Primary Objective:** RAG pipeline ingesting Federal Register documents daily with pgvector embeddings

**Exit Criteria:**
- Federal Register API ingestion worker running daily at 2am ET
- Documents chunked (1000 tokens) and embedded (voyage-3)
- New MCP tool `query_rag_corpus` registered and callable
- First 7 days of Federal Register documents ingested (seed data)
- pgvector similarity search working with <1s p95 latency

---

## Deliverables by Agent

### 1. architect-agent (Sequential - FIRST)
**Files:** `prisma/schema.prisma` (updates), `src/mcp/registry.ts` (updates), `docs/architecture/`

**Tasks:**
- [ ] Update `rag_documents` schema with ingestion metadata:
  - `source_url` (Federal Register document URL)
  - `document_type` (notice, rule, proposed_rule)
  - `publication_date` (original Federal Register date)
  - `chunk_index` (position in parent document)
  - `chunk_total` (total chunks for parent)
  - `parent_document_id` (grouping field for multi-chunk docs)
- [ ] Design `rag_ingestion_runs` audit table:
  - `run_id`, `started_at`, `completed_at`, `documents_processed`, `chunks_created`, `errors`
- [ ] Design RAG query MCP tool schema:
  - `query_rag_corpus(query_text, filters?, top_k?, tenant_id?)` → RAGResult[]
- [ ] Create ADR-004: RAG Pipeline Architecture (chunking, embedding, retrieval)
- [ ] Document Federal Register API integration patterns

---

### 2. backend-agent (Sequential - after architect)
**Files:** `src/workers/rag-ingestion.ts`, `src/mcp/tools/query-rag-corpus.ts`, `src/services/`

**Tasks:**
- [ ] Implement Federal Register API client (`src/services/federal-register-client.ts`):
  - Date-based document query (last 24 hours)
  - Document type filtering (notices only)
  - Keyword filtering (AD/CVD, HTS, scope ruling, CBP)
  - Rate limiting (1000 req/hour)
  - Error handling with retries
- [ ] Implement VoyageAI embedding service (`src/services/voyage-embedding.ts`):
  - voyage-3 model (1024 dimensions)
  - Batch processing (up to 128 texts per request)
  - API key from AWS Secrets Manager
- [ ] Implement text chunking service (`src/services/text-chunker.ts`):
  - Fixed-size chunking (1000 tokens with 200 overlap)
  - Token counting (tiktoken for GPT-4 tokenizer as proxy)
  - Preserve document structure (don't split mid-sentence)
- [ ] Implement RAG ingestion worker (`src/workers/rag-ingestion.ts`):
  - Scheduled via Redis (Bull queue or node-cron)
  - Runs daily at 2am ET
  - Fetch documents from Federal Register API
  - Chunk documents
  - Generate embeddings (batch)
  - Insert into `rag_documents` table
  - Write audit record to `rag_ingestion_runs`
  - Write ledger entry to `agent_action_ledger`
  - Alert on failure (Slack/email stub)
- [ ] Implement `query_rag_corpus` MCP tool (`src/mcp/tools/query-rag-corpus.ts`):
  - Input: query_text, filters (date range, document type), top_k (default 5)
  - Generate query embedding (VoyageAI)
  - pgvector similarity search (cosine distance)
  - Return ranked results with metadata
  - Enforce tenant_id isolation (RLS)
  - Target <1s p95 latency
- [ ] Register `query_rag_corpus` in `src/mcp/registry.ts` (5th tool)
- [ ] Create Prisma migration for schema updates

---

### 3. devops-agent (Parallel - after architect schema design)
**Files:** `infra/`, `.github/workflows/`, `scripts/`

**Tasks:**
- [ ] Store VoyageAI API key in AWS Secrets Manager (`aulintri/voyage-api-key`)
- [ ] Create AWS Lambda function for RAG ingestion worker (or ECS scheduled task):
  - Runtime: Node.js 20
  - Memory: 2GB (for embedding batch processing)
  - Timeout: 15 minutes
  - Trigger: EventBridge schedule (cron: `0 7 * * ? *` UTC = 2am ET)
- [ ] Set up CloudWatch alarms for ingestion failures
- [ ] Create S3 bucket for raw Federal Register document cache (optional)
- [ ] Update CI/CD pipeline to deploy RAG worker
- [ ] Document RAG worker deployment in README

---

### 4. test-agent (Sequential - after backend tools built)
**Files:** `tests/integration/`, `tests/acceptance/`

**Tasks:**
- [ ] Write unit tests for Federal Register API client:
  - Mock API responses (sample documents)
  - Test date filtering
  - Test keyword filtering
  - Test rate limiting (verify delay between requests)
- [ ] Write unit tests for text chunker:
  - Verify 1000 token chunks
  - Verify 200 token overlap
  - Test edge cases (very short documents, exact multiples)
- [ ] Write unit tests for VoyageAI embedding service:
  - Mock VoyageAI API
  - Test batch processing
  - Test error handling (API down, invalid key)
- [ ] Write integration test for RAG ingestion worker:
  - Mock Federal Register API (return 3 sample documents)
  - Run ingestion process
  - Verify `rag_documents` table populated
  - Verify `rag_ingestion_runs` audit record written
  - Verify `agent_action_ledger` entry exists
- [ ] Write integration test for `query_rag_corpus` MCP tool:
  - Seed `rag_documents` with 10 test chunks
  - Query via MCP protocol
  - Verify top-k results returned (k=5)
  - Verify similarity scores sorted descending
  - Test filters (date range, document type)
  - Verify RLS isolation (tenant A cannot see tenant B's private RAG data)
- [ ] Write acceptance tests for Sprint 2 exit criteria:
  - RAG ingestion worker callable manually
  - `query_rag_corpus` tool registered in MCP registry
  - Query returns results in <1s (p95)
  - 7 days of seed data ingested successfully
- [ ] Create test fixtures for Federal Register documents (JSON samples)

---

## Build Order (Dependencies)

### Phase A (Week 1, Days 1-2): Schema & Infrastructure
**Sequential:**
1. architect-agent: Update Prisma schema (`rag_documents`, `rag_ingestion_runs`)
2. devops-agent: Store VoyageAI API key, create Lambda/ECS task

### Phase B (Week 1, Days 3-5): RAG Services
**Sequential:**
1. backend-agent: Implement Federal Register client + VoyageAI service + text chunker
2. backend-agent: Implement RAG ingestion worker
3. backend-agent: Implement `query_rag_corpus` MCP tool

### Phase C (Week 2, Days 1-2): Testing
**Sequential:**
1. test-agent: Unit tests (Federal Register client, chunker, embeddings)
2. test-agent: Integration tests (RAG worker, query tool)

### Phase D (Week 2, Days 3-4): Seed Data & Validation
**Sequential:**
1. backend-agent: Run RAG ingestion manually for last 7 days (seed corpus)
2. test-agent: Acceptance tests (validate seed data, query performance)

### Phase E (Week 2, Day 5): Deployment
**Sequential:**
1. devops-agent: Deploy RAG worker to AWS Lambda/ECS
2. devops-agent: Verify scheduled run at 2am ET
3. All agents: Bug fixes from production validation

---

## Acceptance Criteria (Sprint 2 Exit)

### Must Pass (Blocking):
✅ `query_rag_corpus` registered as 5th MCP tool
✅ RAG ingestion worker runs successfully (manual trigger)
✅ pgvector table contains at least 100 chunks (from 7 days seed data)
✅ `query_rag_corpus` returns results in <1 second (p95) for 100-chunk corpus
✅ RLS enforced: tenant A cannot query tenant B's RAG data (if multi-tenant RAG added)
✅ `rag_ingestion_runs` audit table populated
✅ `agent_action_ledger` records ingestion runs
✅ All tests passing in CI/CD pipeline
✅ RAG worker deployed to AWS (dev environment)

### Nice to Have (Non-blocking):
- CloudWatch dashboard for RAG ingestion metrics
- Slack alerts on ingestion failures
- Federal Register document cache in S3

---

## Risk Register

| Risk | Mitigation | Owner |
|------|------------|-------|
| VoyageAI API key not available | Block Sprint 2 build until key obtained | devops-agent |
| Federal Register API rate limits hit | Implement exponential backoff, cache responses | backend-agent |
| Embedding generation too slow (>5s per document) | Batch embeddings (128 texts per request) | backend-agent |
| pgvector query latency >1s | Add indexes, tune HNSW parameters (m, ef_construction) | architect-agent |
| RAG corpus grows too large (>10GB in 1 year) | Implement 5-year rolling deletion, archive to S3 | backend-agent |

---

## Sprint 2 Blockers

**MUST RESOLVE BEFORE BUILD:**
1. ❗ **VoyageAI API Key**: Must be available in AWS Secrets Manager as `aulintri/voyage-api-key`

**From Sprint 1 (should be resolved):**
✅ pgvector extension enabled in RDS PostgreSQL
✅ S3 bucket created
✅ Redis available for job scheduling

---

## Technical Notes

### Federal Register API Example

**Endpoint:**
```
GET https://www.federalregister.gov/api/v1/documents.json
?conditions[publication_date][gte]=2026-03-19
&conditions[type][]=NOTICE
&fields[]=abstract,body_html_url,document_number,publication_date,title
&per_page=1000
```

**Response:**
```json
{
  "results": [
    {
      "document_number": "2026-12345",
      "title": "Antidumping Duty Order: Steel Wire Rod from China",
      "publication_date": "2026-03-20",
      "abstract": "...",
      "body_html_url": "https://www.federalregister.gov/documents/full_text/..."
    }
  ]
}
```

### VoyageAI Embedding API Example

**Endpoint:**
```
POST https://api.voyageai.com/v1/embeddings
Content-Type: application/json
Authorization: Bearer <API_KEY>

{
  "input": ["text chunk 1", "text chunk 2", ...],
  "model": "voyage-3"
}
```

**Response:**
```json
{
  "embeddings": [
    [0.123, -0.456, ...], // 1024 dimensions
    [0.789, -0.012, ...]
  ]
}
```

### pgvector Query Example

```sql
-- Query similar chunks (cosine distance)
SELECT
  id,
  content,
  source_url,
  publication_date,
  1 - (embedding <=> $1::vector) AS similarity
FROM rag_documents
WHERE 1 - (embedding <=> $1::vector) > 0.7  -- Similarity threshold
ORDER BY embedding <=> $1::vector  -- Cosine distance (lower = more similar)
LIMIT 5;
```

---

## Post-Sprint 2 Handoff

After Sprint 2 completion:
1. RAG corpus will begin growing daily (2am ET runs)
2. Agents can call `query_rag_corpus` to retrieve Federal Register context
3. Monitor `rag_ingestion_runs` table for ingestion health

**For Mexico engineer (if starting after Sprint 2):**
- Review ADR-004 (RAG Pipeline Architecture)
- Run manual ingestion: `npm run rag:ingest`
- Test query tool:
```bash
curl -X POST http://localhost:3000/mcp -d '{
  "jsonrpc": "2.0",
  "method": "tools/call",
  "params": {
    "name": "query_rag_corpus",
    "arguments": {
      "query_text": "antidumping steel",
      "top_k": 5
    }
  },
  "id": 1
}'
```

---

## Next Steps

After Sprint 2 completion, ready to begin:
- **Sprint 3:** Quote Agent intelligence layer (use RAG corpus for HTS classification refinement)
- **Sprint 4:** Expand RAG corpus (add Rules and Proposed Rules, not just Notices)
