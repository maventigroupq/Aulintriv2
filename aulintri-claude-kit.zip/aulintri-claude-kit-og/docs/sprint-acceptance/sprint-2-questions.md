# Sprint 2 Clarifying Questions — RAG Pipeline
**Date:** 2026-03-20
**Phase:** 1 (Months 1-3, Foundations)
**Goal:** RAG pipeline ingesting Federal Register daily

---

## Architecture Questions

### Q1: Federal Register API Integration
**Question:** Which Federal Register API endpoint are we using for daily ingestion?

**Options:**
- A. Official Federal Register API v1 (https://www.federalregister.gov/api/v1/documents)
- B. GovInfo API (https://api.govinfo.gov/published)
- C. RSS feed scraping (https://www.federalregister.gov/documents/search.rss)

**Default:** Option A (Federal Register API v1)

**Rationale:** Official API with structured JSON responses, rate limiting (1000 requests/hour), supports date-based queries for incremental ingestion.

---

### Q2: Embedding Generation Service
**Question:** How are we generating voyage-3 embeddings (1024 dimensions)?

**Options:**
- A. Anthropic API (if voyage-3 is available via Anthropic)
- B. VoyageAI API (https://docs.voyageai.com/embeddings/)
- C. OpenAI API (ada-002 or text-embedding-3-large, different dimensions)
- D. AWS Bedrock (Titan Embeddings)

**Default:** Option B (VoyageAI API direct)

**Rationale:** Sprint 1 chose voyage-3 (1024 dims) explicitly. VoyageAI is the native provider for voyage-3 model.

**Action needed:** Confirm API key available for VoyageAI before Sprint 2 build.

---

### Q3: RAG Corpus Update Strategy
**Question:** How do we handle updates to existing Federal Register documents?

**Options:**
- A. Append-only (never update, keep all versions with timestamps)
- B. Replace (update existing document record, overwrite embedding)
- C. Hybrid (replace for corrections, append for amendments)

**Default:** Option A (Append-only)

**Rationale:** Federal Register documents can be amended (e.g., AD/CVD scope rulings). Keeping all versions maintains audit trail for compliance.

---

### Q4: RAG Ingestion Schedule
**Question:** What time zone and frequency for Federal Register ingestion?

**Options:**
- A. Daily at 2am ET (documents published at midnight, process off-peak)
- B. Twice daily at 6am and 6pm ET
- C. Real-time via webhook (if Federal Register supports it)

**Default:** Option A (Daily at 2am ET)

**Rationale:** Federal Register publishes at midnight ET. 2am gives buffer for API propagation. Off-peak for database load.

---

## Business Rules

### Q5: Document Type Filtering
**Question:** Which Federal Register document types should we ingest for Sprint 2?

**Options:**
- A. All documents (notices, rules, proposed rules, presidential documents)
- B. Notices only (AD/CVD cases, HTS updates)
- C. Rules + Notices (exclude presidential documents)

**Default:** Option B (Notices only)

**Rationale:** Sprint 2 focuses on AD/CVD and HTS intelligence. Rules and presidential documents add noise. Expand in Sprint 4.

**Keywords to filter:**
- "antidumping"
- "countervailing duty"
- "harmonized tariff"
- "HTS"
- "scope ruling"
- "CBP"
- "U.S. Customs"

---

### Q6: RAG Query Tool Permissions
**Question:** Who can call the `query_rag_corpus` MCP tool?

**Options:**
- A. All Cognito roles (ADMIN, BLX_OPS, BLC_BROKER, CUSTOMER, MCP_AGENT)
- B. Internal roles only (ADMIN, BLX_OPS, BLC_BROKER, MCP_AGENT) — exclude CUSTOMER
- C. Agents only (MCP_AGENT role) — humans cannot query directly

**Default:** Option B (Internal roles only)

**Rationale:** RAG corpus contains Federal Register raw text. Customers should get structured answers via agents, not raw retrieval. Prevents information overload.

---

### Q7: Embedding Chunking Strategy
**Question:** How do we chunk long Federal Register documents for embedding?

**Options:**
- A. Full document (no chunking, single embedding per document)
- B. Fixed size (1000 tokens per chunk with 200 token overlap)
- C. Semantic chunking (split on section headers/paragraphs)

**Default:** Option B (Fixed size: 1000 tokens, 200 overlap)

**Rationale:** Federal Register notices can be 50+ pages. voyage-3 has 16K token context but embeddings work best on focused chunks. Overlap preserves context across boundaries.

---

## Integration Questions

### Q8: Ingestion Failure Handling
**Question:** What happens if Federal Register API is down during scheduled ingestion?

**Options:**
- A. Retry 3 times with exponential backoff, then alert Slack/email
- B. Skip the run, wait for next scheduled run (24 hours later)
- C. Retry indefinitely until success

**Default:** Option A (Retry 3x + alert)

**Rationale:** Federal Register has 99.9% uptime but maintenance windows exist. Retries handle transient failures. Alert ensures humans aware if persistent.

---

### Q9: RAG Query Performance Target
**Question:** What is the SLA for `query_rag_corpus` MCP tool response time?

**Options:**
- A. < 500ms (p95)
- B. < 1 second (p95)
- C. < 3 seconds (p95)

**Default:** Option B (< 1 second p95)

**Rationale:** HNSW index on pgvector should make similarity search fast. 1 second allows for embedding generation (200ms) + pgvector query (500ms) + serialization (300ms). Tighter than 3s agent timeout.

---

### Q10: Storage Estimate
**Question:** What is the expected storage footprint for RAG corpus after 1 year?

**Context:**
- Federal Register publishes ~300 documents/day
- Average document size: 20KB text
- After chunking (1000 tokens): ~5 chunks/document
- Total vectors/year: 300 docs × 365 days × 5 chunks = 547,500 vectors
- pgvector(1024) size: ~4KB per vector
- Storage: 547,500 × 4KB = **2.19 GB/year**

**Options:**
- A. Retain all documents indefinitely (archive to S3 after 2 years, keep embeddings)
- B. Rolling 1-year window (delete embeddings older than 1 year)
- C. Rolling 5-year window (compliance standard)

**Default:** Option C (Rolling 5-year window)

**Rationale:** AD/CVD cases can span 5+ years. HTS classification precedents remain relevant long-term. 5 years = ~11GB pgvector storage (acceptable).

---

## Answers Template

To proceed with Sprint 2 build, please answer:

```
Q1: [A/B/C or custom]
Q2: [A/B/C/D or custom]
Q3: [A/B/C or custom]
Q4: [A/B/C or custom]
Q5: [A/B/C or custom]
Q6: [A/B/C or custom]
Q7: [A/B/C or custom]
Q8: [A/B/C or custom]
Q9: [A/B/C or custom]
Q10: [A/B/C or custom]
```

**Shortcut:** Reply "defaults" to accept all default options.

---

## Sprint 2 Blockers

If any of these are NOT resolved, Sprint 2 build will be blocked:

1. ❓ **VoyageAI API Key** (Q2): Need credentials in AWS Secrets Manager before embedding generation can work.
2. ✅ **pgvector extension** (Sprint 1): Already provisioned in RDS PostgreSQL.
3. ✅ **S3 bucket** (Sprint 1): Already created for document storage.

---

## Next Steps

After receiving answers:
1. Generate Sprint 2 build plan (sequencing: architect → backend → devops → test)
2. Dispatch agents to build RAG ingestion worker + `query_rag_corpus` MCP tool
3. Validate with acceptance tests (daily ingestion + RAG query tool callable)
