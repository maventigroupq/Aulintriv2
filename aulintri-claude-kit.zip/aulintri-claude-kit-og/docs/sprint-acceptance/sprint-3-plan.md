# Sprint 3 Build Plan — Quote Agent Intelligence Layer
**Date:** 2026-03-20
**Phase:** 1 (Months 1-3, Foundations)
**Status:** READY TO BUILD

---

## Sprint 3 Goal

**Primary Objective:** Enhance Quote Agent with RAG-powered HTS classification and carrier rate intelligence

**Exit Criteria:**
- Quote Agent uses RAG corpus for HTS code refinement
- HTS classification confidence scores tracked in agent_action_ledger
- Carrier rate API integrations live (3+ carriers)
- Quote Agent orchestration via AOS (Redis pub/sub)
- Safety score integration (FMCSA API)

---

## Deliverables by Agent

### 1. architect-agent (Sequential - FIRST)
**Files:** `docs/architecture/`, `src/agents/quote/schema.ts`

**Tasks:**
- [ ] Design Quote Agent architecture with RAG integration
- [ ] Create ADR-005: Quote Agent Intelligence Layer
- [ ] Design HTS classification workflow (Claude API + RAG context)
- [ ] Design carrier rate aggregation pattern (3+ carriers)
- [ ] Document AOS handoff pattern: RFQ → Quote Agent → Ops Agent
- [ ] Create Quote Agent state machine (FSM)

---

### 2. backend-agent (Sequential - after architect)
**Files:** `src/agents/quote/`, `src/services/`, `src/mcp/tools/`

**Tasks:**
- [ ] Implement Quote Agent core (`src/agents/quote/agent.ts`):
  - Receive RFQ from AOS (Redis subscription: `aos:handoff:quote`)
  - Extract commodity description from RFQ document
  - Query RAG corpus for relevant HTS precedents
  - Call Claude API with RAG context for HTS classification
  - Track confidence score (0-1.0)
  - Query carrier rate APIs (3 carriers)
  - Query FMCSA safety scores
  - Generate quote summary
  - Publish to AOS: `aos:handoff:ops` (handoff to Ops Agent)
  - Write ledger entries (pre/post execution)

- [ ] Implement carrier rate integrations (`src/services/carrier-rates/`):
  - Freightos API client (ocean freight rates)
  - Flexport API client (ocean freight rates)
  - Convoy API client (drayage rates)
  - Rate aggregation service (merge, dedupe, rank)

- [ ] Implement FMCSA API client (`src/services/fmcsa-client.ts`):
  - Fetch carrier safety data by DOT number
  - Calculate safety score (0-100)
  - Cache results (24h TTL)

- [ ] Enhance `classify_hts_code` MCP tool:
  - Add `use_rag` parameter (boolean, default true)
  - Query RAG corpus for similar commodity descriptions
  - Include RAG context in Claude API prompt
  - Return confidence score + RAG sources used

- [ ] Implement `get_carrier_rates` MCP tool:
  - Aggregate rates from 3+ carriers
  - Return ranked list (by price, transit time, reliability)
  - Cache results (1h TTL)

- [ ] Implement `get_carrier_safety_score` MCP tool:
  - Query FMCSA API
  - Return safety score + violation history
  - Cache results (24h TTL)

---

### 3. test-agent (Sequential - after backend)
**Files:** `tests/integration/agents/`, `tests/acceptance/`

**Tasks:**
- [ ] Write integration tests for Quote Agent:
  - RFQ ingestion from Redis
  - HTS classification with RAG context
  - Carrier rate aggregation
  - Safety score lookup
  - AOS handoff to Ops Agent
  - Ledger writes (pre/post)

- [ ] Write unit tests for carrier rate services (3 clients)
- [ ] Write unit tests for FMCSA client
- [ ] Write integration tests for enhanced MCP tools (classify_hts_code, get_carrier_rates, get_carrier_safety_score)
- [ ] Write acceptance tests for Sprint 3 exit criteria

**Test Fixtures:**
- Sample RFQ documents (5 examples)
- Mock carrier rate API responses
- Mock FMCSA API responses

---

### 4. frontend-agent (Parallel - independent)
**Files:** `src/app/quotes/`, `src/components/quote/`

**Tasks:**
- [ ] Create Quote Dashboard page (`src/app/quotes/page.tsx`)
- [ ] Create Quote Detail page (`src/app/quotes/[id]/page.tsx`)
- [ ] Create QuoteCard component (summary view)
- [ ] Create HTSClassificationResult component (confidence score, RAG sources)
- [ ] Create CarrierRateComparison component (table with sort/filter)
- [ ] Create SafetyScoreBadge component (visual indicator)
- [ ] Create Storybook stories for all components

---

## Build Order (Dependencies)

### Phase A (Week 1, Days 1-2): Architecture
**Sequential:**
1. architect-agent: Quote Agent architecture, ADR-005, FSM design

### Phase B (Week 1, Days 3-5): Core Agent
**Sequential:**
1. backend-agent: Quote Agent core, RAG integration, AOS pub/sub
2. backend-agent: Enhance classify_hts_code MCP tool with RAG

### Phase C (Week 2, Days 1-3): Carrier Integrations
**Sequential:**
1. backend-agent: Carrier rate APIs (Freightos, Flexport, Convoy)
2. backend-agent: FMCSA API client
3. backend-agent: Implement get_carrier_rates and get_carrier_safety_score MCP tools

### Phase D (Week 2, Days 4-5): Testing & UI
**Parallel:**
1. test-agent: Integration tests, acceptance tests
2. frontend-agent: Quote Dashboard, components, Storybook

---

## Acceptance Criteria (Sprint 3 Exit)

### Must Pass (Blocking):
✅ Quote Agent receives RFQ from AOS (Redis)
✅ Quote Agent queries RAG corpus for HTS precedents
✅ classify_hts_code tool returns confidence score >= 0.97 for test cases
✅ Carrier rate aggregation returns data from 3+ carriers
✅ FMCSA safety scores retrieved for test carriers
✅ Quote Agent publishes to AOS (handoff to Ops Agent)
✅ agent_action_ledger tracks all Quote Agent actions
✅ All tests passing (target: 85%+ coverage)

### Nice to Have (Non-blocking):
- Quote Dashboard UI deployed
- Rate comparison chart visualization
- Email notification when quote ready

---

## Technical Notes

### HTS Classification with RAG

**Workflow:**
1. Extract commodity description from RFQ (e.g., "Cotton men's trousers")
2. Query RAG corpus:
   ```typescript
   const ragResults = await queryRagCorpus({
     query: `HTS classification precedents for ${commodityDescription}`,
     filters: { document_type: 'federal_register' },
     top_k: 5
   });
   ```
3. Build Claude API prompt with RAG context:
   ```typescript
   const prompt = `Classify this commodity into the Harmonized Tariff Schedule (HTS):

   Commodity: ${commodityDescription}
   Country of Origin: ${countryOfOrigin}

   Relevant Federal Register precedents:
   ${ragResults.map(r => `- ${r.content} (${r.source_url})`).join('\n')}

   Provide:
   1. HTS code (10 digits)
   2. Confidence score (0-1.0)
   3. Reasoning (reference precedents if used)
   `;
   ```
4. Track confidence score in ledger

**Confidence Routing:**
- >= 0.97 → Fast-path (30s BLC review)
- < 0.97 → Full review (agent explanation required)

### Carrier Rate APIs

**Freightos API:**
- Endpoint: `https://api.freightos.com/v1/ocean-freight/rates`
- Auth: API key in headers
- Rate limit: 100 req/hour
- Coverage: 200+ ocean carriers

**Flexport API:**
- Endpoint: `https://api.flexport.com/v2/ocean/rates`
- Auth: OAuth 2.0
- Rate limit: 500 req/hour
- Coverage: 50+ ocean carriers, includes customs clearance fees

**Convoy API:**
- Endpoint: `https://api.convoy.com/v1/drayage/quotes`
- Auth: API key
- Rate limit: 200 req/hour
- Coverage: US drayage, port-to-door

**Aggregation Strategy:**
- Query all 3 APIs in parallel (Promise.all)
- Merge results, dedupe by carrier
- Rank by: (1) Price, (2) Transit time, (3) Safety score
- Cache for 1 hour (rates volatile)

### FMCSA API

**Endpoint:**
```
GET https://mobile.fmcsa.dot.gov/qc/services/carriers/{dotNumber}
```

**Safety Score Calculation:**
```typescript
function calculateSafetyScore(fmcsaData: FMCSACarrier): number {
  const weights = {
    crashTotal: -5,
    oosTotal: -3,
    inspectionTotal: 2,
    safetyRating: 20 // 'Satisfactory' = 100, 'Conditional' = 50, 'Unsatisfactory' = 0
  };

  const score = 50 + // Baseline
    (weights.crashTotal * fmcsaData.crashTotal / 100) +
    (weights.oosTotal * fmcsaData.oosTotal / 100) +
    (weights.inspectionTotal * fmcsaData.inspectionTotal / 100) +
    (fmcsaData.safetyRating === 'SATISFACTORY' ? 20 :
     fmcsaData.safetyRating === 'CONDITIONAL' ? 10 : 0);

  return Math.max(0, Math.min(100, score));
}
```

### AOS Handoff Pattern

**RFQ → Quote Agent:**
```typescript
// Published by RFQ ingestion
redis.publish('aos:handoff:quote', JSON.stringify({
  session_id: 'session_123',
  rfq_id: 'rfq_456',
  customer_id: 'customer_789',
  commodity: 'Steel pipes',
  origin: 'CNSHA',
  destination: 'USLAX',
  cargo_ready_date: '2025-04-01'
}));
```

**Quote Agent → Ops Agent:**
```typescript
// Published by Quote Agent
redis.publish('aos:handoff:ops', JSON.stringify({
  session_id: 'session_123',
  quote_id: 'quote_101',
  hts_code: '7306.30.50.00',
  hts_confidence: 0.98,
  carrier_recommendations: [
    { carrier: 'Maersk', rate_usd: 2500, transit_days: 18, safety_score: 95 },
    { carrier: 'MSC', rate_usd: 2300, transit_days: 20, safety_score: 92 }
  ],
  next_action: 'book_carrier' // Ops Agent decides
}));
```

---

## Dependencies

### From Sprint 1:
- ✅ MCP Server (4 tools registered)
- ✅ agent_action_ledger (pre-execution writes)
- ✅ Redis (AOS pub/sub)

### From Sprint 2:
- ✅ RAG corpus (Federal Register documents)
- ✅ query_rag_corpus MCP tool

### New for Sprint 3:
- ❓ **Carrier API keys:** Freightos, Flexport, Convoy (store in Secrets Manager)
- ❓ **FMCSA API access:** Free, no auth required (but rate limited to 100/day)
- ❓ **Claude API quota:** Ensure sufficient quota for HTS classifications (~1000 calls/day)

---

## Risk Register

| Risk | Mitigation | Owner |
|------|------------|-------|
| Carrier APIs unavailable | Use mock data for testing, deploy stubs | backend-agent |
| Claude API quota exceeded | Implement rate limiting, cache results | backend-agent |
| RAG context too large (>100K tokens) | Limit to top-3 results instead of top-5 | backend-agent |
| HTS confidence scores too low | Fine-tune prompt engineering, add more RAG examples | backend-agent |
| FMCSA API rate limit (100/day) | Cache results for 7 days instead of 24h | backend-agent |

---

## Post-Sprint 3 Handoff

After Sprint 3:
- Quote Agent live with RAG-powered HTS classification
- Carrier rate comparison available via MCP tools
- Safety scores integrated into carrier recommendations
- Ready for Sprint 4: Expand to Mexico operations

---

## Next Steps

**Sprint 4:** Mexico Operations (Spanish translation, SAT integration)
**Sprint 5:** Ops Agent (booking confirmation, shipment tracking)
**Sprint 6:** FAN cross-tenant threat sharing (anomaly detection)
