# Sprint 1 Build Plan — Foundation Setup
**Date:** 2026-03-20
**Phase:** 1 (Months 1-3, Foundations)
**Status:** READY TO BUILD

---

## Answers Applied

**Architecture Decisions:**
- Q1: **us-east-1** (confirmed)
- Q2: **Fastify** (confirmed)
- Q3: **voyage-3 (1024 dims)** (default)
- Q4: **cache.t3.micro** (default)

**Business Rules:**
- Q5: **0.97 confidence threshold** (default)
- Q6: **BLC review all entries** (default - no auto-filing initially)
- Q7: **Blocking AD/CVD acknowledgement** (default)

**Integration Prerequisites:**
- Q8: **ABI vendor TBD** (Sprint 7 blocker if not resolved by Sprint 6)
- Q9: **Mexico engineer TBD** (will scaffold for handoff if needed)

---

## Sprint 1 Goal

**Primary Objective:** Establish MCP-native foundation with core infrastructure
**Exit Criteria:**
- MCP Server live with 4 tools registered
- PostgreSQL RDS with RLS policies active
- agent_action_ledger table enforcing pre-execution writes
- AWS infrastructure (VPC, RDS, ElastiCache, S3, Cognito) provisioned in us-east-1

---

## Deliverables by Agent

### 1. architect-agent (Sequential - FIRST)
**Files:** `prisma/schema.prisma`, `src/mcp/registry.ts`, `docs/architecture/`

**Tasks:**
- [ ] Design complete Prisma schema with:
  - Multi-tenant base (tenant table with RLS)
  - agent_action_ledger (all fields NOT NULL)
  - FAN schema (threat_events with anonymization_status)
  - shipments, quotes, entries, documents
  - pgvector(1024) for RAG embeddings (voyage-3)
- [ ] Design MCP tool registry structure
- [ ] Design AOS (Agent Orchestration System) Redis pub/sub patterns
- [ ] Create ADR-002: Multi-tenant RLS strategy
- [ ] Create ADR-003: agent_action_ledger pre-execution pattern

---

### 2. devops-agent (Parallel - after architect schema design)
**Files:** `infra/`, `Dockerfile`, `.github/workflows/`

**Tasks:**
- [ ] Provision AWS VPC in us-east-1 (private/public subnets)
- [ ] Provision RDS PostgreSQL 16 with pgvector extension
- [ ] Provision ElastiCache Redis (cache.t3.micro)
- [ ] Provision S3 bucket with key pattern: `{tenant_id}/{shipment_id}/{document_type}/{filename}`
- [ ] Provision Cognito User Pool with 5 roles:
  - ADMIN, BLX_OPS, BLC_BROKER, CUSTOMER, MCP_AGENT
- [ ] Configure AWS Secrets Manager for all credentials
- [ ] Set up GitHub Actions CI/CD pipeline
- [ ] Create Dockerfile for Fastify app
- [ ] Document environment variables in `.env.example`

---

### 3. backend-agent (Sequential - after architect + devops)
**Files:** `src/api/`, `src/mcp/`, `src/agents/`, `src/workers/`

**Tasks:**
- [ ] Scaffold Fastify app with @modelcontextprotocol/sdk plugin
- [ ] Implement MCP Server in `src/mcp/server.ts`
- [ ] Implement ledger service (pre-execution writes to agent_action_ledger)
- [ ] Implement 4 MCP tools (Sprint 1-3 tools):
  - `extract_rfq_data(document_s3_key)` → QuoteRequest
  - `classify_hts_code(commodity_description, country_of_origin, prior_classifications[])` → HTSResult
  - `get_carrier_rates(origin_port, dest_port, container_type, cargo_date)` → RateOption[]
  - `get_carrier_safety_score(dot_number)` → SafetyScore
- [ ] Register all 4 tools in `src/mcp/registry.ts`
- [ ] Implement AOS Redis pub/sub scaffold in `src/agents/orchestration/`
- [ ] Create Quote Agent scaffold in `src/agents/quote/`
- [ ] Implement Cognito JWT validation middleware
- [ ] Write Prisma migration scripts
- [ ] Apply RLS policies to all tables

---

### 4. frontend-agent (Parallel - independent of backend)
**Files:** `src/app/`, `src/components/`, `storybook/`

**Tasks:**
- [ ] Set up Next.js 15 app with TypeScript + Tailwind CSS
- [ ] Set up Storybook 8
- [ ] Create 10 primitive components with stories:
  - Button, Input, Select, Textarea, Card, Modal, Alert, Badge, Table, Spinner
- [ ] Create layout components:
  - AppShell, Sidebar, Header, Footer
- [ ] Create authentication pages (Cognito integration):
  - Login, Register, Password Reset
- [ ] Create dashboard scaffold (empty state)
- [ ] Implement Cognito session management

---

### 5. customs-agent (Documentation only - Sprint 1)
**Files:** `src/customs/`, `docs/customs/`

**Tasks:**
- [ ] Document CATAIR EDI format requirements for Sprint 7
- [ ] Document ISF 10+2 requirements
- [ ] Document entry summary format (7501)
- [ ] Create PGA matrix (FDA, USDA, EPA, CPSC, TTB requirements by HTS chapter)
- [ ] Document AD/CVD lookup requirements
- [ ] Create compliance screening checklist

---

### 6. test-agent (Sequential - after backend tools built)
**Files:** `tests/`, `src/__tests__/`, `acceptance/`

**Tasks:**
- [ ] Set up Jest + Supertest
- [ ] Write integration tests for 4 MCP tools
- [ ] Write unit tests for ledger service
- [ ] Write acceptance tests for Sprint 1 exit criteria:
  - MCP Server responds to `tools/list` JSON-RPC call
  - All 4 tools callable via MCP protocol
  - agent_action_ledger records written before tool execution
  - RLS policies block cross-tenant queries
  - FAN threat_events query respects anonymization rules
- [ ] Create test fixtures for quote documents
- [ ] Document test data setup in README

---

## Build Order (Dependencies)

### Phase A (Week 1, Days 1-2): Foundation
**Sequential:**
1. architect-agent: Complete Prisma schema design
2. devops-agent: Provision AWS infrastructure

### Phase B (Week 1, Days 3-5): Core Services
**Parallel (3 agents):**
1. backend-agent: Fastify app + MCP Server + ledger service
2. frontend-agent: Next.js setup + Storybook + primitive components
3. customs-agent: Documentation

### Phase C (Week 2, Days 1-3): MCP Tools
**Sequential:**
1. backend-agent: Implement 4 MCP tools + AOS scaffold

### Phase D (Week 2, Days 4-5): Testing & Integration
**Sequential:**
1. test-agent: Integration tests + acceptance tests
2. All agents: Bug fixes from test failures

---

## Acceptance Criteria (Sprint 1 Exit)

### Must Pass (Blocking):
✅ MCP Server responds to `tools/list` with 4 registered tools
✅ Each tool callable via JSON-RPC 2.0 MCP protocol
✅ agent_action_ledger writes pre-execution record BEFORE tool handler runs
✅ PostgreSQL RLS blocks cross-tenant queries (test with 2 tenants)
✅ FAN threat_events query respects anonymization_status='cleared' AND shared=true
✅ All tests passing in CI/CD pipeline
✅ Deployed to AWS dev environment (us-east-1)

### Nice to Have (Non-blocking):
- Storybook deployed to static hosting
- Basic UI navigation working (login → dashboard)
- Mexico engineer onboarded and able to run locally

---

## Risk Register

| Risk | Mitigation | Owner |
|------|------------|-------|
| pgvector extension not available on RDS tier | Verify RDS PostgreSQL 16 supports pgvector before provisioning | devops-agent |
| MCP SDK breaking changes | Pin @modelcontextprotocol/sdk to specific version | backend-agent |
| Cognito RBAC complexity | Start with simple role-based access, iterate in Sprint 2 | backend-agent |
| Mexico engineer unavailable | Document handoff extensively, scaffold all files | architect-agent |

---

## Post-Sprint 1 Handoff

For Mexico engineer (if starting after Sprint 1):
- Review ADR-001 (MCP-First) and ADR-002/003 (created in Sprint 1)
- Run `npm install && npx prisma migrate dev`
- Review MCP tool implementations in `src/mcp/tools/`
- Test MCP Server locally: `curl -X POST http://localhost:3000/mcp -d '{"jsonrpc":"2.0","method":"tools/list","id":1}'`

---

## Next Steps

After Sprint 1 completion, ready to begin:
- **Sprint 2:** RAG pipeline ingestion (Federal Register daily scraper)
- **Sprint 3:** Quote Agent intelligence layer (HTS classification refinement)
