# ADR-001: MCP-First Architecture — All Capabilities as MCP Tools

**Date:** February 2026
**Status:** ACCEPTED
**Deciders:** Quinn Eaden (Product Owner), Lead Engineer

---

## Context

The original SOW v1.0 planned point-to-point REST API integrations for carrier connections in Sprints 13–15. Due-diligence identified this as obsolete in an enterprise AI agent environment where Salesforce Agentforce, SAP Joule, and 3PL-proprietary AI systems consume external capabilities via Model Context Protocol (MCP), not bespoke REST endpoints.

## Decision

**Every Aulintri capability that could be called by an external system is implemented as an MCP tool from day one, not as a REST endpoint.**

The MCP Server is scaffolded in Sprint 1, Week 1 — not deferred to Phase 3. Every tool function built in Phases 1 and 2 is registered as an MCP capability on the day it is built.

### MCP Tool Implementation Contract

```typescript
interface MCPTool {
  name: string;                    // snake_case, globally unique
  description: string;             // Used by external agents for tool discovery
  inputSchema: JSONSchema;         // Validated BEFORE handler execution
  handler: (input, context) => Promise<unknown>;
}
```

### What Gets MCP-Registered (every capability):
- `extract_rfq_data` — quote intake
- `classify_hts_code` — HTS classification
- `get_carrier_rates` — BLX contracted rates
- `get_carrier_safety_score` — FMCSA screening
- `submit_isf_filing` — ABI ISF transmission
- `draft_entry_summary` — entry preparation
- `calculate_duties` — duty calculation
- `book_ocean_freight` — carrier booking
- All PGA tools, drawback, FTZ, compliance screening

### What Does NOT Get MCP-Registered:
- Internal database queries (not callable by external agents)
- UI rendering logic
- Auth/session management

## Consequences

### Positive
- External AI agents (Agentforce, SAP Joule) consume Aulintri capabilities without any UI interaction
- Adding a new carrier in Year 2 = adding one MCP tool handler (not a bespoke REST integration)
- MCP tool discovery (`tools/list`) eliminates external API documentation maintenance
- Token-scoped access control: Platform tier gets customs tools, NOT carrier rate data

### Negative
- Higher upfront complexity in Sprint 1 (MCP Server plugin vs simple REST routes)
- JSON-RPC 2.0 is less familiar than REST to some engineers

### Neutral
- REST adapter layer available if needed: `/api/v1/classify` → calls `classify_hts_code` internally

## Security Implications

JSON injection via MCP tool inputs is the primary attack vector. Mitigation:
- All tool inputs validated against JSON Schema BEFORE handler execution
- Validated data only — no raw string interpolation into Claude API system prompts
- Capability tokens are JWT-scoped: a token grants access to specific tools only
- Token scope enforced at the MCP Server layer before handler is called

## Implementation Reference

- MCP Server: `src/mcp/server.ts`
- Tool Registry: `src/mcp/registry.ts`
- Tool implementations: `src/mcp/tools/*.ts`
