export const prisma = {
  $connect: async () => undefined,
  $disconnect: async () => undefined,
  $queryRaw: async (..._args: unknown[]) => [],
  $executeRaw: async (..._args: unknown[]) => 0,
  agentActionLedger: {
    create: async (_args: unknown) => undefined,
    update: async (_args: unknown) => undefined,
    findMany: async (_args?: unknown) => [],
    findUnique: async (_args?: unknown) => undefined,
  },
  shipment: {
    create: async (_args: unknown) => undefined,
    findMany: async (_args?: unknown) => [],
    findUnique: async (_args?: unknown) => undefined,
  },
  tenant: {
    create: async (_args: unknown) => undefined,
    findUnique: async (_args?: unknown) => undefined,
  },
  threatEvent: {
    create: async (_args: unknown) => undefined,
    findMany: async (_args?: unknown) => [],
  },
};
