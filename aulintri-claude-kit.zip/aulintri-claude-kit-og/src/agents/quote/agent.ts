/**
 * Quote Agent - RAG-Powered HTS Classification & Carrier Rate Aggregation
 * Aulintri Sprint 3
 */

import { PrismaClient } from '@prisma/client';
import { createClient, RedisClientType } from 'redis';
import { RFQPayload, QuoteOutput, QuoteAgentState } from './types';
import { classifyHTSWithRAG } from './hts-classifier';
import { aggregateCarrierRates } from './carrier-aggregator';
import { fetchSafetyScore } from './fmcsa-client';
import { publishHandoff } from '../orchestration/handoff-client';

const prisma = new PrismaClient();

export class QuoteAgent {
  private redis: RedisClientType;
  private state: QuoteAgentState = 'IDLE';
  private sessionId: string | null = null;

  constructor() {
    this.redis = createClient({
      url: process.env.REDIS_URL || 'redis://localhost:6379',
    });
  }

  async start(): Promise<void> {
    await this.redis.connect();
    await this.redis.subscribe('aos:handoff:quote', this.handleRFQ.bind(this));
    console.log('[QuoteAgent] Subscribed to aos:handoff:quote');
  }

  private async handleRFQ(message: string): Promise<void> {
    try {
      const rfq: RFQPayload = JSON.parse(message);
      this.sessionId = rfq.session_id;

      console.log(`[QuoteAgent] Received RFQ ${rfq.rfq_id} for session ${this.sessionId}`);

      // Acquire lock to prevent duplicate processing
      const lockAcquired = await this.redis.set(
        `aos:lock:${this.sessionId}`,
        'quote_agent',
        { NX: true, EX: 60 }
      );

      if (!lockAcquired) {
        console.warn(`[QuoteAgent] Session ${this.sessionId} already locked`);
        return;
      }

      // Write pre-execution ledger entry
      await prisma.agentActionLedger.create({
        data: {
          tenant_id: rfq.tenant_id,
          action_type: 'quote_generation',
          reserve_allocated: 0.03, // $0.03 per quote (Claude API cost)
          burst_billable: false,
          outcome_type: 'pending',
          outcome_value_usd: 0,
          sla_met: null,
          confidence_score: null,
          metadata: { session_id: this.sessionId, rfq_id: rfq.rfq_id },
        },
      });

      // Execute Quote Agent FSM
      const quote = await this.executeQuotePipeline(rfq);

      // Publish handoff to Ops Agent
      await publishHandoff('ops', {
        session_id: this.sessionId,
        tenant_id: rfq.tenant_id,
        quote_id: quote.quote_id,
        hts_classification: quote.hts_classification,
        carrier_recommendations: quote.carrier_rates,
        next_action: 'book_carrier',
      });

      // Write post-execution ledger entry
      await prisma.agentActionLedger.create({
        data: {
          tenant_id: rfq.tenant_id,
          action_type: 'quote_generation',
          reserve_allocated: 0,
          burst_billable: false,
          outcome_type: 'quote_generated',
          outcome_value_usd: quote.total_cost_usd,
          sla_met: quote.generation_time_ms < 30000, // SLA: < 30s
          confidence_score: quote.hts_classification.confidence,
          metadata: { session_id: this.sessionId, quote_id: quote.quote_id },
        },
      });

      // Release lock
      await this.redis.del(`aos:lock:${this.sessionId}`);

      console.log(`[QuoteAgent] Quote ${quote.quote_id} generated and handed off to Ops Agent`);

    } catch (error: any) {
      console.error('[QuoteAgent] Error processing RFQ:', error);
      this.state = 'FAILED';

      if (this.sessionId) {
        await this.redis.publish('aos:dlq', JSON.stringify({
          session_id: this.sessionId,
          error: error.message,
          timestamp: new Date().toISOString(),
        }));
        await this.redis.del(`aos:lock:${this.sessionId}`);
      }
    }
  }

  private async executeQuotePipeline(rfq: RFQPayload): Promise<QuoteOutput> {
    const startTime = Date.now();

    // State: EXTRACTING_COMMODITY
    this.state = 'EXTRACTING_COMMODITY';
    const commodityDescription = rfq.commodity_description || rfq.commodity;

    // State: QUERYING_RAG + CLASSIFYING_HTS
    this.state = 'QUERYING_RAG';
    const htsResult = await classifyHTSWithRAG({
      commodityDescription,
      countryOfOrigin: rfq.country_of_origin,
      priorClassifications: [],
    });

    if (htsResult.confidence < 0.50) {
      throw new Error(`HTS confidence too low: ${htsResult.confidence}`);
    }

    // State: FETCHING_RATES
    this.state = 'FETCHING_RATES';
    const carrierRates = await aggregateCarrierRates({
      originPort: rfq.origin_port,
      destPort: rfq.destination_port,
      containerType: rfq.container_type || '20GP',
      cargoReadyDate: rfq.cargo_ready_date,
    });

    if (carrierRates.length < 2) {
      throw new Error('Insufficient carrier rates (minimum 2 required)');
    }

    // State: CHECKING_SAFETY
    this.state = 'CHECKING_SAFETY';
    const carrierRatesWithSafety = await Promise.all(
      carrierRates.map(async (rate) => {
        try {
          const safetyScore = await fetchSafetyScore(rate.carrier_dot_number);
          return { ...rate, safety_score: safetyScore.score };
        } catch (error) {
          // Fallback to carrier self-report or default score
          return { ...rate, safety_score: 75 };
        }
      })
    );

    // State: GENERATING_QUOTE
    this.state = 'GENERATING_QUOTE';
    const rankedRates = this.rankCarriers(carrierRatesWithSafety);

    const quote: QuoteOutput = {
      quote_id: `quote_${Date.now()}`,
      session_id: rfq.session_id,
      rfq_id: rfq.rfq_id,
      tenant_id: rfq.tenant_id,
      hts_classification: htsResult,
      carrier_rates: rankedRates,
      total_cost_usd: rankedRates[0].total_cost_usd, // Cheapest ranked carrier
      generation_time_ms: Date.now() - startTime,
      created_at: new Date().toISOString(),
    };

    this.state = 'COMPLETED';
    return quote;
  }

  private rankCarriers(carriers: any[]): any[] {
    return carriers
      .map((carrier) => {
        const maxPrice = Math.max(...carriers.map(c => c.ocean_freight_usd));
        const maxTransit = Math.max(...carriers.map(c => c.transit_days));

        const normalizedPrice = carrier.ocean_freight_usd / maxPrice;
        const normalizedTransit = carrier.transit_days / maxTransit;
        const normalizedSafety = (100 - carrier.safety_score) / 100;

        const score = (normalizedPrice * 0.5) + (normalizedTransit * 0.3) + (normalizedSafety * 0.2);

        return { ...carrier, rank_score: score };
      })
      .sort((a, b) => a.rank_score - b.rank_score); // Lower score = better rank
  }

  async stop(): Promise<void> {
    await this.redis.quit();
    await prisma.$disconnect();
  }
}

// Singleton instance
export const quoteAgent = new QuoteAgent();
