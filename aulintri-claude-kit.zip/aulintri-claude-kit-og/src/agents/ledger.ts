// src/agents/ledger.ts
// Agent Action Ledger — Source of truth for Burstable Reserve billing, SLA reporting, E&O underwriting
// EVERY Claude API call writes here BEFORE execution. No exceptions.

import { db } from '../db';
import { v4 as uuidv4 } from 'uuid';

interface PreExecutionRecord {
  tenant_id: string;
  action_type: string;
  reserve_allocated: boolean;
  shipment_id?: string;
  quote_id?: string;
}

interface PostExecutionRecord {
  sla_met: boolean;
  confidence_score: number;
  outcome_type?: string;
  outcome_value_usd?: number;
  burst_billable?: boolean;
}

class AgentActionLedger {
  /**
   * Write a pre-execution record BEFORE any Claude API call.
   * This is MANDATORY — called even when failure is anticipated.
   * Returns the action_id needed for the post-execution write.
   */
  async writePre(record: PreExecutionRecord): Promise<string> {
    const actionId = uuidv4();

    try {
      await db.agentActionLedger.create({
        data: {
          id: actionId,
          tenant_id: record.tenant_id,
          action_type: record.action_type,
          record_type: 'pre',
          reserve_allocated: record.reserve_allocated,
          shipment_id: record.shipment_id,
          quote_id: record.quote_id,
          // These will be filled in by writePost
          sla_met: false,         // Pessimistic default — updated by writePost
          confidence_score: 0,    // Updated by writePost
          burst_billable: false,
        },
      });
    } catch (ledgerError) {
      // Ledger write failure is a CRITICAL error — it corrupts SLA dataset
      // and E&O underwriting. Alert immediately, do not silently continue.
      console.error('[LEDGER CRITICAL] Pre-execution write failed:', {
        action_id: actionId,
        tenant_id: record.tenant_id,
        action_type: record.action_type,
        error: (ledgerError as Error).message,
      });
      // Re-throw — the caller should NOT proceed if ledger is broken
      throw new Error(`Ledger pre-execution write failed: ${(ledgerError as Error).message}`);
    }

    return actionId;
  }

  /**
   * Update the pre-execution record after the action completes (success or failure).
   * Must be called even on failure — incomplete dataset corrupts E&O underwriting.
   */
  async writePost(actionId: string, record: PostExecutionRecord): Promise<void> {
    try {
      // Check if burst applies: compare reserve_consumed vs allotment
      const existing = await db.agentActionLedger.findUnique({ where: { id: actionId } });
      if (!existing) {
        throw new Error(`Pre-execution record not found for action_id: ${actionId}`);
      }

      const isBurstBillable = record.burst_billable ?? await this.checkIfBurstBillable(
        existing.tenant_id,
        existing.action_type
      );

      // Create a new post record (pre and post are separate rows for audit trail)
      await db.agentActionLedger.create({
        data: {
          tenant_id: existing.tenant_id,
          action_type: existing.action_type,
          record_type: 'post',
          reserve_allocated: existing.reserve_allocated,
          burst_billable: isBurstBillable,
          shipment_id: existing.shipment_id,
          quote_id: existing.quote_id,
          sla_met: record.sla_met,
          confidence_score: record.confidence_score,
          outcome_type: record.outcome_type,
          outcome_value_usd: record.outcome_value_usd,
        },
      });

      // Update the pre record's sla_met for quick querying
      await db.agentActionLedger.update({
        where: { id: actionId },
        data: {
          sla_met: record.sla_met,
          confidence_score: record.confidence_score,
          outcome_type: record.outcome_type,
          outcome_value_usd: record.outcome_value_usd,
          burst_billable: isBurstBillable,
        },
      });

    } catch (ledgerError) {
      // Post-execution write failure is also CRITICAL
      console.error('[LEDGER CRITICAL] Post-execution write failed:', {
        action_id: actionId,
        error: (ledgerError as Error).message,
      });
      // Log but don't re-throw here — action already completed, don't fail the user
      // Alert the ops team via SES
      await this.alertOpsTeam(actionId, ledgerError as Error);
    }
  }

  /**
   * Check if this action exceeds the tenant's monthly reserve allotment
   * (would be burst-billable at the overage rate).
   */
  private async checkIfBurstBillable(tenantId: string, actionType: string): Promise<boolean> {
    const org = await db.organization.findUnique({
      where: { id: tenantId },
      select: { billing_tier: true, monthly_entry_allotment: true, monthly_isf_allotment: true, monthly_tool_call_allotment: true },
    });
    if (!org) return false;

    const periodStart = new Date();
    periodStart.setDate(1);
    periodStart.setHours(0, 0, 0, 0);

    const consumed = await db.agentActionLedger.count({
      where: {
        tenant_id: tenantId,
        action_type: actionType,
        record_type: 'post',
        timestamp: { gte: periodStart },
      },
    });

    // Determine allotment based on action type and tier
    let allotment = org.monthly_tool_call_allotment;
    if (actionType === 'draft_entry_summary' || actionType === 'submit_isf_filing') {
      allotment = actionType.includes('isf')
        ? org.monthly_isf_allotment
        : org.monthly_entry_allotment;
    }

    return consumed >= allotment;
  }

  private async alertOpsTeam(actionId: string, error: Error): Promise<void> {
    // TODO: SES alert to ops team
    console.error('[LEDGER ALERT] Ops team notification:', { actionId, error: error.message });
  }

  /**
   * Query SLA metrics for E&O reporting.
   * Excludes migration data (data_source = 'migration').
   */
  async getSLAMetrics(tenantId: string | null, dateRange: { start: Date; end: Date }) {
    const whereClause = {
      record_type: 'post' as const,
      data_source: 'live',
      timestamp: { gte: dateRange.start, lte: dateRange.end },
      ...(tenantId ? { tenant_id: tenantId } : {}),
    };

    const [total, met, byActionType] = await Promise.all([
      db.agentActionLedger.count({ where: whereClause }),
      db.agentActionLedger.count({ where: { ...whereClause, sla_met: true } }),
      db.agentActionLedger.groupBy({
        by: ['action_type'],
        where: whereClause,
        _count: { id: true },
        _avg: { confidence_score: true },
      }),
    ]);

    return {
      overall_sla_rate: total > 0 ? met / total : null,
      total_actions: total,
      by_action_type: byActionType.map(g => ({
        action_type: g.action_type,
        count: g._count.id,
        avg_confidence: g._avg.confidence_score,
      })),
    };
  }

  /**
   * Verify ledger chain completeness for a shipment (used in sprint UAT).
   * Every pre record must have a corresponding post record.
   */
  async verifyChainCompleteness(shipmentId: string): Promise<{ complete: boolean; gaps: string[] }> {
    const allRecords = await db.agentActionLedger.findMany({
      where: { shipment_id: shipmentId },
      orderBy: { timestamp: 'asc' },
    });

    const preIds = new Set(allRecords.filter(r => r.record_type === 'pre').map(r => r.id));
    const postActionTypes = new Set(allRecords.filter(r => r.record_type === 'post').map(r => r.action_type));

    const gaps: string[] = [];
    for (const record of allRecords.filter(r => r.record_type === 'pre')) {
      if (!postActionTypes.has(record.action_type)) {
        gaps.push(`Missing post record for action: ${record.action_type} (${record.id})`);
      }
    }

    return { complete: gaps.length === 0, gaps };
  }
}

export const ledger = new AgentActionLedger();
