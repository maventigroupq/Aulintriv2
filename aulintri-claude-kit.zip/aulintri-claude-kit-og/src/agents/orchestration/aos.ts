// src/agents/orchestration/aos.ts
// Agent Orchestration System (AOS)
// Governs cross-agent handoffs. Only ONE agent holds write authority at a time.
// State persisted in Redis. Prevents concurrent modification of shipment records.

import { redis } from '../../db/redis';

type AgentType = 'QUOTE_AGENT' | 'CLEARANCE_AGENT' | 'OPS_AGENT';

interface AOSSession {
  session_id: string;
  tenant_id: string;
  shipment_id: string;
  active_agent: AgentType;
  handoff_context: HandoffContext | null;
  action_log: HandoffLogEntry[];
  created_at: number;
  updated_at: number;
}

interface HandoffContext {
  // Quote Agent → Clearance Agent
  quote_id?: string;
  commodity_desc?: string;
  hts_candidates?: string[];
  confirmed_coo?: string;
  ad_cvd_alerts?: unknown[];
  ior_id?: string;
  vessel_eta_estimate?: string;
  // Clearance Agent → Ops Agent
  isf_filed?: boolean;
  entry_draft_id?: string;
  fan_threat_level?: number;
  estimated_exposure_usd?: number;
}

interface HandoffLogEntry {
  from: AgentType;
  to: AgentType;
  at: number;
  reason?: string;
}

const SESSION_TTL = 60 * 60 * 24 * 30; // 30 days

class AgentOrchestrationSystem {
  private sessionKey(shipmentId: string): string {
    return `aos:${shipmentId}`;
  }

  /**
   * Initialize a new AOS session when a shipment is created.
   * Quote Agent starts with write authority.
   */
  async initSession(params: {
    session_id: string;
    tenant_id: string;
    shipment_id: string;
    initial_agent?: AgentType;
  }): Promise<AOSSession> {
    const session: AOSSession = {
      session_id: params.session_id,
      tenant_id: params.tenant_id,
      shipment_id: params.shipment_id,
      active_agent: params.initial_agent ?? 'QUOTE_AGENT',
      handoff_context: null,
      action_log: [],
      created_at: Date.now(),
      updated_at: Date.now(),
    };

    await redis.set(
      this.sessionKey(params.shipment_id),
      JSON.stringify(session),
      'EX',
      SESSION_TTL
    );

    return session;
  }

  /**
   * Get current session state.
   */
  async getSession(shipmentId: string): Promise<AOSSession | null> {
    const raw = await redis.get(this.sessionKey(shipmentId));
    if (!raw) return null;
    return JSON.parse(raw);
  }

  /**
   * Perform a handoff between agents.
   * Releases write authority from fromAgent, grants it to toAgent.
   * After handoff, fromAgent CANNOT write to the shipment record.
   */
  async handoff(params: {
    shipment_id: string;
    from_agent: AgentType;
    to_agent: AgentType;
    context: HandoffContext;
    reason?: string;
  }): Promise<AOSSession> {
    const sessionKey = this.sessionKey(params.shipment_id);

    // Use Redis WATCH for optimistic concurrency (prevent race conditions)
    let session: AOSSession | null = null;
    let attempts = 0;

    while (attempts < 3) {
      session = await this.getSession(params.shipment_id);

      if (!session) {
        throw new Error(`No AOS session found for shipment: ${params.shipment_id}`);
      }

      // Enforce write authority — only the active agent can hand off
      if (session.active_agent !== params.from_agent) {
        throw new Error(
          `Handoff rejected: ${params.from_agent} does not hold write authority. ` +
          `Current holder: ${session.active_agent}`
        );
      }

      const updatedSession: AOSSession = {
        ...session,
        active_agent: params.to_agent,
        handoff_context: params.context,
        action_log: [
          ...session.action_log,
          {
            from: params.from_agent,
            to: params.to_agent,
            at: Date.now(),
            reason: params.reason,
          },
        ],
        updated_at: Date.now(),
      };

      // Atomic update with optimistic locking
      const result = await redis.set(
        sessionKey,
        JSON.stringify(updatedSession),
        'EX',
        SESSION_TTL,
        'XX' // Only set if key exists (prevents phantom writes)
      );

      if (result === 'OK') {
        console.log(`[AOS] Handoff: ${params.from_agent} → ${params.to_agent} for shipment ${params.shipment_id}`);
        return updatedSession;
      }

      // Retry on concurrent modification
      attempts++;
      await new Promise(resolve => setTimeout(resolve, 50 * attempts));
    }

    throw new Error('AOS handoff failed after 3 attempts — concurrent modification detected');
  }

  /**
   * Assert that a given agent has write authority.
   * Called before any write operation on a shipment.
   */
  async assertWriteAuthority(shipmentId: string, agent: AgentType): Promise<void> {
    const session = await this.getSession(shipmentId);
    if (!session) {
      throw new Error(`No AOS session for shipment: ${shipmentId}`);
    }
    if (session.active_agent !== agent) {
      throw new Error(
        `${agent} attempted write but lacks authority. ` +
        `Current holder: ${session.active_agent}`
      );
    }
  }

  /**
   * Ops Agent can be activated by any trigger (Customs Hold, D&D, FAN alert).
   * This is a special case — Ops Agent activation doesn't require a standard handoff.
   */
  async activateOpsAgent(params: {
    shipment_id: string;
    trigger: 'CUSTOMS_HOLD' | 'DD_EXPIRY' | 'FAN_ALERT' | 'ISF_REJECTION';
    estimated_exposure_usd: number;
  }): Promise<AOSSession> {
    const session = await this.getSession(params.shipment_id);
    if (!session) {
      throw new Error(`No AOS session for shipment: ${params.shipment_id}`);
    }

    const updatedSession: AOSSession = {
      ...session,
      active_agent: 'OPS_AGENT',
      handoff_context: {
        ...session.handoff_context,
        estimated_exposure_usd: params.estimated_exposure_usd,
      },
      action_log: [
        ...session.action_log,
        {
          from: session.active_agent,
          to: 'OPS_AGENT',
          at: Date.now(),
          reason: `Triggered by: ${params.trigger}`,
        },
      ],
      updated_at: Date.now(),
    };

    await redis.set(
      this.sessionKey(params.shipment_id),
      JSON.stringify(updatedSession),
      'EX',
      SESSION_TTL
    );

    console.log(`[AOS] Ops Agent activated for shipment ${params.shipment_id} — trigger: ${params.trigger}, exposure: $${params.estimated_exposure_usd}`);
    return updatedSession;
  }
}

export const aos = new AgentOrchestrationSystem();
