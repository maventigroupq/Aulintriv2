import { prisma } from '@/db/prisma';

type LedgerWriteInput = {
  tenant_id: string;
  action_type: string;
  tenant_reserve_balance?: number;
  metadata?: Record<string, unknown>;
  related_entity_type?: string;
  related_entity_id?: string;
};

type LedgerUpdateInput = {
  outcome_type?: string;
  outcome_value_usd?: number;
  sla_met?: boolean;
  confidence_score?: number;
  error_message?: string;
  execution_time_ms?: number;
};

const ACTION_COSTS: Record<string, number> = {
  extract_rfq: 0.15,
  classify_hts: 0.25,
  get_carrier_rates: 0.1,
  get_carrier_safety_score: 0.05,
  submit_isf: 0.75,
};

function getActionCost(actionType: string): number {
  return ACTION_COSTS[actionType] ?? 0.1;
}

export async function writeLedgerEntry(input: LedgerWriteInput) {
  const cost = getActionCost(input.action_type);
  const reserveBalance = input.tenant_reserve_balance ?? cost;
  const reserveAllocated = reserveBalance > 0 ? cost : 0;
  const burstBillable = reserveBalance > 0 ? 0 : cost;

  return prisma.agentActionLedger.create({
    data: {
      action_id: `action_${Date.now()}`,
      tenant_id: input.tenant_id,
      action_type: input.action_type,
      reserve_allocated: reserveAllocated,
      burst_billable: burstBillable,
      outcome_type: 'pending',
      outcome_value_usd: 0,
      sla_met: false,
      confidence_score: 0,
      metadata: input.metadata,
      related_entity_type: input.related_entity_type,
      related_entity_id: input.related_entity_id,
      timestamp: new Date(),
    },
  });
}

export async function updateLedgerEntry(actionId: string, input: LedgerUpdateInput) {
  return prisma.agentActionLedger.update({
    where: { action_id: actionId },
    data: {
      ...input,
    },
  });
}
