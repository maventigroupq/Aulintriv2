// src/components/AgentConfidenceBadge.tsx
// Sprint 1 UI Primitive — renders confidence_score from agent_action_ledger
// GREEN >= 0.97 (fast-path eligible) | AMBER >= 0.85 | RED < 0.85

'use client';

import { cn } from '../lib/utils';

interface AgentConfidenceBadgeProps {
  score: number;          // 0.0–1.0 from agent_action_ledger.confidence_score
  action_type: string;    // e.g. 'classify_hts_code', 'draft_entry_summary'
  show_label?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

type ConfidenceLevel = 'fast-path' | 'review-recommended' | 'full-review-required';

function getConfidenceLevel(score: number): ConfidenceLevel {
  if (score >= 0.97) return 'fast-path';
  if (score >= 0.85) return 'review-recommended';
  return 'full-review-required';
}

const LEVEL_CONFIG: Record<ConfidenceLevel, {
  label: string;
  sublabel: string;
  dotClass: string;
  textClass: string;
  bgClass: string;
  borderClass: string;
  badgeLabel: string;
}> = {
  'fast-path': {
    label: 'Fast Path',
    sublabel: '30-sec BLC review',
    dotClass: 'bg-emerald-400',
    textClass: 'text-emerald-400',
    bgClass: 'bg-emerald-400/10',
    borderClass: 'border-emerald-400/30',
    badgeLabel: 'AUTO',
  },
  'review-recommended': {
    label: 'Review',
    sublabel: 'BLC recommended',
    dotClass: 'bg-amber-400',
    textClass: 'text-amber-400',
    bgClass: 'bg-amber-400/10',
    borderClass: 'border-amber-400/30',
    badgeLabel: 'REVIEW',
  },
  'full-review-required': {
    label: 'Full Review',
    sublabel: 'BLC required',
    dotClass: 'bg-red-400',
    textClass: 'text-red-400',
    bgClass: 'bg-red-400/10',
    borderClass: 'border-red-400/30',
    badgeLabel: 'HOLD',
  },
};

const ACTION_TYPE_LABELS: Record<string, string> = {
  classify_hts_code: 'HTS',
  draft_entry_summary: 'Entry',
  submit_isf_filing: 'ISF',
  calculate_duties: 'Duties',
  extract_rfq_data: 'RFQ',
};

export function AgentConfidenceBadge({
  score,
  action_type,
  show_label = true,
  size = 'md',
  className,
}: AgentConfidenceBadgeProps) {
  const level = getConfidenceLevel(score);
  const config = LEVEL_CONFIG[level];
  const actionLabel = ACTION_TYPE_LABELS[action_type] ?? action_type;
  const scoreDisplay = (score * 100).toFixed(1) + '%';

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2',
  };

  const dotSizeClasses = {
    sm: 'h-1.5 w-1.5',
    md: 'h-2 w-2',
    lg: 'h-2.5 w-2.5',
  };

  return (
    <div
      className={cn(
        'inline-flex items-center rounded border font-mono font-medium',
        config.bgClass,
        config.borderClass,
        config.textClass,
        sizeClasses[size],
        className
      )}
      title={`${actionLabel} confidence: ${scoreDisplay} — ${config.sublabel}`}
    >
      {/* Pulsing indicator dot */}
      <span className="relative flex shrink-0">
        {level === 'fast-path' && (
          <span className={cn('animate-ping absolute inline-flex h-full w-full rounded-full opacity-50', config.dotClass)} />
        )}
        <span className={cn('relative inline-flex rounded-full', config.dotClass, dotSizeClasses[size])} />
      </span>

      {/* Score */}
      <span className="tabular-nums">{scoreDisplay}</span>

      {/* Label */}
      {show_label && (
        <>
          <span className="opacity-40">·</span>
          <span className="opacity-80">{config.badgeLabel}</span>
        </>
      )}
    </div>
  );
}

// ── Storybook-compatible export ──────────────────────────────────────────────
export type { AgentConfidenceBadgeProps };
