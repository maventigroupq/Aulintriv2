// src/components/FANAlertBanner.tsx
// Federated Anomaly Network — real-time cross-tenant threat event display
// Subscribes to SSE stream. NEVER shows detected_by_tenant (anonymized).

'use client';

import { useEffect, useState, useCallback } from 'react';
import { cn } from '../lib/utils';

interface FANAlert {
  event_id: string;
  event_type: FANEventType;
  hts_chapters_affected: string[];
  origin_country: string;
  destination_port: string | null;
  risk_level: 1 | 2 | 3 | 4 | 5;
  detected_at: string;
  // NO detected_by_tenant — anonymized at server
}

type FANEventType =
  | 'INTENSIVE_EXAM'
  | 'FDA_HOLD'
  | 'USDA_HOLD'
  | 'DOJ_TRANSSHIPMENT'
  | 'CUSTOMS_HOLD_PATTERN'
  | 'AD_CVD_SCOPE_ACTION';

interface FANAlertBannerProps {
  tenant_id: string;
  className?: string;
  max_alerts?: number;
}

const EVENT_TYPE_CONFIG: Record<FANEventType, {
  label: string;
  icon: string;
  colorClass: string;
}> = {
  INTENSIVE_EXAM:        { label: 'Intensive Exam',     icon: '🔍', colorClass: 'border-violet-400/40 bg-violet-400/5 text-violet-300' },
  FDA_HOLD:              { label: 'FDA Hold',            icon: '⚕️', colorClass: 'border-red-400/40 bg-red-400/5 text-red-300' },
  USDA_HOLD:             { label: 'USDA Hold',           icon: '🌾', colorClass: 'border-orange-400/40 bg-orange-400/5 text-orange-300' },
  DOJ_TRANSSHIPMENT:     { label: 'DOJ Transshipment',   icon: '⚠️', colorClass: 'border-red-500/40 bg-red-500/8 text-red-200' },
  CUSTOMS_HOLD_PATTERN:  { label: 'Hold Pattern',        icon: '🔒', colorClass: 'border-amber-400/40 bg-amber-400/5 text-amber-300' },
  AD_CVD_SCOPE_ACTION:   { label: 'AD/CVD Scope Action', icon: '📋', colorClass: 'border-blue-400/40 bg-blue-400/5 text-blue-300' },
};

const RISK_LEVEL_LABELS: Record<number, string> = {
  1: 'Low', 2: 'Moderate', 3: 'Elevated', 4: 'High', 5: 'Critical',
};

function RiskDots({ level }: { level: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(n => (
        <div
          key={n}
          className={cn(
            'h-1.5 w-1.5 rounded-full transition-colors',
            n <= level
              ? level >= 4 ? 'bg-red-400' : level >= 3 ? 'bg-amber-400' : 'bg-violet-400'
              : 'bg-white/10'
          )}
        />
      ))}
    </div>
  );
}

export function FANAlertBanner({ tenant_id, className, max_alerts = 3 }: FANAlertBannerProps) {
  const [alerts, setAlerts] = useState<FANAlert[]>([]);
  const [connected, setConnected] = useState(false);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  const addAlert = useCallback((alert: FANAlert) => {
    setAlerts(prev => [alert, ...prev].slice(0, max_alerts));
  }, [max_alerts]);

  useEffect(() => {
    const source = new EventSource(`/api/fan/stream?tenant_id=${encodeURIComponent(tenant_id)}`);

    source.onopen = () => setConnected(true);

    source.onmessage = (e) => {
      try {
        const alert = JSON.parse(e.data) as FANAlert;
        addAlert(alert);
      } catch {
        console.error('[FAN] Failed to parse alert:', e.data);
      }
    };

    source.onerror = () => {
      setConnected(false);
      // SSE auto-reconnects
    };

    return () => {
      source.close();
      setConnected(false);
    };
  }, [tenant_id, addAlert]);

  const visibleAlerts = alerts.filter(a => !dismissed.has(a.event_id));

  if (visibleAlerts.length === 0) return null;

  return (
    <div className={cn('space-y-2', className)}>
      {/* FAN Header */}
      <div className="flex items-center gap-2 px-1">
        <div className={cn('h-1.5 w-1.5 rounded-full', connected ? 'bg-violet-400 animate-pulse' : 'bg-white/20')} />
        <span className="font-mono text-xs text-white/40 uppercase tracking-widest">
          FAN Network · {visibleAlerts.length} Alert{visibleAlerts.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Alert Cards */}
      {visibleAlerts.map(alert => {
        const config = EVENT_TYPE_CONFIG[alert.event_type];
        const timeAgo = formatTimeAgo(new Date(alert.detected_at));

        return (
          <div
            key={alert.event_id}
            className={cn(
              'rounded-lg border px-4 py-3 font-mono text-sm',
              'flex items-start justify-between gap-3',
              config.colorClass
            )}
          >
            <div className="flex items-start gap-3 min-w-0">
              <span className="mt-0.5 shrink-0 text-base">{config.icon}</span>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-xs uppercase tracking-wide opacity-80">
                    {config.label}
                  </span>
                  <RiskDots level={alert.risk_level} />
                  <span className="text-xs opacity-50">{RISK_LEVEL_LABELS[alert.risk_level]}</span>
                </div>
                <p className="mt-1 text-xs opacity-70 leading-relaxed">
                  {alert.destination_port && (
                    <span className="font-medium">{alert.destination_port} · </span>
                  )}
                  {alert.origin_country} origin ·{' '}
                  HTS {alert.hts_chapters_affected.map(c => `Ch.${c}`).join(', ')}
                </p>
                <p className="mt-1 text-xs opacity-40">{timeAgo}</p>
              </div>
            </div>
            <button
              onClick={() => setDismissed(prev => new Set([...prev, alert.event_id]))}
              className="shrink-0 mt-0.5 opacity-30 hover:opacity-70 transition-opacity text-current"
              aria-label="Dismiss alert"
            >
              ×
            </button>
          </div>
        );
      })}
    </div>
  );
}

function formatTimeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
