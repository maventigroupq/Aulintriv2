import type { Meta, StoryObj } from '@storybook/react';
import { AgentConfidenceBadge } from './AgentConfidenceBadge';

const meta = {
  title: 'Components/AgentConfidenceBadge',
  component: AgentConfidenceBadge,
  args: {
    action_type: 'classify_hts_code',
    show_label: true,
    size: 'md',
  },
  parameters: {
    backgrounds: {
      default: 'slate',
    },
  },
} satisfies Meta<typeof AgentConfidenceBadge>;

export default meta;

type Story = StoryObj<typeof meta>;

export const FastPath: Story = {
  args: {
    score: 0.991,
  },
};

export const ReviewRecommended: Story = {
  args: {
    score: 0.91,
  },
};

export const FullReviewRequired: Story = {
  args: {
    score: 0.71,
  },
};
