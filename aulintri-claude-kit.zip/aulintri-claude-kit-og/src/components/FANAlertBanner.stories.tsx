import type { Meta, StoryObj } from '@storybook/react';
import { useEffect } from 'react';
import { FANAlertBanner } from './FANAlertBanner';

class MockEventSource {
  static instances: MockEventSource[] = [];

  onopen: (() => void) | null = null;
  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: (() => void) | null = null;

  constructor(_url: string) {
    MockEventSource.instances.push(this);

    queueMicrotask(() => {
      this.onopen?.();

      const alerts = [
        {
          event_id: 'evt_1',
          event_type: 'FDA_HOLD',
          hts_chapters_affected: ['08'],
          origin_country: 'CN',
          destination_port: 'USLAX',
          risk_level: 4,
          detected_at: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        },
        {
          event_id: 'evt_2',
          event_type: 'AD_CVD_SCOPE_ACTION',
          hts_chapters_affected: ['73'],
          origin_country: 'VN',
          destination_port: 'USLGB',
          risk_level: 3,
          detected_at: new Date(Date.now() - 75 * 60 * 1000).toISOString(),
        },
      ];

      alerts.forEach((alert) => {
        this.onmessage?.({ data: JSON.stringify(alert) } as MessageEvent);
      });
    });
  }

  close() {}
}

function MockedBanner() {
  useEffect(() => {
    const previous = globalThis.EventSource;
    Object.defineProperty(globalThis, 'EventSource', {
      configurable: true,
      writable: true,
      value: MockEventSource,
    });

    return () => {
      Object.defineProperty(globalThis, 'EventSource', {
        configurable: true,
        writable: true,
        value: previous,
      });
    };
  }, []);

  return (
    <div style={{ width: 720 }}>
      <FANAlertBanner tenant_id="tenant_storybook" />
    </div>
  );
}

const meta = {
  title: 'Components/FANAlertBanner',
  component: MockedBanner,
  parameters: {
    layout: 'padded',
    backgrounds: {
      default: 'slate',
    },
  },
} satisfies Meta<typeof MockedBanner>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {};
