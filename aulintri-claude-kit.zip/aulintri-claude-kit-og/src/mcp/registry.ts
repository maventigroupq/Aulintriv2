// src/mcp/registry.ts
// Central MCP Tool Registry — every Aulintri capability registers here
// External AI agents discover tools via the tools/list endpoint

import Ajv from 'ajv';
const ajv = new Ajv({ strict: true });

export interface MCPTool {
  name: string;
  description: string;
  inputSchema: Record<string, unknown>; // JSON Schema
  handler: (input: unknown, context: ToolContext) => Promise<unknown>;
  // Auto-generated from inputSchema
  validateInput?: (input: unknown) => { valid: boolean; errors?: unknown[] };
}

export interface ToolContext {
  tenant_id: string;
  token_id: string;
  tool_scope: string[];
}

class ToolRegistry {
  private tools = new Map<string, MCPTool>();

  register(tool: MCPTool): void {
    if (this.tools.has(tool.name)) {
      throw new Error(`Tool already registered: ${tool.name}. Use a unique name.`);
    }

    // Compile JSON Schema validator
    const validate = ajv.compile(tool.inputSchema);
    const toolWithValidator: MCPTool = {
      ...tool,
      validateInput: (input: unknown) => {
        const valid = validate(input);
        return { valid, errors: valid ? undefined : validate.errors ?? [] };
      }
    };

    this.tools.set(tool.name, toolWithValidator);
    console.log(`[MCP Registry] Registered tool: ${tool.name}`);
  }

  get(name: string): MCPTool | undefined {
    return this.tools.get(name);
  }

  getAll(): MCPTool[] {
    return Array.from(this.tools.values());
  }

  has(name: string): boolean {
    return this.tools.has(name);
  }

  getToolNames(): string[] {
    return Array.from(this.tools.keys());
  }
}

export const toolRegistry = new ToolRegistry();

// ─────────────────────────────────────────────────────────────────────────────
// TOOL REGISTRATION — Import and register all tools here
// Phase 1 tools are registered at startup
// ─────────────────────────────────────────────────────────────────────────────

export async function registerAllTools(): Promise<void> {
  // Sprint 1-3: Core intelligence tools
  const { extractRFQData } = await import('./tools/extract-rfq-data');
  const { classifyHTSCode } = await import('./tools/classify-hts-code');
  const { getCarrierRates } = await import('./tools/get-carrier-rates');
  const { getCarrierSafetyScore } = await import('./tools/get-carrier-safety-score');

  toolRegistry.register(extractRFQData);
  toolRegistry.register(classifyHTSCode);
  toolRegistry.register(getCarrierRates);
  toolRegistry.register(getCarrierSafetyScore);

  // Sprint 7-9 tools registered when their modules are built
  // toolRegistry.register(submitISFFiling);
  // toolRegistry.register(draftEntrySummary);
  // toolRegistry.register(calculateDuties);

  console.log(`[MCP Registry] ${toolRegistry.getToolNames().length} tools registered:`, toolRegistry.getToolNames());
}
