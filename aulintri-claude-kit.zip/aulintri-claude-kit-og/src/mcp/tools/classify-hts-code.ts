// src/mcp/tools/classify-hts-code.ts
// MCP Tool: classify_hts_code
// Sprint 2 deliverable: 2.3
// External AI agents (SAP Joule, Salesforce Agentforce) can call this tool
// to classify commodities and detect AD/CVD exposure.

import Anthropic from '@anthropic-ai/sdk';
import { MCPTool, ToolContext } from '../registry';
import { ledger } from '../../agents/ledger';
import { queryADCVD } from '../../compliance/adcvd-router';
import { db } from '../../db';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY, // loaded from AWS Secrets Manager in prod
});

interface ClassifyHTSInput {
  commodity_description: string;
  country_of_origin: string;
  prior_classifications?: string[]; // CBP-liquidated codes = few-shot examples → moat
  entered_value?: number;
}

interface ClassifyHTSResult {
  hts_code: string;             // 10-digit
  confidence_score: number;     // 0.0–1.0
  ad_cvd_flags: ADCVDFlag[];
  prior_rulings_cited: string[];
  review_recommended: boolean;  // true if confidence_score < 0.97
  rationale: string;
}

interface ADCVDFlag {
  case_number: string;
  country: string;
  scope_summary: string;
  estimated_additional_duty_pct: number;
  source_document_id: string;   // pgvector record ID for traceability
}

export const classifyHTSCode: MCPTool = {
  name: 'classify_hts_code',
  description: `Classify a commodity to a 10-digit HTS code. Returns confidence score,
    AD/CVD flags from the live Federal Register RAG pipeline, and prior rulings
    for the tenant's commodity profile. Confidence >= 0.97 enables autonomous
    filing in the Clearance Agent semantic middleware.`,
  inputSchema: {
    type: 'object',
    required: ['commodity_description', 'country_of_origin'],
    properties: {
      commodity_description: {
        type: 'string',
        description: 'Full commodity description including material, form, use',
        minLength: 10,
      },
      country_of_origin: {
        type: 'string',
        description: 'ISO 2-letter country code (e.g., CN, VN, MX)',
        pattern: '^[A-Z]{2}$',
      },
      prior_classifications: {
        type: 'array',
        items: { type: 'string', pattern: '^\\d{10}$' },
        description: 'CBP-liquidated HTS codes for similar commodities — improves accuracy',
      },
      entered_value: {
        type: 'number',
        description: 'Customs value in USD (used for AD/CVD duty estimate calculation)',
      },
    },
  },

  handler: async (rawInput: unknown, context: ToolContext): Promise<ClassifyHTSResult> => {
    const input = rawInput as ClassifyHTSInput;

    // ── 1. Pre-execution ledger write (MANDATORY — even on anticipated failure) ──
    const actionId = await ledger.writePre({
      tenant_id: context.tenant_id,
      action_type: 'classify_hts_code',
      reserve_allocated: true,
    });

    try {
      // ── 2. Load tenant's prior classifications (few-shot moat) ──────────────
      const tenantPriors = await db.hTSClassification.findMany({
        where: {
          tenant_id: context.tenant_id,
          is_confirmed: true,         // CBP-liquidated only — these are ground truth
        },
        orderBy: { created_at: 'desc' },
        take: 10,
        select: { commodity_desc: true, hts_code: true, country_of_origin: true },
      });

      // ── 3. Build Claude prompt with few-shot examples ─────────────────────
      const priorExamples = [
        ...(input.prior_classifications?.map(code => ({ code, source: 'provided' })) ?? []),
        ...tenantPriors.map(p => ({
          commodity: p.commodity_desc,
          code: p.hts_code,
          coo: p.country_of_origin,
          source: 'cbp_liquidated',
        })),
      ];

      const systemPrompt = `You are a licensed U.S. Customs Broker specializing in HTS classification.
You must return ONLY valid JSON matching the specified schema.
Classify with the specificity required for 10-digit HTS codes per HTSUS Schedule B.
Prior liquidated classifications for this customer (use as few-shot examples):
${JSON.stringify(priorExamples, null, 2)}`;

      const userPrompt = `Classify this commodity:
Description: ${input.commodity_description}
Country of Origin: ${input.country_of_origin}

Return JSON:
{
  "hts_code": "XXXXXXXXXX",
  "confidence_score": 0.0-1.0,
  "rationale": "...",
  "prior_rulings_cited": ["..."]
}

Rules:
- confidence_score >= 0.97 only if you are certain about all 10 digits
- Cite specific CBP rulings if known (NY/HQ ruling numbers)
- Return ONLY JSON, no preamble`;

      const response = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: userPrompt }],
        system: systemPrompt,
      });

      const responseText = response.content[0].type === 'text' ? response.content[0].text : '';
      const parsed = JSON.parse(responseText.replace(/```json|```/g, '').trim());

      // ── 4. Query AD/CVD RAG pipeline (hybrid retrieval) ────────────────────
      const adcvdFlags = await queryADCVD([parsed.hts_code], input.country_of_origin);

      // ── 5. Store classification in accuracy model ──────────────────────────
      await db.hTSClassification.create({
        data: {
          tenant_id: context.tenant_id,
          commodity_desc: input.commodity_description,
          country_of_origin: input.country_of_origin,
          hts_code: parsed.hts_code,
          confidence_score: parsed.confidence_score,
          is_confirmed: false, // becomes true after CBP liquidation
        },
      });

      const result: ClassifyHTSResult = {
        hts_code: parsed.hts_code,
        confidence_score: parsed.confidence_score,
        ad_cvd_flags: adcvdFlags,
        prior_rulings_cited: parsed.prior_rulings_cited ?? [],
        review_recommended: parsed.confidence_score < 0.97,
        rationale: parsed.rationale,
      };

      // ── 6. Post-execution ledger write ────────────────────────────────────
      await ledger.writePost(actionId, {
        sla_met: true,
        confidence_score: parsed.confidence_score,
        outcome_type: 'classification',
        outcome_value_usd: adcvdFlags.length > 0 && input.entered_value
          ? input.entered_value * adcvdFlags[0].estimated_additional_duty_pct / 100
          : undefined,
      });

      return result;

    } catch (error) {
      // ── Failure ledger write (still mandatory) ────────────────────────────
      await ledger.writePost(actionId, {
        sla_met: false,
        confidence_score: 0,
        outcome_type: 'classification_failed',
      });
      throw error;
    }
  },
};
