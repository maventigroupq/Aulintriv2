// src/mcp/server.ts
// Aulintri MCP Server — Fastify plugin with JSON-RPC 2.0 transport
// Every Aulintri capability exposed as a callable MCP tool

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import fp from 'fastify-plugin';
import { toolRegistry } from './registry';
import { verifyMCPToken, extractTenantContext } from '../auth/mcp-auth';
import { rateLimit } from '../auth/rate-limiter';

interface JsonRPCRequest {
  jsonrpc: '2.0';
  id: string | number;
  method: string;
  params?: unknown;
}

interface JsonRPCResponse {
  jsonrpc: '2.0';
  id: string | number;
  result?: unknown;
  error?: { code: number; message: string; data?: unknown };
}

async function mcpServerPlugin(fastify: FastifyInstance) {
  // ── MCP Protocol: List available tools ──────────────────────────────────
  fastify.post('/mcp', async (request: FastifyRequest, reply: FastifyReply) => {
    const body = request.body as JsonRPCRequest;

    // Validate JSON-RPC 2.0 envelope
    if (body.jsonrpc !== '2.0' || !body.method || !body.id) {
      return reply.code(400).send({
        jsonrpc: '2.0',
        id: body.id ?? null,
        error: { code: -32600, message: 'Invalid JSON-RPC 2.0 request' }
      });
    }

    // Authenticate capability token
    const authHeader = request.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return reply.code(401).send({
        jsonrpc: '2.0',
        id: body.id,
        error: { code: -32001, message: 'Missing capability token' }
      });
    }

    let tokenContext;
    try {
      tokenContext = await verifyMCPToken(authHeader.slice(7));
    } catch {
      return reply.code(401).send({
        jsonrpc: '2.0',
        id: body.id,
        error: { code: -32002, message: 'Invalid or expired capability token' }
      });
    }

    // Rate limiting: 100 calls/minute per token (configurable per tier)
    const rateLimitResult = await rateLimit(tokenContext.token_id, tokenContext.rate_limit ?? 100);
    if (!rateLimitResult.allowed) {
      return reply.code(429).send({
        jsonrpc: '2.0',
        id: body.id,
        error: { code: -32003, message: 'Rate limit exceeded', data: { retry_after: rateLimitResult.retry_after } }
      });
    }

    // Route JSON-RPC method
    switch (body.method) {
      case 'tools/list':
        return handleListTools(body, tokenContext, reply);

      case 'tools/call':
        return handleCallTool(body, tokenContext, reply);

      default:
        return reply.send({
          jsonrpc: '2.0',
          id: body.id,
          error: { code: -32601, message: `Method not found: ${body.method}` }
        });
    }
  });

  // ── SSE stream for FAN alerts (real-time cross-tenant threat events) ────
  fastify.get('/mcp/fan/stream', async (request: FastifyRequest<{ Querystring: { tenant_id: string } }>, reply: FastifyReply) => {
    const { tenant_id } = request.query;

    reply.raw.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    });

    // Subscribe to Redis pub/sub for this tenant's HTS chapters + origins
    // Filtering happens here — only propagate alerts matching tenant profile
    const subscription = await subscribeToFANAlerts(tenant_id, (alert) => {
      // NEVER send detected_by_tenant — it's hashed/anonymized
      const safeAlert = {
        event_id: alert.id,
        event_type: alert.event_type,
        hts_chapters_affected: alert.hts_chapters_affected,
        origin_country: alert.origin_country,
        destination_port: alert.destination_port,
        risk_level: alert.risk_level,
        detected_at: alert.detected_at,
        // No tenant identifying information
      };
      reply.raw.write(`data: ${JSON.stringify(safeAlert)}\n\n`);
    });

    request.raw.on('close', () => subscription.unsubscribe());
  });
}

async function handleListTools(
  body: JsonRPCRequest,
  tokenContext: TokenContext,
  reply: FastifyReply
): Promise<FastifyReply> {
  // Return only tools the token is scoped to access
  const tools = toolRegistry.getAll()
    .filter(tool => tokenContext.tool_scope.includes(tool.name))
    .map(tool => ({
      name: tool.name,
      description: tool.description,
      inputSchema: tool.inputSchema,
    }));

  return reply.send({
    jsonrpc: '2.0',
    id: body.id,
    result: { tools }
  });
}

async function handleCallTool(
  body: JsonRPCRequest,
  tokenContext: TokenContext,
  reply: FastifyReply
): Promise<FastifyReply> {
  const params = body.params as { name: string; arguments: unknown };

  // Scope enforcement: token cannot call tools outside its scope
  if (!tokenContext.tool_scope.includes(params.name)) {
    return reply.code(403).send({
      jsonrpc: '2.0',
      id: body.id,
      error: { code: -32004, message: `Token not authorized for tool: ${params.name}` }
    });
  }

  const tool = toolRegistry.get(params.name);
  if (!tool) {
    return reply.send({
      jsonrpc: '2.0',
      id: body.id,
      error: { code: -32601, message: `Tool not found: ${params.name}` }
    });
  }

  // JSON Schema validation BEFORE any string interpolation into Claude prompts
  // This prevents JSON injection via MCP tool inputs
  const validationResult = tool.validateInput(params.arguments);
  if (!validationResult.valid) {
    return reply.code(400).send({
      jsonrpc: '2.0',
      id: body.id,
      error: {
        code: -32602,
        message: 'Invalid params',
        data: validationResult.errors
      }
    });
  }

  try {
    const context: ToolContext = {
      tenant_id: tokenContext.tenant_id,
      token_id: tokenContext.token_id,
      tool_scope: tokenContext.tool_scope,
    };

    const result = await tool.handler(params.arguments, context);

    return reply.send({
      jsonrpc: '2.0',
      id: body.id,
      result
    });
  } catch (error) {
    const err = error as Error;
    fastify.log.error({ tool: params.name, tenant: tokenContext.tenant_id, error: err.message });

    return reply.send({
      jsonrpc: '2.0',
      id: body.id,
      error: { code: -32000, message: 'Tool execution failed', data: err.message }
    });
  }
}

// Placeholder — implement in src/fan/pubsub.ts
async function subscribeToFANAlerts(tenant_id: string, callback: (alert: any) => void) {
  // Subscribe to Redis channel 'fan:alerts'
  // Filter by tenant's HTS chapters and origin countries from org settings
  return { unsubscribe: () => {} };
}

interface TokenContext {
  token_id: string;
  tenant_id: string;
  tool_scope: string[];
  rate_limit: number;
}

interface ToolContext {
  tenant_id: string;
  token_id: string;
  tool_scope: string[];
}

export default fp(mcpServerPlugin, { name: 'mcp-server' });
