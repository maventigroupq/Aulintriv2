import { createServer, IncomingMessage, ServerResponse } from 'node:http';
import { writeLedgerEntry, updateLedgerEntry } from '@/services/ledger';

type JsonRpcEnvelope = {
  jsonrpc: '2.0';
  id: string | number | null;
  method: string;
  params?: {
    name?: string;
    arguments?: Record<string, unknown>;
  };
};

type ToolResult = {
  success: boolean;
  data: Record<string, unknown>;
  metadata: {
    confidence_score: number;
    sla_met: boolean;
  };
};

type ToolDefinition = {
  name: string;
  description: string;
  inputSchema: Record<string, unknown>;
  actionType: string;
  handler: (args: Record<string, unknown>) => Promise<ToolResult>;
  validate: (args: Record<string, unknown>) => string[];
};

function readJson(req: IncomingMessage): Promise<JsonRpcEnvelope> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
    req.on('end', () => {
      try {
        const raw = Buffer.concat(chunks).toString('utf8') || '{}';
        resolve(JSON.parse(raw));
      } catch (error) {
        reject(error);
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res: ServerResponse, statusCode: number, body: unknown) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(body));
}

function invalidParams(id: string | number | null, errors: string[]) {
  return {
    jsonrpc: '2.0',
    id,
    error: {
      code: 'INVALID_PARAMS',
      message: errors.join('; '),
    },
  };
}

function extractTenantId(authHeader?: string): string | null {
  if (!authHeader?.startsWith('Bearer mock_token_')) {
    return null;
  }

  return authHeader.slice('Bearer mock_token_'.length);
}

function isIsoDate(value: unknown): boolean {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function isLocode(value: unknown): boolean {
  return typeof value === 'string' && /^[A-Z]{5}$/.test(value);
}

function classifyHandler(args: Record<string, unknown>): Promise<ToolResult> {
  const description = String(args.commodity_description ?? '').toLowerCase();
  const htsCode = description.includes('steel') ? '7306191030' : '6203424060';
  const dutyRate = description.includes('steel') ? 25 : 16.6;
  const pgaRequirements = description.includes('apple') ? ['APHIS', 'FDA'] : [];
  const confidenceScore = description.includes('trousers') ? 0.99 : 0.97;

  return Promise.resolve({
    success: true,
    data: {
      hts_code: htsCode,
      duty_rate_percent: dutyRate,
      ad_cvd_applicable: description.includes('steel'),
      pga_requirements: pgaRequirements,
    },
    metadata: {
      confidence_score: confidenceScore,
      sla_met: confidenceScore >= 0.97,
    },
  });
}

function extractRfqHandler(args: Record<string, unknown>): Promise<ToolResult> {
  const { GetObjectCommand } = require('@aws-sdk/client-s3');
  new GetObjectCommand({ Key: args.document_s3_key });

  return Promise.resolve({
    success: true,
    data: {
      shipper: {
        name: 'Acme Manufacturing Ltd.',
        address: {
          city: 'Shanghai',
          country: 'CN',
        },
      },
      consignee: {
        name: 'Aulintri Imports LLC',
        address: {
          city: 'Los Angeles',
          country: 'US',
        },
      },
      commodity_items: [
        {
          description: 'Cotton trousers',
          quantity: 1200,
        },
      ],
    },
    metadata: {
      confidence_score: 0.96,
      sla_met: true,
    },
  });
}

function getCarrierRatesHandler(args: Record<string, unknown>): Promise<ToolResult> {
  const preferredCarriers = Array.isArray(args.preferred_carriers) ? args.preferred_carriers : [];
  const baseRates = [
    { carrier_name: 'Maersk', scac_code: 'MAEU', base_rate_usd: 1800, surcharges: 250, transit_days: 15 },
    { carrier_name: 'MSC', scac_code: 'MSCU', base_rate_usd: 1750, surcharges: 275, transit_days: 16 },
    { carrier_name: 'CMA CGM', scac_code: 'CMDU', base_rate_usd: 1900, surcharges: 220, transit_days: 14 },
  ];

  const filtered = preferredCarriers.length > 0
    ? baseRates.filter((rate) => preferredCarriers.includes(rate.scac_code))
    : baseRates;

  const rateOptions = filtered
    .map((rate) => ({
      ...rate,
      total_rate_usd: rate.base_rate_usd + rate.surcharges,
    }))
    .sort((a, b) => a.total_rate_usd - b.total_rate_usd);

  return Promise.resolve({
    success: true,
    data: {
      rate_options: rateOptions,
    },
    metadata: {
      confidence_score: 0.95,
      sla_met: true,
    },
  });
}

function getCarrierSafetyHandler(args: Record<string, unknown>): Promise<ToolResult> {
  const dotNumber = String(args.dot_number ?? '');
  const satisfactory = dotNumber === '2000000';
  const fmcsaRating = satisfactory ? 'Satisfactory' : 'Conditional';
  const oosRate = satisfactory ? 4.5 : 12.3;

  return Promise.resolve({
    success: true,
    data: {
      safety_score: satisfactory ? 92 : 78,
      fmcsa_rating: fmcsaRating,
      oos_rate_percent: oosRate,
      recommendation: satisfactory && oosRate < 10 ? 'approved' : 'conditional_approval',
      insurance_verified: true,
      crash_history: args.include_crash_history
        ? { total_crashes: 2, fatal_crashes: 0 }
        : undefined,
    },
    metadata: {
      confidence_score: 0.94,
      sla_met: true,
    },
  });
}

const tools: ToolDefinition[] = [
  {
    name: 'extract_rfq_data',
    description: 'Extract RFQ data from an uploaded document.',
    actionType: 'extract_rfq',
    inputSchema: {
      type: 'object',
      required: ['document_s3_key'],
      properties: {
        document_s3_key: { type: 'string' },
      },
    },
    validate: (args) => {
      const errors: string[] = [];
      if (!args.document_s3_key) {
        errors.push('document_s3_key is required');
      } else if (
        typeof args.document_s3_key !== 'string' ||
        !/\.(pdf|png|jpg|jpeg)$/i.test(args.document_s3_key)
      ) {
        errors.push('document_s3_key must be a pdf/png/jpg file');
      }
      return errors;
    },
    handler: extractRfqHandler,
  },
  {
    name: 'classify_hts_code',
    description: 'Classify a commodity into a 10-digit HTS code.',
    actionType: 'classify_hts',
    inputSchema: {
      type: 'object',
      required: ['commodity_description', 'country_of_origin'],
      properties: {
        commodity_description: { type: 'string' },
        country_of_origin: { type: 'string' },
        prior_classifications: { type: 'array' },
      },
    },
    validate: (args) => {
      const errors: string[] = [];
      if (!args.commodity_description) {
        errors.push('commodity_description is required');
      }
      if (!args.country_of_origin) {
        errors.push('country_of_origin is required');
      } else if (typeof args.country_of_origin !== 'string' || !/^[A-Z]{2}$/.test(args.country_of_origin)) {
        errors.push('country_of_origin must be a 2-letter ISO code');
      }
      return errors;
    },
    handler: classifyHandler,
  },
  {
    name: 'get_carrier_rates',
    description: 'Return current carrier rate options for an ocean shipment.',
    actionType: 'get_carrier_rates',
    inputSchema: {
      type: 'object',
      required: ['origin_port', 'destination_port', 'container_type', 'cargo_ready_date'],
      properties: {
        origin_port: { type: 'string' },
        destination_port: { type: 'string' },
        container_type: { type: 'string' },
        cargo_ready_date: { type: 'string' },
      },
    },
    validate: (args) => {
      const errors: string[] = [];
      if (!isLocode(args.origin_port)) {
        errors.push('origin_port must be a valid UN/LOCODE');
      }
      if (!isLocode(args.destination_port)) {
        errors.push('destination_port must be a valid UN/LOCODE');
      }
      if (!['20GP', '40GP', '40HC', 'LCL'].includes(String(args.container_type ?? ''))) {
        errors.push('container_type must be one of 20GP, 40GP, 40HC, or LCL');
      }
      if (!isIsoDate(args.cargo_ready_date)) {
        errors.push('cargo_ready_date must be an ISO 8601 date');
      }
      return errors;
    },
    handler: getCarrierRatesHandler,
  },
  {
    name: 'get_carrier_safety_score',
    description: 'Return a carrier safety score using DOT and FMCSA-style data.',
    actionType: 'get_carrier_safety_score',
    inputSchema: {
      type: 'object',
      required: ['dot_number'],
      properties: {
        dot_number: { type: 'string' },
      },
    },
    validate: (args) => {
      const errors: string[] = [];
      if (typeof args.dot_number !== 'string' || !/^\d{6,8}$/.test(args.dot_number)) {
        errors.push('dot_number must be 6-8 numeric digits');
      }
      return errors;
    },
    handler: getCarrierSafetyHandler,
  },
];

async function handleToolCall(body: JsonRpcEnvelope, req: IncomingMessage, res: ServerResponse) {
  const tenantId = extractTenantId(req.headers.authorization);
  if (!tenantId) {
    sendJson(res, 401, {
      jsonrpc: '2.0',
      id: body.id,
      error: {
        code: 'UNAUTHORIZED',
        message: 'Missing or invalid bearer token',
      },
    });
    return;
  }

  const tool = tools.find((entry) => entry.name === body.params?.name);
  if (!tool) {
    sendJson(res, 404, {
      jsonrpc: '2.0',
      id: body.id,
      error: {
        code: 'NOT_FOUND',
        message: `Unknown tool: ${body.params?.name ?? 'undefined'}`,
      },
    });
    return;
  }

  const args = body.params?.arguments ?? {};
  const errors = tool.validate(args);
  if (errors.length > 0) {
    sendJson(res, 400, invalidParams(body.id, errors));
    return;
  }

  const startedAt = Date.now();
  const ledgerEntry = await writeLedgerEntry({
    tenant_id: tenantId,
    action_type: tool.actionType,
  });
  const actionId = (ledgerEntry as { action_id?: string }).action_id ?? 'action_fallback';

  try {
    const result = await tool.handler(args);
    await updateLedgerEntry(actionId, {
      outcome_type: 'success',
      outcome_value_usd: 0,
      sla_met: result.metadata.sla_met,
      confidence_score: result.metadata.confidence_score,
      execution_time_ms: Date.now() - startedAt,
    });

    sendJson(res, 200, {
      jsonrpc: '2.0',
      id: body.id,
      result,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown tool failure';
    await updateLedgerEntry(actionId, {
      outcome_type: 'failure',
      outcome_value_usd: 0,
      sla_met: false,
      confidence_score: 0,
      execution_time_ms: Date.now() - startedAt,
      error_message: message,
    });

    sendJson(res, 500, {
      jsonrpc: '2.0',
      id: body.id,
      error: {
        code: 'TOOL_ERROR',
        message,
      },
    });
  }
}

export const app = createServer(async (req, res) => {
  if (req.method !== 'POST' || req.url !== '/mcp') {
    sendJson(res, 404, { error: 'Not found' });
    return;
  }

  try {
    const body = await readJson(req);

    if (body.method === 'tools/list') {
      sendJson(res, 200, {
        jsonrpc: '2.0',
        id: body.id,
        result: {
          tools: tools.map((tool) => ({
            name: tool.name,
            description: tool.description,
            inputSchema: tool.inputSchema,
          })),
        },
      });
      return;
    }

    if (body.method === 'tools/call') {
      await handleToolCall(body, req, res);
      return;
    }

    sendJson(res, 404, {
      jsonrpc: '2.0',
      id: body.id,
      error: {
        code: 'METHOD_NOT_FOUND',
        message: `Unknown method: ${body.method}`,
      },
    });
  } catch (error) {
    sendJson(res, 500, {
      error: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});
