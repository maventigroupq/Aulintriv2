# CLAUDE.md — Aulintri v2.0 Build System
# MCP-Native Headless Broker | Customs Compliance Platform
# Beyond Logix (BLX) · Beyond Clearance (BLC) · Maventi Group

---

## 🧠 What You Are Building

Aulintri is an MCP-native agentic customs compliance platform. It is NOT a traditional CRUD app.
The core architectural mandate: every capability is a registered MCP tool callable by external AI agents.

**Stack:**
- Frontend: Next.js 15 + TypeScript + Tailwind CSS
- Backend: Node.js (Fastify) + @modelcontextprotocol/sdk
- Database: PostgreSQL (RDS) + pgvector extension
- Cache/Pub-Sub: ElastiCache Redis
- AI: Claude API (claude-sonnet-4-20250514)
- Cloud: AWS (VPC, RDS, S3, Cognito, Lambda, SES)
- Billing: agent_action_ledger (source of truth), Zoho Books (accounting sync)

---

## 🏗️ Critical Architecture Rules

### Rule 1: MCP-First, Always
Every tool function built must be registered as an MCP capability from day one.
NEVER build a REST endpoint that should be an MCP tool.
MCP tools use JSON-RPC 2.0 transport via Fastify plugin.

### Rule 2: agent_action_ledger is Sacred
Every Claude API call writes a pre-execution record BEFORE execution.
Schema (enforce NOT NULL on all fields):
```
{ action_id, tenant_id, action_type, reserve_allocated,
  burst_billable, outcome_type, outcome_value_usd,
  sla_met, confidence_score, timestamp }
```

### Rule 3: Multi-Tenant RLS Always On
PostgreSQL Row-Level Security on ALL tables.
FAN exception: threat_events readable cross-tenant ONLY when:
  anonymization_status = 'cleared' AND shared = true

### Rule 4: Confidence Score Routing
confidence_score >= 0.97 + no FAN flags → 30-second BLC fast review path
confidence_score < 0.97 OR FAN flag → full BLC review with agent explanation

### Rule 5: Pre-execution Writes on Failure Too
Even failed agent actions write a ledger record. Incomplete SLA dataset = E&O underwriting failure.

---

## 📦 Domain Glossary

| Term | Meaning |
|------|---------|
| BLX | Beyond Logix — freight forwarding operator |
| BLC | Beyond Clearance — customs brokerage operator |
| AOS | Agent Orchestration System — governs cross-agent handoffs via Redis |
| FAN | Federated Anomaly Network — cross-tenant enforcement intelligence |
| CATAIR | CBP's EDI spec for ABI transmissions |
| ISF | Importer Security Filing (10+2) — due 24h before vessel arrival |
| ABI | Automated Broker Interface — CBP's filing channel |
| AD/CVD | Antidumping / Countervailing Duties |
| IOR | Importer of Record |
| HTS | Harmonized Tariff Schedule code (10-digit) |
| COO | Country of Origin |
| PGA | Partner Government Agency (FDA, USDA, EPA, CPSC, TTB) |
| DIS | Document Imaging System — CBP ACE document upload |
| MPF | Merchandise Processing Fee |
| HMF | Harbor Maintenance Fee |
| FTZ | Foreign Trade Zone |
| E&O | Errors & Omissions insurance |
| SLA | Service Level Agreement (legally backed by E&O policy) |

---

## 🔧 MCP Tool Registry (Build Order)

Sprint 1-3 tools (register from day 1):
1. `extract_rfq_data(document_s3_key)` → QuoteRequest
2. `classify_hts_code(commodity_description, country_of_origin, prior_classifications[])` → HTSResult
3. `get_carrier_rates(origin_port, dest_port, container_type, cargo_date)` → RateOption[]
4. `get_carrier_safety_score(dot_number)` → SafetyScore

Sprint 7-9 tools:
5. `submit_isf_filing(shipment_id)` → ISFResult
6. `draft_entry_summary(shipment_id)` → EntryDraft
7. `calculate_duties(hts_code, coo, entered_value, quantity)` → DutyCalc
8. `submit_fda_prior_notice(shipment_id)` → PNResult
9. `screen_compliance(party_name, party_country, commodity_hts)` → ComplianceResult

Sprint 13-14 tools:
10. `book_ocean_freight(quote_id, carrier_id, booking_details)` → BookingConfirmation
11. `track_shipment(booking_reference)` → TrackingEvents[]
12. `get_electronic_bl(booking_reference)` → BLDocument
13. `book_parcel(origin, destination, package_details, carrier_preference)` → ParcelBooking
14. `create_drayage_order(shipment_id, terminal, delivery_address, required_date)` → DrayageOrder
15. `compare_carrier_rates(origin_port, dest_port, container_type, cargo_date)` → RateComparison
16. `simulate_ieepa_scenarios(hts_code, coo, annual_import_volume)` → IEEPAScenarios
17. `generate_report(report_type, tenant_id, date_range)` → ReportData

---

## 🤖 Agent Routing Rules

### Parallel Dispatch (ALL conditions must be met):
- 3+ unrelated tasks across independent domains
- No shared files or database state between tasks
- Clear module boundaries

### Sequential Dispatch (ANY condition triggers):
- Task B needs output from Task A
- Shared database schema changes
- MCP tool registration depends on schema existing first

### Domain Ownership:
- **architect-agent**: Schema design, MCP tool registry, AOS patterns, pgvector setup
- **backend-agent**: Fastify routes, MCP tool handlers, Lambda workers, Redis pub/sub
- **frontend-agent**: Next.js pages, React components, Storybook, Tailwind
- **customs-agent**: CATAIR formatting, CBP logic, ISF/entry rules, PGA requirements
- **devops-agent**: AWS infra, RDS, ElastiCache, S3, Cognito, Lambda, CI/CD
- **test-agent**: Acceptance criteria validation, CBP sandbox testing, SLA verification

### File Ownership (no overlap):
- architect-agent owns: `prisma/schema.prisma`, `src/mcp/registry.ts`, `docs/architecture/`
- backend-agent owns: `src/api/`, `src/agents/`, `src/workers/`, `src/mcp/tools/`
- frontend-agent owns: `src/app/` (Next.js), `src/components/`, `storybook/`
- customs-agent owns: `src/customs/`, `src/catair/`, `src/compliance/`
- devops-agent owns: `infra/`, `Dockerfile`, `.github/workflows/`, `terraform/`
- test-agent owns: `tests/`, `src/__tests__/`, `acceptance/`

---

## 📋 Sprint Phases

### Phase 1 (Months 1-3, Sprints 1-6): Foundations
Goal: BLX processes all quotes through Aulintri. MCP Server live with 4 tools.
Exit: RAG pipeline ingesting Federal Register daily. FAN schema live.

### Phase 2 (Months 4-6, Sprints 7-12): Clearance Engine
Goal: BLC files all entries. FAN cross-tenant propagation live. FAPI 2.0 financing demo.
Exit: 12+ MCP tools. 6-month SLA report to E&O insurer.

### Phase 3 (Months 7-9, Sprints 13-18): Production Launch
Goal: External customers. E&O policy active. First paying customer on Agentic Contract.
Exit: Full import lifecycle executable by external MCP client without UI.

---

## ⚠️ Do Not Rules

- NEVER auto-file to CBP without BLC human review on first external customer entry
- NEVER store sensitive PII in CloudWatch logs (redact before logging)
- NEVER skip the pre-execution ledger write (even on anticipated failures)
- NEVER build point-to-point REST carrier APIs — they must be MCP tools
- NEVER hardcode credentials — all secrets in AWS Secrets Manager
- NEVER submit to CBP during 6am-7am ET maintenance window
- NEVER use Zoho Books as billing source of truth — it's accounting sync only

---

## ✅ Acceptance Criteria Defaults

Every sprint deliverable must:
1. Have a corresponding agent_action_ledger record written
2. Be registered as an MCP tool if it's a callable capability
3. Have PostgreSQL RLS enforced on any new table
4. Pass CBP sandbox test (for customs items)
5. Have Storybook story if it's a UI component

---

## 🗂️ Project File Structure

```
aulintri/
├── CLAUDE.md                    ← This file
├── .claude/
│   ├── agents/                  ← Sub-agent definitions
│   └── commands/                ← Slash commands
├── src/
│   ├── app/                     ← Next.js App Router
│   ├── components/              ← React components + Storybook
│   ├── api/                     ← Fastify routes
│   ├── mcp/
│   │   ├── server.ts            ← MCP Fastify plugin
│   │   ├── registry.ts          ← Tool registry
│   │   └── tools/               ← One file per MCP tool
│   ├── agents/
│   │   ├── orchestration/       ← AOS (Agent Orchestration System)
│   │   ├── quote/               ← Quote Agent
│   │   ├── clearance/           ← Clearance Agent
│   │   └── ops/                 ← Ops Agent
│   ├── customs/                 ← CATAIR, ISF, entry, PGA logic
│   ├── compliance/              ← OFAC, AD/CVD, FAN
│   ├── workers/                 ← Lambda workers (RAG ingestion, billing)
│   └── db/                      ← Prisma schema + migrations
├── infra/                       ← Terraform / AWS CDK
├── tests/
└── docs/
    ├── architecture/
    ├── mcp-integration-guide/
    └── sprint-acceptance/
```
