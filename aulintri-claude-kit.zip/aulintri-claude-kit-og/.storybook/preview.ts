import type { Preview } from '@storybook/react';

const preview: Preview = {
  parameters: {
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
    backgrounds: {
      default: 'slate',
      values: [
        { name: 'slate', value: '#0f172a' },
        { name: 'paper', value: '#f8fafc' },
      ],
    },
    layout: 'centered',
  },
};

export default preview;
