# /sprint — Full Sprint Execution Command

## Purpose
Run a complete sprint: plan → clarify → build → test → accept.
This is the primary daily driver command.

## Usage
```
/sprint N        # Full sprint with clarifying questions
/sprint N --fast # Skip questions if sprint is straightforward
```

## Workflow

```
/sprint 1
│
├─ [Step 1] Read SOW sprint requirements
├─ [Step 2] Use architect agent to analyze dependencies
├─ [Step 3] Generate questions → docs/sprint-acceptance/sprint-1-questions.md
├─ [Step 4] PAUSE — show questions to Minh
│
│   [Minh answers questions]
│
├─ [Step 5] /build sprint 1 (parallel agents)
├─ [Step 6] /test sprint 1 (test agent validates)
├─ [Step 7] Generate sprint-1-UAT.md
└─ [Step 8] "Sprint 1 ready for your UAT demo review"
```

## Sprint Readiness Gate

Before marking a sprint complete, ALL must pass:
- [ ] agent_action_ledger has no gaps for E2E test flows
- [ ] New MCP tools callable from external client
- [ ] RLS verified (cross-tenant isolation)
- [ ] CBP sandbox tests passed (customs sprints)
- [ ] Storybook stories present (UI sprints)
- [ ] sprint-N-UAT.md generated

## Sprint Status Command
```
/sprint status    # Shows current sprint progress, open questions, blockers
```
