# /plan — Aulintri Sprint Planning Command

## Purpose
Analyze the current sprint requirements, generate clarifying questions for Minh,
and produce a sprint plan. **DO NOT write any code until questions are answered.**

## Instructions

You are the Aulintri technical lead. When this command is run:

### Step 1: Read Context
Read the following files to understand current state:
- CLAUDE.md (architecture rules + domain glossary)
- docs/sprint-acceptance/current-sprint.md (if exists)
- Any recent ADRs in docs/architecture/

### Step 2: Identify the Sprint
Ask the user: "Which sprint are we planning? (e.g., Sprint 1, Sprint 3)"
Then read the relevant sprint section from the SOW.

### Step 3: Generate Clarifying Questions
Use the architect sub-agent to analyze the sprint deliverables and generate
questions in these categories:

**Architecture Questions** (ask architect sub-agent in parallel):
- Schema design decisions that need human input
- MCP tool interface decisions
- Data model ambiguities

**Business Rules Questions** (ask customs sub-agent if customs sprint):
- CBP rule interpretations needed
- SLA threshold decisions
- E&O policy coverage questions

**Integration Questions**:
- Third-party credentials or sandbox access needed
- BLX/BLC ops SME availability for testing

### Step 4: Output Format

Generate a file: `docs/sprint-acceptance/sprint-N-questions.md`

```markdown
# Sprint N — Clarifying Questions
Date: [today]
Waiting for: Minh's answers before build begins

## Architecture Decisions Needed
1. [Question] → [Why it matters] → [Option A vs Option B]

## Business Rules Needed
2. [Question] → [Regulatory reference] → [Default assumption if no answer by X]

## Integration Prerequisites
3. [Credential/access needed] → [Sprint blocker if not available by Week N]

## Questions I Can Answer Myself (listing for transparency)
- [Decision I'll make with rationale]

## Ready to Build (no questions)
- [Deliverables with clear requirements]

---
Reply with your answers and I will kick off the build.
```

### Step 5: Wait
After outputting questions, STOP. Do not begin building.
Wait for Minh to answer questions before proceeding to /build.

## Example Usage
```
/plan
> Which sprint? Sprint 1
> [generates sprint-1-questions.md]
> "Ready for your answers on 4 questions before I begin Sprint 1."
```
