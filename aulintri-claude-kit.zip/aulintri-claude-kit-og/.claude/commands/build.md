# /build — Aulintri Sprint Build Command

## Purpose
Execute a sprint build using parallel sub-agents after /plan questions are answered.
Routes work to specialist agents based on domain ownership rules in CLAUDE.md.

## Prerequisites Check
Before building, verify:
1. `docs/sprint-acceptance/sprint-N-questions.md` exists and is answered
2. Schema migrations are designed (architect agent) before backend/customs code
3. All required credentials/sandbox access confirmed

## Agent Dispatch Strategy

### Phase A: Architecture (SEQUENTIAL — must complete first)
Dispatch architect sub-agent to:
- Design/verify all new tables needed for this sprint
- Register new MCP tool shells in src/mcp/registry.ts
- Write ADR if significant architecture decision

Wait for Phase A completion before Phase B.

### Phase B: Implementation (PARALLEL where domain-independent)
After schema is approved, dispatch in parallel:

```
[backend agent]     → src/mcp/tools/new-tool.ts
                      src/agents/quote/handlers.ts
                      src/workers/new-worker.ts

[customs agent]     → src/customs/catair-formatter.ts
                      src/compliance/new-rule.ts

[frontend agent]    → src/components/NewComponent.tsx
                      src/app/new-page/page.tsx

[devops agent]      → infra/new-resource.tf
                      .github/workflows/update.yml
```

### Phase C: Tests (SEQUENTIAL — runs after implementation)
Dispatch test sub-agent to:
- Write acceptance tests for all sprint deliverables
- Run CBP sandbox tests if customs sprint
- Verify ledger chain completeness
- Generate sprint-N-UAT.md checklist

## Progress Reporting

After each parallel phase, report:
```
Phase A (Architecture): ✅ Complete
  → Schema migrations ready: [list]
  → MCP tools registered: [list]

Phase B (Implementation): ✅ Complete
  → backend: [files changed]
  → customs: [files changed]
  → frontend: [files changed]
  → devops: [files changed]

Phase C (Tests): ✅ Complete
  → Acceptance tests: [count] written
  → CBP sandbox: PASSED / FAILED
  → Ledger chain: COMPLETE / GAPS FOUND

Sprint N build complete. Ready for UAT.
```

## Conflict Prevention

If two agents need the same file (conflict risk), serialize them:
```
CONFLICT DETECTED: backend + customs both need src/customs/hts-lookup.ts
RESOLUTION: customs agent writes first, backend agent imports
```

## Example Usage
```
/build sprint 1
> Checking prerequisites...
> Phase A: Dispatching architect agent...
> [architect completes schema]
> Phase B: Dispatching backend, customs, frontend, devops in parallel...
> [all complete]
> Phase C: Dispatching test agent...
> Sprint 1 build complete.
```
