# /mcp-tool — Scaffold a New MCP Tool

## Purpose
Generate a complete MCP tool implementation with:
- Tool definition (name, description, JSON Schema)
- Handler with pre/post ledger writes
- Idempotency key support
- Unit tests
- Storybook mock (if tool has UI surface)
- Registration in src/mcp/registry.ts

## Usage
```
/mcp-tool classify_hts_code
/mcp-tool submit_isf_filing --customs  # adds CATAIR/CBP specific patterns
/mcp-tool book_ocean_freight --carrier # adds carrier API patterns
```

## Output Files Generated

```
src/mcp/tools/classify-hts-code.ts      ← Tool implementation
src/mcp/tools/classify-hts-code.test.ts ← Unit tests
```

## Generated Tool Template

```typescript
// src/mcp/tools/{tool-name}.ts
import { MCPTool } from '../registry';
import { ledger } from '../../agents/ledger';
import { z } from 'zod';

// 1. Input schema (also used for JSON Schema validation)
const InputSchema = z.object({
  // Define inputs here
});

export const toolName: MCPTool = {
  name: '{tool_name}',
  description: '{description}',
  inputSchema: zodToJsonSchema(InputSchema),

  handler: async (rawInput, context) => {
    // 2. Validate input
    const input = InputSchema.parse(rawInput);

    // 3. Idempotency check (for state-mutating tools)
    if (input.idempotency_key) {
      const existing = await db.idempotencyKeys.findUnique({
        where: { key: input.idempotency_key }
      });
      if (existing) return existing.result;
    }

    // 4. Pre-execution ledger write (MANDATORY)
    const actionId = await ledger.writePre({
      tenant_id: context.tenant_id,
      action_type: '{tool_name}',
      reserve_allocated: true
    });

    try {
      // 5. Tool logic here
      const result = await execute(input, context);

      // 6. Post-execution ledger write
      await ledger.writePost(actionId, {
        sla_met: true,
        confidence_score: result.confidence_score ?? 1.0,
        outcome_type: '{outcome_type}'
      });

      // 7. Store idempotency result
      if (input.idempotency_key) {
        await db.idempotencyKeys.create({
          data: { key: input.idempotency_key, result }
        });
      }

      return result;

    } catch (err) {
      // 8. Failure ledger write (still mandatory)
      await ledger.writePost(actionId, {
        sla_met: false,
        confidence_score: 0,
        outcome_type: '{tool_name}_failed'
      });
      throw err;
    }
  }
};
```
