# Aulintri v2.0 — Claude Code Build Kit

MCP-Native Headless Broker | Customs Compliance Platform
Beyond Logix · Beyond Clearance · Maventi Group

---

## What This Kit Is

This directory is your complete Claude Code setup for building Aulintri v2.0.
Copy it into your project root and it transforms Claude Code into a coordinated
**team of 6 specialist agents** that build the platform sprint-by-sprint.

---

## How to Start

### Step 1: Install Claude Code
```bash
npm install -g @anthropic-ai/claude-code
```

### Step 2: Copy this kit into your project root
```bash
cp -r aulintri-claude-kit/. your-aulintri-project/
```

### Step 3: Open Claude Code in your project
```bash
cd your-aulintri-project
claude
```

Claude Code will read `CLAUDE.md` automatically. It now knows:
- The entire Aulintri domain (BLX, BLC, FAN, AOS, CATAIR, ISF, etc.)
- The 6 specialist sub-agents and their file ownership
- The MCP-first architecture mandate
- The agent_action_ledger requirement
- Every MCP tool to be built across 18 sprints

---

## Your Daily Workflow

### Start a sprint:
```
/plan
```
→ Claude Code analyzes the sprint, asks you clarifying questions, and STOPS.
→ Answer the questions. Then:

```
/build sprint 1
```
→ Claude Code dispatches parallel sub-agents:
  - **architect** → schema + MCP registry
  - **backend** → tool handlers + Lambda workers
  - **customs** → CATAIR + CBP logic
  - **frontend** → Next.js + components
  - **devops** → AWS infra
  - **test** → acceptance tests + UAT checklist

### Add a new MCP tool:
```
/mcp-tool classify_hts_code
```
→ Generates the full tool with ledger writes, idempotency, JSON Schema, tests.

### Full sprint in one command:
```
/sprint 1
```
→ plan → wait for answers → build → test → UAT checklist

---

## The Agent Team

| Agent | What It Builds | Files It Owns |
|-------|---------------|---------------|
| **architect** | Schema, MCP registry, AOS patterns, ADRs | `prisma/`, `src/mcp/registry.ts`, `docs/architecture/` |
| **backend** | Fastify, MCP tool handlers, Lambda workers | `src/api/`, `src/mcp/tools/`, `src/workers/` |
| **customs** | CATAIR, CBP logic, ISF, entry, compliance | `src/customs/`, `src/catair/`, `src/compliance/` |
| **frontend** | Next.js, React components, Storybook | `src/app/`, `src/components/` |
| **devops** | AWS infra, Terraform, CI/CD, security | `infra/`, `.github/workflows/` |
| **test** | Acceptance tests, CBP sandbox, UAT docs | `tests/`, `acceptance/` |

Parallel dispatch: agents with no file overlap build simultaneously.
Sequential dispatch: schema must exist before tool handlers.

---

## What's Already Built (Sprint 0 — This Kit)

| File | Description |
|------|-------------|
| `CLAUDE.md` | Domain glossary, architecture rules, agent routing |
| `prisma/schema.prisma` | Full database schema including agent_action_ledger + threat_events |
| `src/mcp/server.ts` | MCP Server Fastify plugin (JSON-RPC 2.0) |
| `src/mcp/registry.ts` | Tool registry with JSON Schema validation |
| `src/mcp/tools/classify-hts-code.ts` | First MCP tool — full ledger pattern |
| `src/agents/ledger.ts` | Agent Action Ledger service (billing + SLA + E&O) |
| `src/agents/orchestration/aos.ts` | Agent Orchestration System (Redis-backed handoffs) |
| `src/components/AgentConfidenceBadge.tsx` | UI primitive: confidence score display |
| `src/components/FANAlertBanner.tsx` | UI primitive: real-time FAN alerts via SSE |
| `docs/sprint-acceptance/sprint-1-questions.md` | Sprint 1 clarifying questions (answer these first) |
| `docs/architecture/ADR-001-mcp-first.md` | Architecture decision record: MCP-first mandate |

---

## Sprint 1 Blockers — Answer These Before Building

Open `docs/sprint-acceptance/sprint-1-questions.md` and answer 9 questions.
The most time-sensitive:

**Q8: ABI Vendor** — Start evaluation NOW. Connexion, QP, or Descartes.
Sandbox access takes 2-4 weeks. Sprint 7 is blocked without it.

**Q9: Engineer Start Date** — Sprint 1 MCP scaffold assumes engineer is onboarded by Week 2.

---

## Phase Overview

| Phase | Months | Goal |
|-------|--------|------|
| Phase 1 (Sprints 1-6) | 1-3 | BLX quotes through Aulintri, 4 MCP tools live |
| Phase 2 (Sprints 7-12) | 4-6 | BLC files all entries, FAN live, FAPI 2.0 financing |
| Phase 3 (Sprints 13-18) | 7-9 | External customers, E&O policy, first paying customer |

---

## The 3 Things That Compound Your Moat

1. **agent_action_ledger** — every action logged = SLA data = E&O policy = Agentic Contract authority
2. **hts_classifications accuracy history** — CBP liquidations feed back → confidence improves with every entry
3. **FAN threat_events** — every customs hold on any tenant improves intelligence for all tenants

These three compound with every shipment processed. Protect the data.

---

## Critical Rules for Claude Code Sessions

- Always run `/plan` before `/build` on a new sprint
- Never skip the pre-execution ledger write, even in test code
- Never write a REST endpoint for something that should be an MCP tool
- Never hardcode credentials — use `process.env.*` which maps to AWS Secrets Manager
- Never submit to CBP between 6am-7am ET in any test or production code

---

*Built with Claude Code · Aulintri v2.0 · February 2026 · CONFIDENTIAL*
